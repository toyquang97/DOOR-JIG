﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ThermaquilSixPatientUI
{
    public partial class PainForm : Form
    {
        public int PainLevel { get; private set; }

        private List<RadioButton> radioButtons = new List<RadioButton>();

        public PainForm()
        {
            InitializeComponent();
            AddToRadioBtnList();
        }

        private void AddToRadioBtnList()
        {
            radioButtons.Add(rb0);
            radioButtons.Add(rb1);
            radioButtons.Add(rb2);
            radioButtons.Add(rb3);
            radioButtons.Add(rb4);
            radioButtons.Add(rb5);
            radioButtons.Add(rb6);
            radioButtons.Add(rb7);
            radioButtons.Add(rb8);
            radioButtons.Add(rb9);
            radioButtons.Add(rb10);
        }

        private void rb_CheckChanged(object sender, EventArgs e)
        {
            RadioButton rb = (RadioButton)sender;
            btnOk.Visible = true;
            if (rb.Checked)
            {
                PainLevel = Convert.ToInt32(rb.Tag);
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void PainForm_Shown(object sender, EventArgs e)
        {
            foreach (RadioButton rb in radioButtons)
            {
                rb.Checked = false;
            }
        }

    }
}
