﻿namespace ThermaquilSixPatientUI
{
    internal class MySettings
    {
        private MySettings() { }
        private static MySettings instance = null;
        public static MySettings Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new MySettings();
                }
                return instance;
            }
        }

        const int NUM_UNIQUE_CYLES = 4;
        public uint NumberOfSteps { get; private set; }
        public bool UseShamSettings { get; private set; }
        public double ShamColdMinF { get; private set; }
        public double ShamColdMaxF { get; private set; }
        public double ShamHotMinF { get; private set; }
        public double ShamHotMaxF { get; private set; }
        public double ActiveColdMinF { get; private set; }
        public double ActiveColdMaxF { get; private set; }
        public double ActiveHotMinF { get; private set; }
        public double ActiveHotMaxF { get; private set; }
        public int[] HotCycleTimeMins { get; private set;  } = new int [NUM_UNIQUE_CYLES];
        public int[] ColdCycleTimeMins { get; private set; } = new int[NUM_UNIQUE_CYLES];
        public int[] ActiveHotSetpoint { get; private set; } = new int[NUM_UNIQUE_CYLES];
        public int[] ActiveColdSetpoint { get; private set; } = new int[NUM_UNIQUE_CYLES];
        public int[] ShamHotSetpoint { get; private set; } = new int[NUM_UNIQUE_CYLES];
        public int[] ShamColdSetpoint { get; private set; } = new int[NUM_UNIQUE_CYLES];

        public void Update()
        {
            NumberOfSteps = Properties.Settings.Default.NumberOfSteps;
            UseShamSettings = Properties.Settings.Default.UseShamSettings;
            ShamColdMinF = Properties.Settings.Default.ShamColdMinF;
            ShamColdMaxF = Properties.Settings.Default.ShamColdMaxF;
            ShamHotMinF = Properties.Settings.Default.ShamHotMinF;
            ShamHotMaxF = Properties.Settings.Default.ShamHotMaxF;
            ActiveColdMinF = Properties.Settings.Default.ActiveColdMinF;
            ActiveColdMaxF = Properties.Settings.Default.ActiveColdMaxF;
            ActiveHotMinF = Properties.Settings.Default.ActiveHotMinF;
            ActiveHotMaxF = Properties.Settings.Default.ActiveHotMaxF;

            for (int i = 0; i < NUM_UNIQUE_CYLES; i++)
            {
                HotCycleTimeMins[i] = Properties.Settings.Default.HotCycleTimeMins[i];
                ColdCycleTimeMins[i] = Properties.Settings.Default.ColdCycleTimeMins[i];
                ActiveHotSetpoint[i] = Properties.Settings.Default.ActiveHotSetpoint[i]; 
                ActiveColdSetpoint[i] = Properties.Settings.Default.ActiveColdSetpoint[i];        
                ShamHotSetpoint[i] = Properties.Settings.Default.ShamHotSetpoint[i];
                ShamColdSetpoint[i] = Properties.Settings.Default.ShamColdSetpoint[i];
            }
        }

    }

}