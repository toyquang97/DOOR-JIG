﻿namespace ThermaquilSixPatientUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnCommPortConnect = new System.Windows.Forms.Button();
            this.cbCommPort = new System.Windows.Forms.ComboBox();
            this.btnSettings = new System.Windows.Forms.Button();
            this.gBoxTherapyState = new System.Windows.Forms.GroupBox();
            this.btnSkipCycle = new System.Windows.Forms.Button();
            this.btnStartTreatment = new System.Windows.Forms.Button();
            this.lblSystemStatus = new System.Windows.Forms.Label();
            this.btnIncSteps = new System.Windows.Forms.Button();
            this.lblSetPointSteps = new System.Windows.Forms.Label();
            this.lblActualTemperatureSteps = new System.Windows.Forms.Label();
            this.btnDecTime = new System.Windows.Forms.Button();
            this.btnIncTime = new System.Windows.Forms.Button();
            this.lblTimeRemaining = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblHotCyclesCount = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblColdCyclesCount = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnDecSteps = new System.Windows.Forms.Button();
            this.btnControl = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.gBoxTemps = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblColdSetpointF = new System.Windows.Forms.Label();
            this.lblHotSetpointF = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label19 = new System.Windows.Forms.Label();
            this.lblInletTempF = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblOutletTempF = new System.Windows.Forms.Label();
            this.lblColdResvTempF = new System.Windows.Forms.Label();
            this.lblHotResvTempF = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblActualTempF = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label16 = new System.Windows.Forms.Label();
            this.lblFirmwareVersion = new System.Windows.Forms.Label();
            this.btnFill = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.lblColdTempMin = new System.Windows.Forms.Label();
            this.lblColdTempMax = new System.Windows.Forms.Label();
            this.lblHotTempMin = new System.Windows.Forms.Label();
            this.lblHotTempMax = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.lblColdCycleTemp2 = new System.Windows.Forms.Label();
            this.lblColdCycleTemp1 = new System.Windows.Forms.Label();
            this.lblColdCycleTime1 = new System.Windows.Forms.Label();
            this.lblHotCycleTime1 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lblHotCycleTime2 = new System.Windows.Forms.Label();
            this.lblHotCycleTime3 = new System.Windows.Forms.Label();
            this.lblHotCycleTime4 = new System.Windows.Forms.Label();
            this.lblColdCycleTime2 = new System.Windows.Forms.Label();
            this.lblColdCycleTime3 = new System.Windows.Forms.Label();
            this.lblColdCycleTime4 = new System.Windows.Forms.Label();
            this.lblHotCycleTemp1 = new System.Windows.Forms.Label();
            this.lblHotCycleTemp2 = new System.Windows.Forms.Label();
            this.lblHotCycleTemp3 = new System.Windows.Forms.Label();
            this.lblHotCycleTemp4 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.lblColdCycleTemp4 = new System.Windows.Forms.Label();
            this.lblColdCycleTemp3 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.lblSetNumSteps = new System.Windows.Forms.Label();
            this.lblTBD = new System.Windows.Forms.Label();
            this.lblCSVFileInfo = new System.Windows.Forms.Label();
            this.btnCSVSave = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.gBoxTherapyState.SuspendLayout();
            this.gBoxTemps.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnCommPortConnect);
            this.groupBox2.Controls.Add(this.cbCommPort);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(17, 471);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(154, 139);
            this.groupBox2.TabIndex = 34;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "COM Port";
            // 
            // btnCommPortConnect
            // 
            this.btnCommPortConnect.Enabled = false;
            this.btnCommPortConnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCommPortConnect.Location = new System.Drawing.Point(8, 55);
            this.btnCommPortConnect.Margin = new System.Windows.Forms.Padding(2);
            this.btnCommPortConnect.Name = "btnCommPortConnect";
            this.btnCommPortConnect.Size = new System.Drawing.Size(128, 73);
            this.btnCommPortConnect.TabIndex = 1;
            this.btnCommPortConnect.Text = "Connect";
            this.btnCommPortConnect.UseVisualStyleBackColor = true;
            this.btnCommPortConnect.Click += new System.EventHandler(this.btnCommPortConnect_Click);
            // 
            // cbCommPort
            // 
            this.cbCommPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCommPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbCommPort.FormattingEnabled = true;
            this.cbCommPort.Location = new System.Drawing.Point(6, 23);
            this.cbCommPort.Margin = new System.Windows.Forms.Padding(2);
            this.cbCommPort.MaxDropDownItems = 16;
            this.cbCommPort.Name = "cbCommPort";
            this.cbCommPort.Size = new System.Drawing.Size(130, 33);
            this.cbCommPort.TabIndex = 0;
            this.cbCommPort.SelectedIndexChanged += new System.EventHandler(this.cbCommPort_SelectedIndexChanged);
            // 
            // btnSettings
            // 
            this.btnSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettings.Location = new System.Drawing.Point(17, 11);
            this.btnSettings.Margin = new System.Windows.Forms.Padding(2);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(104, 57);
            this.btnSettings.TabIndex = 35;
            this.btnSettings.Text = "Settings...";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // gBoxTherapyState
            // 
            this.gBoxTherapyState.BackColor = System.Drawing.SystemColors.Control;
            this.gBoxTherapyState.Controls.Add(this.btnSkipCycle);
            this.gBoxTherapyState.Controls.Add(this.btnStartTreatment);
            this.gBoxTherapyState.Controls.Add(this.lblSystemStatus);
            this.gBoxTherapyState.Controls.Add(this.btnIncSteps);
            this.gBoxTherapyState.Controls.Add(this.lblSetPointSteps);
            this.gBoxTherapyState.Controls.Add(this.lblActualTemperatureSteps);
            this.gBoxTherapyState.Controls.Add(this.btnDecTime);
            this.gBoxTherapyState.Controls.Add(this.btnIncTime);
            this.gBoxTherapyState.Controls.Add(this.lblTimeRemaining);
            this.gBoxTherapyState.Controls.Add(this.label2);
            this.gBoxTherapyState.Controls.Add(this.lblHotCyclesCount);
            this.gBoxTherapyState.Controls.Add(this.label1);
            this.gBoxTherapyState.Controls.Add(this.label15);
            this.gBoxTherapyState.Controls.Add(this.label14);
            this.gBoxTherapyState.Controls.Add(this.label6);
            this.gBoxTherapyState.Controls.Add(this.lblColdCyclesCount);
            this.gBoxTherapyState.Controls.Add(this.label5);
            this.gBoxTherapyState.Controls.Add(this.btnDecSteps);
            this.gBoxTherapyState.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gBoxTherapyState.Location = new System.Drawing.Point(17, 76);
            this.gBoxTherapyState.Margin = new System.Windows.Forms.Padding(2);
            this.gBoxTherapyState.Name = "gBoxTherapyState";
            this.gBoxTherapyState.Padding = new System.Windows.Forms.Padding(2);
            this.gBoxTherapyState.Size = new System.Drawing.Size(626, 375);
            this.gBoxTherapyState.TabIndex = 36;
            this.gBoxTherapyState.TabStop = false;
            this.gBoxTherapyState.Text = "System Status";
            // 
            // btnSkipCycle
            // 
            this.btnSkipCycle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSkipCycle.Location = new System.Drawing.Point(501, 314);
            this.btnSkipCycle.Margin = new System.Windows.Forms.Padding(2);
            this.btnSkipCycle.Name = "btnSkipCycle";
            this.btnSkipCycle.Size = new System.Drawing.Size(121, 57);
            this.btnSkipCycle.TabIndex = 47;
            this.btnSkipCycle.Text = "Skip Cycle";
            this.btnSkipCycle.UseVisualStyleBackColor = true;
            this.btnSkipCycle.Visible = false;
            this.btnSkipCycle.Click += new System.EventHandler(this.btnSkipCycle_Click);
            // 
            // btnStartTreatment
            // 
            this.btnStartTreatment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartTreatment.Location = new System.Drawing.Point(262, 267);
            this.btnStartTreatment.Margin = new System.Windows.Forms.Padding(2);
            this.btnStartTreatment.Name = "btnStartTreatment";
            this.btnStartTreatment.Size = new System.Drawing.Size(104, 57);
            this.btnStartTreatment.TabIndex = 46;
            this.btnStartTreatment.Text = "Start Treatment";
            this.btnStartTreatment.UseVisualStyleBackColor = true;
            this.btnStartTreatment.Visible = false;
            this.btnStartTreatment.Click += new System.EventHandler(this.btnStartTreatment_Click);
            // 
            // lblSystemStatus
            // 
            this.lblSystemStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSystemStatus.Location = new System.Drawing.Point(8, 34);
            this.lblSystemStatus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSystemStatus.Name = "lblSystemStatus";
            this.lblSystemStatus.Size = new System.Drawing.Size(599, 325);
            this.lblSystemStatus.TabIndex = 5;
            this.lblSystemStatus.Text = "Off";
            this.lblSystemStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnIncSteps
            // 
            this.btnIncSteps.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIncSteps.Location = new System.Drawing.Point(392, 47);
            this.btnIncSteps.Margin = new System.Windows.Forms.Padding(2);
            this.btnIncSteps.Name = "btnIncSteps";
            this.btnIncSteps.Size = new System.Drawing.Size(147, 58);
            this.btnIncSteps.TabIndex = 10;
            this.btnIncSteps.Text = "--";
            this.btnIncSteps.UseVisualStyleBackColor = true;
            this.btnIncSteps.Click += new System.EventHandler(this.btnIncSteps_Click);
            // 
            // lblSetPointSteps
            // 
            this.lblSetPointSteps.AutoSize = true;
            this.lblSetPointSteps.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSetPointSteps.Location = new System.Drawing.Point(496, 164);
            this.lblSetPointSteps.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSetPointSteps.Name = "lblSetPointSteps";
            this.lblSetPointSteps.Size = new System.Drawing.Size(30, 31);
            this.lblSetPointSteps.TabIndex = 9;
            this.lblSetPointSteps.Text = "2";
            // 
            // lblActualTemperatureSteps
            // 
            this.lblActualTemperatureSteps.AutoSize = true;
            this.lblActualTemperatureSteps.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActualTemperatureSteps.Location = new System.Drawing.Point(524, 117);
            this.lblActualTemperatureSteps.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblActualTemperatureSteps.Name = "lblActualTemperatureSteps";
            this.lblActualTemperatureSteps.Size = new System.Drawing.Size(37, 39);
            this.lblActualTemperatureSteps.TabIndex = 8;
            this.lblActualTemperatureSteps.Text = "5";
            // 
            // btnDecTime
            // 
            this.btnDecTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDecTime.Location = new System.Drawing.Point(116, 200);
            this.btnDecTime.Margin = new System.Windows.Forms.Padding(2);
            this.btnDecTime.Name = "btnDecTime";
            this.btnDecTime.Size = new System.Drawing.Size(50, 50);
            this.btnDecTime.TabIndex = 7;
            this.btnDecTime.Text = "-";
            this.btnDecTime.UseVisualStyleBackColor = true;
            this.btnDecTime.Click += new System.EventHandler(this.btnDecTime_Click);
            // 
            // btnIncTime
            // 
            this.btnIncTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIncTime.Location = new System.Drawing.Point(116, 53);
            this.btnIncTime.Margin = new System.Windows.Forms.Padding(2);
            this.btnIncTime.Name = "btnIncTime";
            this.btnIncTime.Size = new System.Drawing.Size(50, 50);
            this.btnIncTime.TabIndex = 6;
            this.btnIncTime.Text = "+";
            this.btnIncTime.UseVisualStyleBackColor = true;
            this.btnIncTime.Click += new System.EventHandler(this.btnIncTime_Click);
            // 
            // lblTimeRemaining
            // 
            this.lblTimeRemaining.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimeRemaining.Location = new System.Drawing.Point(70, 145);
            this.lblTimeRemaining.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTimeRemaining.Name = "lblTimeRemaining";
            this.lblTimeRemaining.Size = new System.Drawing.Size(134, 56);
            this.lblTimeRemaining.TabIndex = 5;
            this.lblTimeRemaining.Text = "00:15:00";
            this.lblTimeRemaining.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(42, 117);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(280, 39);
            this.label2.TabIndex = 4;
            this.label2.Text = "Time Remaining";
            // 
            // lblHotCyclesCount
            // 
            this.lblHotCyclesCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotCyclesCount.Location = new System.Drawing.Point(181, 336);
            this.lblHotCyclesCount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHotCyclesCount.Name = "lblHotCyclesCount";
            this.lblHotCyclesCount.Size = new System.Drawing.Size(51, 23);
            this.lblHotCyclesCount.TabIndex = 3;
            this.lblHotCyclesCount.Text = "0";
            this.lblHotCyclesCount.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 336);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Completed Cylces:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(385, 164);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(131, 31);
            this.label15.TabIndex = 16;
            this.label15.Text = "Setpoint:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(365, 117);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(192, 39);
            this.label14.TabIndex = 15;
            this.label14.Text = "Pad Temp:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(247, 304);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 25);
            this.label6.TabIndex = 14;
            this.label6.Text = "Cold";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblColdCyclesCount
            // 
            this.lblColdCyclesCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdCyclesCount.Location = new System.Drawing.Point(247, 336);
            this.lblColdCyclesCount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblColdCyclesCount.Name = "lblColdCyclesCount";
            this.lblColdCyclesCount.Size = new System.Drawing.Size(45, 20);
            this.lblColdCyclesCount.TabIndex = 13;
            this.lblColdCyclesCount.Text = "10";
            this.lblColdCyclesCount.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(194, 304);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 25);
            this.label5.TabIndex = 12;
            this.label5.Text = "Hot";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnDecSteps
            // 
            this.btnDecSteps.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDecSteps.Location = new System.Drawing.Point(392, 206);
            this.btnDecSteps.Margin = new System.Windows.Forms.Padding(2);
            this.btnDecSteps.Name = "btnDecSteps";
            this.btnDecSteps.Size = new System.Drawing.Size(147, 58);
            this.btnDecSteps.TabIndex = 11;
            this.btnDecSteps.Text = "--";
            this.btnDecSteps.UseVisualStyleBackColor = true;
            this.btnDecSteps.Click += new System.EventHandler(this.btnDecSteps_Click);
            // 
            // btnControl
            // 
            this.btnControl.Enabled = false;
            this.btnControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnControl.Location = new System.Drawing.Point(539, 11);
            this.btnControl.Margin = new System.Windows.Forms.Padding(2);
            this.btnControl.Name = "btnControl";
            this.btnControl.Size = new System.Drawing.Size(104, 57);
            this.btnControl.TabIndex = 38;
            this.btnControl.Text = "Prepare For Therapy";
            this.btnControl.UseVisualStyleBackColor = true;
            this.btnControl.Click += new System.EventHandler(this.btnControl_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // gBoxTemps
            // 
            this.gBoxTemps.Controls.Add(this.tableLayoutPanel2);
            this.gBoxTemps.Controls.Add(this.tableLayoutPanel1);
            this.gBoxTemps.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gBoxTemps.Location = new System.Drawing.Point(721, 12);
            this.gBoxTemps.Name = "gBoxTemps";
            this.gBoxTemps.Size = new System.Drawing.Size(284, 265);
            this.gBoxTemps.TabIndex = 40;
            this.gBoxTemps.TabStop = false;
            this.gBoxTemps.Text = "Temperatures";
            this.gBoxTemps.Visible = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.Controls.Add(this.lblColdSetpointF, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblHotSetpointF, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label22, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label23, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label26, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label27, 2, 1);
            this.tableLayoutPanel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel2.Location = new System.Drawing.Point(30, 189);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(225, 63);
            this.tableLayoutPanel2.TabIndex = 41;
            // 
            // lblColdSetpointF
            // 
            this.lblColdSetpointF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblColdSetpointF.AutoSize = true;
            this.lblColdSetpointF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdSetpointF.Location = new System.Drawing.Point(136, 34);
            this.lblColdSetpointF.Name = "lblColdSetpointF";
            this.lblColdSetpointF.Size = new System.Drawing.Size(57, 25);
            this.lblColdSetpointF.TabIndex = 9;
            this.lblColdSetpointF.Text = "--";
            this.lblColdSetpointF.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblHotSetpointF
            // 
            this.lblHotSetpointF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHotSetpointF.AutoSize = true;
            this.lblHotSetpointF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotSetpointF.Location = new System.Drawing.Point(136, 4);
            this.lblHotSetpointF.Name = "lblHotSetpointF";
            this.lblHotSetpointF.Size = new System.Drawing.Size(57, 25);
            this.lblHotSetpointF.TabIndex = 8;
            this.lblHotSetpointF.Text = "--";
            this.lblHotSetpointF.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(6, 4);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(121, 25);
            this.label22.TabIndex = 0;
            this.label22.Text = "Hot Setpoint";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 33);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(121, 27);
            this.label23.TabIndex = 1;
            this.label23.Text = "Cold Setpoint";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label26
            // 
            this.label26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(202, 4);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(17, 25);
            this.label26.TabIndex = 4;
            this.label26.Text = "F";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label27
            // 
            this.label27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(202, 34);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(17, 25);
            this.label27.TabIndex = 5;
            this.label27.Text = "F";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Controls.Add(this.label19, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblInletTempF, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label17, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblOutletTempF, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblColdResvTempF, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblHotResvTempF, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label10, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label11, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label12, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label13, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblActualTempF, 1, 4);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(30, 27);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(225, 155);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(202, 125);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(17, 25);
            this.label19.TabIndex = 14;
            this.label19.Text = "F";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblInletTempF
            // 
            this.lblInletTempF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblInletTempF.AutoSize = true;
            this.lblInletTempF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInletTempF.Location = new System.Drawing.Point(136, 94);
            this.lblInletTempF.Name = "lblInletTempF";
            this.lblInletTempF.Size = new System.Drawing.Size(57, 25);
            this.lblInletTempF.TabIndex = 11;
            this.lblInletTempF.Text = "--";
            this.lblInletTempF.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 125);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(121, 25);
            this.label17.TabIndex = 12;
            this.label17.Text = "Pad";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblOutletTempF
            // 
            this.lblOutletTempF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblOutletTempF.AutoSize = true;
            this.lblOutletTempF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutletTempF.Location = new System.Drawing.Point(136, 64);
            this.lblOutletTempF.Name = "lblOutletTempF";
            this.lblOutletTempF.Size = new System.Drawing.Size(57, 25);
            this.lblOutletTempF.TabIndex = 10;
            this.lblOutletTempF.Text = "--";
            this.lblOutletTempF.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblColdResvTempF
            // 
            this.lblColdResvTempF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblColdResvTempF.AutoSize = true;
            this.lblColdResvTempF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdResvTempF.Location = new System.Drawing.Point(136, 34);
            this.lblColdResvTempF.Name = "lblColdResvTempF";
            this.lblColdResvTempF.Size = new System.Drawing.Size(57, 25);
            this.lblColdResvTempF.TabIndex = 9;
            this.lblColdResvTempF.Text = "--";
            this.lblColdResvTempF.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblHotResvTempF
            // 
            this.lblHotResvTempF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHotResvTempF.AutoSize = true;
            this.lblHotResvTempF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotResvTempF.Location = new System.Drawing.Point(136, 4);
            this.lblHotResvTempF.Name = "lblHotResvTempF";
            this.lblHotResvTempF.Size = new System.Drawing.Size(57, 25);
            this.lblHotResvTempF.TabIndex = 8;
            this.lblHotResvTempF.Text = "--";
            this.lblHotResvTempF.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 27);
            this.label4.TabIndex = 0;
            this.label4.Text = "Hot Resevoir";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 27);
            this.label7.TabIndex = 1;
            this.label7.Text = "Cold Resevoir";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 64);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 25);
            this.label8.TabIndex = 2;
            this.label8.Text = "Outlet";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 94);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(121, 25);
            this.label9.TabIndex = 3;
            this.label9.Text = "Inlet";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(202, 4);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(17, 25);
            this.label10.TabIndex = 4;
            this.label10.Text = "F";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(202, 34);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(17, 25);
            this.label11.TabIndex = 5;
            this.label11.Text = "F";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(202, 64);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 25);
            this.label12.TabIndex = 6;
            this.label12.Text = "F";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(202, 94);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 25);
            this.label13.TabIndex = 7;
            this.label13.Text = "F";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblActualTempF
            // 
            this.lblActualTempF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblActualTempF.AutoSize = true;
            this.lblActualTempF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActualTempF.Location = new System.Drawing.Point(136, 125);
            this.lblActualTempF.Name = "lblActualTempF";
            this.lblActualTempF.Size = new System.Drawing.Size(57, 25);
            this.lblActualTempF.TabIndex = 13;
            this.lblActualTempF.Text = "--";
            this.lblActualTempF.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ThermaquilSixPatientUI.Properties.Resources.ThermaquilLogoColor;
            this.pictureBox1.InitialImage = global::ThermaquilSixPatientUI.Properties.Resources.ThermaquilLogoColor;
            this.pictureBox1.Location = new System.Drawing.Point(202, 478);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(311, 132);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(129, 48);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(187, 25);
            this.label16.TabIndex = 42;
            this.label16.Text = "Firmware Version:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblFirmwareVersion
            // 
            this.lblFirmwareVersion.AutoSize = true;
            this.lblFirmwareVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirmwareVersion.Location = new System.Drawing.Point(286, 48);
            this.lblFirmwareVersion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFirmwareVersion.Name = "lblFirmwareVersion";
            this.lblFirmwareVersion.Size = new System.Drawing.Size(28, 25);
            this.lblFirmwareVersion.TabIndex = 43;
            this.lblFirmwareVersion.Text = "--";
            this.lblFirmwareVersion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnFill
            // 
            this.btnFill.Enabled = false;
            this.btnFill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFill.Location = new System.Drawing.Point(418, 11);
            this.btnFill.Margin = new System.Windows.Forms.Padding(2);
            this.btnFill.Name = "btnFill";
            this.btnFill.Size = new System.Drawing.Size(104, 57);
            this.btnFill.TabIndex = 44;
            this.btnFill.Text = "Start Fill";
            this.btnFill.UseVisualStyleBackColor = true;
            this.btnFill.Click += new System.EventHandler(this.btnFill_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableLayoutPanel3);
            this.groupBox1.Controls.Add(this.tableLayoutPanel4);
            this.groupBox1.Controls.Add(this.lblSetNumSteps);
            this.groupBox1.Controls.Add(this.lblTBD);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(721, 283);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(476, 327);
            this.groupBox1.TabIndex = 42;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Settings";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Outset;
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.Controls.Add(this.lblColdTempMin, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.lblColdTempMax, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.lblHotTempMin, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.lblHotTempMax, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label18, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label20, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label21, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label24, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label30, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.label28, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.label25, 2, 1);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(35, 188);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 4;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(225, 128);
            this.tableLayoutPanel3.TabIndex = 10;
            // 
            // lblColdTempMin
            // 
            this.lblColdTempMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblColdTempMin.AutoSize = true;
            this.lblColdTempMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdTempMin.Location = new System.Drawing.Point(137, 98);
            this.lblColdTempMin.Name = "lblColdTempMin";
            this.lblColdTempMin.Size = new System.Drawing.Size(59, 25);
            this.lblColdTempMin.TabIndex = 20;
            this.lblColdTempMin.Text = "--";
            this.lblColdTempMin.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblColdTempMax
            // 
            this.lblColdTempMax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblColdTempMax.AutoSize = true;
            this.lblColdTempMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdTempMax.Location = new System.Drawing.Point(137, 66);
            this.lblColdTempMax.Name = "lblColdTempMax";
            this.lblColdTempMax.Size = new System.Drawing.Size(59, 25);
            this.lblColdTempMax.TabIndex = 19;
            this.lblColdTempMax.Text = "--";
            this.lblColdTempMax.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblHotTempMin
            // 
            this.lblHotTempMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHotTempMin.AutoSize = true;
            this.lblHotTempMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotTempMin.Location = new System.Drawing.Point(137, 35);
            this.lblHotTempMin.Name = "lblHotTempMin";
            this.lblHotTempMin.Size = new System.Drawing.Size(59, 25);
            this.lblHotTempMin.TabIndex = 18;
            this.lblHotTempMin.Text = "--";
            this.lblHotTempMin.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblHotTempMax
            // 
            this.lblHotTempMax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHotTempMax.AutoSize = true;
            this.lblHotTempMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotTempMax.Location = new System.Drawing.Point(137, 4);
            this.lblHotTempMax.Name = "lblHotTempMax";
            this.lblHotTempMax.Size = new System.Drawing.Size(59, 25);
            this.lblHotTempMax.TabIndex = 17;
            this.lblHotTempMax.Text = "--";
            this.lblHotTempMax.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(204, 4);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(16, 25);
            this.label18.TabIndex = 10;
            this.label18.Text = "F";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 29);
            this.label3.TabIndex = 10;
            this.label3.Text = "Hot Temp Max";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(5, 33);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(124, 29);
            this.label20.TabIndex = 11;
            this.label20.Text = "Hot Temp Min";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(5, 64);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(124, 29);
            this.label21.TabIndex = 12;
            this.label21.Text = "Cold Temp Max";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(5, 95);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(124, 31);
            this.label24.TabIndex = 13;
            this.label24.Text = "Cold Temp Min";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(204, 98);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(16, 25);
            this.label30.TabIndex = 16;
            this.label30.Text = "F";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label28
            // 
            this.label28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(204, 66);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(16, 25);
            this.label28.TabIndex = 15;
            this.label28.Text = "F";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(204, 35);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(16, 25);
            this.label25.TabIndex = 14;
            this.label25.Text = "F";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble;
            this.tableLayoutPanel4.ColumnCount = 5;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel4.Controls.Add(this.lblColdCycleTemp2, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.lblColdCycleTemp1, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.lblColdCycleTime1, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.lblHotCycleTime1, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.label36, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label37, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label29, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.lblHotCycleTime2, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.lblHotCycleTime3, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.lblHotCycleTime4, 4, 1);
            this.tableLayoutPanel4.Controls.Add(this.lblColdCycleTime2, 2, 2);
            this.tableLayoutPanel4.Controls.Add(this.lblColdCycleTime3, 3, 2);
            this.tableLayoutPanel4.Controls.Add(this.lblColdCycleTime4, 4, 2);
            this.tableLayoutPanel4.Controls.Add(this.lblHotCycleTemp1, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.lblHotCycleTemp2, 2, 3);
            this.tableLayoutPanel4.Controls.Add(this.lblHotCycleTemp3, 3, 3);
            this.tableLayoutPanel4.Controls.Add(this.lblHotCycleTemp4, 4, 3);
            this.tableLayoutPanel4.Controls.Add(this.label41, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label42, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label44, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.label43, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.lblColdCycleTemp4, 4, 4);
            this.tableLayoutPanel4.Controls.Add(this.lblColdCycleTemp3, 3, 4);
            this.tableLayoutPanel4.Controls.Add(this.label31, 0, 4);
            this.tableLayoutPanel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel4.Location = new System.Drawing.Point(35, 25);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 5;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(421, 127);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // lblColdCycleTemp2
            // 
            this.lblColdCycleTemp2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblColdCycleTemp2.AutoSize = true;
            this.lblColdCycleTemp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdCycleTemp2.Location = new System.Drawing.Point(263, 104);
            this.lblColdCycleTemp2.Name = "lblColdCycleTemp2";
            this.lblColdCycleTemp2.Size = new System.Drawing.Size(44, 20);
            this.lblColdCycleTemp2.TabIndex = 31;
            this.lblColdCycleTemp2.Text = "--";
            this.lblColdCycleTemp2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblColdCycleTemp1
            // 
            this.lblColdCycleTemp1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblColdCycleTemp1.AutoSize = true;
            this.lblColdCycleTemp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdCycleTemp1.Location = new System.Drawing.Point(210, 104);
            this.lblColdCycleTemp1.Name = "lblColdCycleTemp1";
            this.lblColdCycleTemp1.Size = new System.Drawing.Size(44, 20);
            this.lblColdCycleTemp1.TabIndex = 29;
            this.lblColdCycleTemp1.Text = "--";
            this.lblColdCycleTemp1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblColdCycleTime1
            // 
            this.lblColdCycleTime1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblColdCycleTime1.AutoSize = true;
            this.lblColdCycleTime1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdCycleTime1.Location = new System.Drawing.Point(210, 55);
            this.lblColdCycleTime1.Name = "lblColdCycleTime1";
            this.lblColdCycleTime1.Size = new System.Drawing.Size(44, 23);
            this.lblColdCycleTime1.TabIndex = 11;
            this.lblColdCycleTime1.Text = "--";
            this.lblColdCycleTime1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblHotCycleTime1
            // 
            this.lblHotCycleTime1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHotCycleTime1.AutoSize = true;
            this.lblHotCycleTime1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotCycleTime1.Location = new System.Drawing.Point(210, 29);
            this.lblHotCycleTime1.Name = "lblHotCycleTime1";
            this.lblHotCycleTime1.Size = new System.Drawing.Size(44, 23);
            this.lblHotCycleTime1.TabIndex = 10;
            this.lblHotCycleTime1.Text = "--";
            this.lblHotCycleTime1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label36
            // 
            this.label36.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(6, 29);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(195, 23);
            this.label36.TabIndex = 2;
            this.label36.Text = "Hot Cycle Time (mins)";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label37
            // 
            this.label37.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(6, 55);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(195, 23);
            this.label37.TabIndex = 3;
            this.label37.Text = "Cold Cycle Time (mins)";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label29
            // 
            this.label29.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(6, 81);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(195, 20);
            this.label29.TabIndex = 12;
            this.label29.Text = "Hot Setpoint (F)";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblHotCycleTime2
            // 
            this.lblHotCycleTime2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHotCycleTime2.AutoSize = true;
            this.lblHotCycleTime2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotCycleTime2.Location = new System.Drawing.Point(263, 29);
            this.lblHotCycleTime2.Name = "lblHotCycleTime2";
            this.lblHotCycleTime2.Size = new System.Drawing.Size(44, 23);
            this.lblHotCycleTime2.TabIndex = 14;
            this.lblHotCycleTime2.Text = "--";
            this.lblHotCycleTime2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblHotCycleTime3
            // 
            this.lblHotCycleTime3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHotCycleTime3.AutoSize = true;
            this.lblHotCycleTime3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotCycleTime3.Location = new System.Drawing.Point(316, 29);
            this.lblHotCycleTime3.Name = "lblHotCycleTime3";
            this.lblHotCycleTime3.Size = new System.Drawing.Size(44, 23);
            this.lblHotCycleTime3.TabIndex = 15;
            this.lblHotCycleTime3.Text = "--";
            this.lblHotCycleTime3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblHotCycleTime4
            // 
            this.lblHotCycleTime4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHotCycleTime4.AutoSize = true;
            this.lblHotCycleTime4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotCycleTime4.Location = new System.Drawing.Point(369, 29);
            this.lblHotCycleTime4.Name = "lblHotCycleTime4";
            this.lblHotCycleTime4.Size = new System.Drawing.Size(46, 23);
            this.lblHotCycleTime4.TabIndex = 16;
            this.lblHotCycleTime4.Text = "--";
            this.lblHotCycleTime4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblColdCycleTime2
            // 
            this.lblColdCycleTime2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblColdCycleTime2.AutoSize = true;
            this.lblColdCycleTime2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdCycleTime2.Location = new System.Drawing.Point(263, 55);
            this.lblColdCycleTime2.Name = "lblColdCycleTime2";
            this.lblColdCycleTime2.Size = new System.Drawing.Size(44, 23);
            this.lblColdCycleTime2.TabIndex = 17;
            this.lblColdCycleTime2.Text = "--";
            this.lblColdCycleTime2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblColdCycleTime3
            // 
            this.lblColdCycleTime3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblColdCycleTime3.AutoSize = true;
            this.lblColdCycleTime3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdCycleTime3.Location = new System.Drawing.Point(316, 55);
            this.lblColdCycleTime3.Name = "lblColdCycleTime3";
            this.lblColdCycleTime3.Size = new System.Drawing.Size(44, 23);
            this.lblColdCycleTime3.TabIndex = 19;
            this.lblColdCycleTime3.Text = "--";
            this.lblColdCycleTime3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblColdCycleTime4
            // 
            this.lblColdCycleTime4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblColdCycleTime4.AutoSize = true;
            this.lblColdCycleTime4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdCycleTime4.Location = new System.Drawing.Point(369, 55);
            this.lblColdCycleTime4.Name = "lblColdCycleTime4";
            this.lblColdCycleTime4.Size = new System.Drawing.Size(46, 23);
            this.lblColdCycleTime4.TabIndex = 18;
            this.lblColdCycleTime4.Text = "--";
            this.lblColdCycleTime4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblHotCycleTemp1
            // 
            this.lblHotCycleTemp1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHotCycleTemp1.AutoSize = true;
            this.lblHotCycleTemp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotCycleTemp1.Location = new System.Drawing.Point(210, 81);
            this.lblHotCycleTemp1.Name = "lblHotCycleTemp1";
            this.lblHotCycleTemp1.Size = new System.Drawing.Size(44, 20);
            this.lblHotCycleTemp1.TabIndex = 20;
            this.lblHotCycleTemp1.Text = "--";
            this.lblHotCycleTemp1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblHotCycleTemp2
            // 
            this.lblHotCycleTemp2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHotCycleTemp2.AutoSize = true;
            this.lblHotCycleTemp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotCycleTemp2.Location = new System.Drawing.Point(263, 81);
            this.lblHotCycleTemp2.Name = "lblHotCycleTemp2";
            this.lblHotCycleTemp2.Size = new System.Drawing.Size(44, 20);
            this.lblHotCycleTemp2.TabIndex = 22;
            this.lblHotCycleTemp2.Text = "--";
            this.lblHotCycleTemp2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblHotCycleTemp3
            // 
            this.lblHotCycleTemp3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHotCycleTemp3.AutoSize = true;
            this.lblHotCycleTemp3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotCycleTemp3.Location = new System.Drawing.Point(316, 81);
            this.lblHotCycleTemp3.Name = "lblHotCycleTemp3";
            this.lblHotCycleTemp3.Size = new System.Drawing.Size(44, 20);
            this.lblHotCycleTemp3.TabIndex = 21;
            this.lblHotCycleTemp3.Text = "--";
            this.lblHotCycleTemp3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblHotCycleTemp4
            // 
            this.lblHotCycleTemp4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHotCycleTemp4.AutoSize = true;
            this.lblHotCycleTemp4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHotCycleTemp4.Location = new System.Drawing.Point(369, 81);
            this.lblHotCycleTemp4.Name = "lblHotCycleTemp4";
            this.lblHotCycleTemp4.Size = new System.Drawing.Size(46, 20);
            this.lblHotCycleTemp4.TabIndex = 23;
            this.lblHotCycleTemp4.Text = "--";
            this.lblHotCycleTemp4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label41
            // 
            this.label41.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(210, 3);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(44, 23);
            this.label41.TabIndex = 24;
            this.label41.Text = "Cy1";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label42
            // 
            this.label42.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(263, 3);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(44, 23);
            this.label42.TabIndex = 25;
            this.label42.Text = "Cy2";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label44
            // 
            this.label44.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(316, 3);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(44, 23);
            this.label44.TabIndex = 27;
            this.label44.Text = "Cy3";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label43
            // 
            this.label43.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(369, 3);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(46, 23);
            this.label43.TabIndex = 26;
            this.label43.Text = "Cy4...";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblColdCycleTemp4
            // 
            this.lblColdCycleTemp4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblColdCycleTemp4.AutoSize = true;
            this.lblColdCycleTemp4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdCycleTemp4.Location = new System.Drawing.Point(369, 104);
            this.lblColdCycleTemp4.Name = "lblColdCycleTemp4";
            this.lblColdCycleTemp4.Size = new System.Drawing.Size(46, 20);
            this.lblColdCycleTemp4.TabIndex = 28;
            this.lblColdCycleTemp4.Text = "--";
            this.lblColdCycleTemp4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblColdCycleTemp3
            // 
            this.lblColdCycleTemp3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblColdCycleTemp3.AutoSize = true;
            this.lblColdCycleTemp3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColdCycleTemp3.Location = new System.Drawing.Point(316, 104);
            this.lblColdCycleTemp3.Name = "lblColdCycleTemp3";
            this.lblColdCycleTemp3.Size = new System.Drawing.Size(44, 20);
            this.lblColdCycleTemp3.TabIndex = 30;
            this.lblColdCycleTemp3.Text = "--";
            this.lblColdCycleTemp3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label31
            // 
            this.label31.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(6, 104);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(195, 20);
            this.label31.TabIndex = 13;
            this.label31.Text = "Cold Setpoint (F)";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSetNumSteps
            // 
            this.lblSetNumSteps.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSetNumSteps.AutoSize = true;
            this.lblSetNumSteps.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSetNumSteps.Location = new System.Drawing.Point(433, 194);
            this.lblSetNumSteps.Name = "lblSetNumSteps";
            this.lblSetNumSteps.Size = new System.Drawing.Size(26, 25);
            this.lblSetNumSteps.TabIndex = 9;
            this.lblSetNumSteps.Text = "--";
            this.lblSetNumSteps.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTBD
            // 
            this.lblTBD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTBD.AutoSize = true;
            this.lblTBD.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTBD.Location = new System.Drawing.Point(324, 194);
            this.lblTBD.Name = "lblTBD";
            this.lblTBD.Size = new System.Drawing.Size(110, 25);
            this.lblTBD.TabIndex = 1;
            this.lblTBD.Text = "NumSteps:";
            this.lblTBD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCSVFileInfo
            // 
            this.lblCSVFileInfo.AutoSize = true;
            this.lblCSVFileInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCSVFileInfo.Location = new System.Drawing.Point(18, 619);
            this.lblCSVFileInfo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCSVFileInfo.Name = "lblCSVFileInfo";
            this.lblCSVFileInfo.Size = new System.Drawing.Size(80, 20);
            this.lblCSVFileInfo.TabIndex = 45;
            this.lblCSVFileInfo.Text = "CSV Info:";
            this.lblCSVFileInfo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblCSVFileInfo.Visible = false;
            // 
            // btnCSVSave
            // 
            this.btnCSVSave.Enabled = false;
            this.btnCSVSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCSVSave.Location = new System.Drawing.Point(528, 539);
            this.btnCSVSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnCSVSave.Name = "btnCSVSave";
            this.btnCSVSave.Size = new System.Drawing.Size(111, 71);
            this.btnCSVSave.TabIndex = 48;
            this.btnCSVSave.Text = "Force CSV File Save";
            this.btnCSVSave.UseVisualStyleBackColor = true;
            this.btnCSVSave.Click += new System.EventHandler(this.btnCSVSave_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1220, 648);
            this.Controls.Add(this.btnCSVSave);
            this.Controls.Add(this.lblCSVFileInfo);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnFill);
            this.Controls.Add(this.lblFirmwareVersion);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.gBoxTemps);
            this.Controls.Add(this.btnControl);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gBoxTherapyState);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thermaquil Clinical User Interface";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.groupBox2.ResumeLayout(false);
            this.gBoxTherapyState.ResumeLayout(false);
            this.gBoxTherapyState.PerformLayout();
            this.gBoxTemps.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnCommPortConnect;
        private System.Windows.Forms.ComboBox cbCommPort;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.GroupBox gBoxTherapyState;
        private System.Windows.Forms.Label lblHotCyclesCount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblSystemStatus;
        private System.Windows.Forms.Button btnDecSteps;
        private System.Windows.Forms.Button btnIncSteps;
        private System.Windows.Forms.Label lblSetPointSteps;
        private System.Windows.Forms.Label lblActualTemperatureSteps;
        private System.Windows.Forms.Button btnDecTime;
        private System.Windows.Forms.Button btnIncTime;
        private System.Windows.Forms.Label lblTimeRemaining;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnControl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblColdCyclesCount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox gBoxTemps;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lblColdSetpointF;
        private System.Windows.Forms.Label lblHotSetpointF;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblInletTempF;
        private System.Windows.Forms.Label lblOutletTempF;
        private System.Windows.Forms.Label lblColdResvTempF;
        private System.Windows.Forms.Label lblHotResvTempF;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblFirmwareVersion;
        private System.Windows.Forms.Button btnFill;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblActualTempF;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label lblColdCycleTime1;
        private System.Windows.Forms.Label lblHotCycleTime1;
        private System.Windows.Forms.Label lblSetNumSteps;
        private System.Windows.Forms.Label lblTBD;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label lblCSVFileInfo;
        private System.Windows.Forms.Button btnStartTreatment;
        private System.Windows.Forms.Button btnSkipCycle;
        private System.Windows.Forms.Button btnCSVSave;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblColdCycleTemp2;
        private System.Windows.Forms.Label lblColdCycleTemp1;
        private System.Windows.Forms.Label lblHotCycleTime2;
        private System.Windows.Forms.Label lblHotCycleTime3;
        private System.Windows.Forms.Label lblHotCycleTime4;
        private System.Windows.Forms.Label lblColdCycleTime2;
        private System.Windows.Forms.Label lblColdCycleTime3;
        private System.Windows.Forms.Label lblColdCycleTime4;
        private System.Windows.Forms.Label lblHotCycleTemp1;
        private System.Windows.Forms.Label lblHotCycleTemp2;
        private System.Windows.Forms.Label lblHotCycleTemp3;
        private System.Windows.Forms.Label lblHotCycleTemp4;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label lblColdCycleTemp4;
        private System.Windows.Forms.Label lblColdCycleTemp3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label lblColdTempMin;
        private System.Windows.Forms.Label lblColdTempMax;
        private System.Windows.Forms.Label lblHotTempMin;
        private System.Windows.Forms.Label lblHotTempMax;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label25;
    }
}

