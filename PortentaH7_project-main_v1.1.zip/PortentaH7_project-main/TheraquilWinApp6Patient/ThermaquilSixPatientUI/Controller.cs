﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ThermaquilSixPatientUI
{
    internal class Controller
    {
        public enum ControllerEvent
        {
            evTimer,
            evCommGood,
            evCommBad,
            evSettingsChanged,
            evPrepareCancelBtnClicked,
            evFillBtnClicked,
            evMoreIntense,
            evLessIntense,
            evReadyToRun,
            evReadyClick,
            evTherapyComplete,
            evSkipCycle,
            evPainLevel10,
            evPainLevel9,
            evPainLevel8,
            evPainLevel7,
            evPainLevel6,
            evPainLevel5,
            evPainLevel4,
            evPainLevel3,
            evPainLevel2,
            evPainLevel1,
            evPainLevel0,
            evForceCSVFileSave
        };

        public enum Cycle
        {
            OFF,
            PREPARING,
            READY,
            HEATING,
            COOLING,
        };

        private GroupBox GBoxSystemStatus;
        public Label LblTimeRemaining { get; private set; }
        private Label LblHotCyclesCount;
        private Label LblColdCyclesCount;
        private Label LblUUT;
        private Label LblHotSetpoint;
        private Label LblColdSetpoint;
        private Label LblCurrentSteps;
        private Label LblActualTempSteps;
        
        private Button BtnControl;
        private Button BtnSettings;
        private Button BtnMoreIntense;
        private Button BtnLessIntense;
        private Button BtnFill;
        private Button BtnStartTreatment;
        private Button BtnSkipCycle;

        public Cycle CycleState { get; private set; }

        public void SetFormControlReferences(GroupBox gBoxSS, Label lblHCR, Label lblCCR, Label lbluut, Label lblTR, Button btnC, Button btnS, 
                                            Label lblHSP, Label lblCSP, Label lblCurrStep, Label lblActSteps, Button btnMS, Button btnLS, Button btnFill,
                                            Button btnStartTreatment, Button btnSkipCycle)
        {
            GBoxSystemStatus = gBoxSS;
            LblTimeRemaining = lblTR;
            LblHotCyclesCount = lblHCR;
            LblColdCyclesCount = lblCCR;
            LblUUT = lbluut;
            BtnControl = btnC;
            BtnSettings = btnS;
            LblHotSetpoint = lblHSP;
            LblColdSetpoint = lblCSP;
            LblCurrentSteps = lblCurrStep;
            LblActualTempSteps = lblActSteps;
            BtnMoreIntense = btnMS;
            BtnLessIntense = btnLS;
            BtnFill = btnFill;
            BtnStartTreatment = btnStartTreatment;
            BtnSkipCycle = btnSkipCycle;
        }

        private Controller() { }
        private static Controller instance = null;
        public static Controller Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Controller();
                }
                return instance;
            }
        }

        private delegate void ServiceEvent(ControllerEvent evt);
        private ServiceEvent SM_Func;
        private uint HotCyclesCount;
        private uint ColdCyclesCount;
        private bool CommOK;

        public void StateMachineInvoke(ControllerEvent evt)
        {
            if ((evt == ControllerEvent.evCommBad) && CommOK)
            {
                CommOK = false;
                UICommBad();
            }
            CSVFile.Instance.Update(evt);
            Console.WriteLine(evt.ToString());
            SM_Func(evt);
        }

        #region USER_INTERFACE
        public void UIIniitialize()
        {
            BtnControl.Text = "Prepare For Therapy";
            BtnControl.Enabled = false;
            BtnFill.Text = "Start Fill";
            BtnFill.Enabled = false;
            GBoxSystemStatus.Enabled = true;
            LblUUT.Text = "Waiting For Communication with Device";
            LblTimeRemaining.Text = "--:--:--";
            LblCurrentSteps.Text = "--";
            LblActualTempSteps.Text = "--";
            LblColdCyclesCount.Text = "--";
            LblHotCyclesCount.Text = "--";
            LblColdSetpoint.Text = "--";
            LblHotSetpoint.Text = "--";
            GBoxSystemStatus.BackColor = System.Drawing.SystemColors.Control;
            BtnSettings.Enabled = true;
            BtnFill.Enabled = false;
            BtnStartTreatment.Visible = false;
            BtnSkipCycle.Visible = false;
            SM_Func = SM_WaitForComm;
            CycleState = Cycle.OFF;
        }

        private void UICancel(bool promptForPain)
        {
            Serial.Instance.SetMode(Serial.SysMode.OFF);
            CycleState = Cycle.OFF;
            BtnControl.Text = "Prepare For Therapy";
            LblUUT.Text = "User Cancelled Therapy";
            LblUUT.Visible = true;
            LblTimeRemaining.Text = "--:--:--";
            LblCurrentSteps.Text = "--";
            LblActualTempSteps.Text = "--";
            LblColdCyclesCount.Text = "--";
            LblHotCyclesCount.Text = "--";
            LblColdSetpoint.Text = "--";
            LblHotSetpoint.Text = "--";
            BtnMoreIntense.Text = "--";
            BtnLessIntense.Text = "--";
            BtnSkipCycle.Visible = false;
            BtnFill.Enabled = true;
            BtnStartTreatment.Visible = false;
            GBoxSystemStatus.BackColor = System.Drawing.SystemColors.Control;
            BtnSettings.Enabled = true;
            if (promptForPain)
            {
                GetCurrentPainLevel();
                SM_Func = SM_PainEnd;
            }
            else
            {
                SM_Func = SM_Prepare;
            }

        }

        private void UIComplete()
        {
            GBoxSystemStatus.BackColor = System.Drawing.Color.Green;
            LblUUT.Text = "Therapy Complete!";
            LblUUT.Visible = true;
            CSVFile.Instance.Update(ControllerEvent.evTherapyComplete);
            SM_Func = SM_Prepare;
            BtnControl.Text = "Prepare For Therapy";
            LblTimeRemaining.Text = "--:--:--";
            LblCurrentSteps.Text = "--";
            LblActualTempSteps.Text = "--";
            LblColdCyclesCount.Text = "--";
            LblHotCyclesCount.Text = "--";
            LblColdSetpoint.Text = "--";
            LblHotSetpoint.Text = "--";
            BtnMoreIntense.Text = "--";
            BtnLessIntense.Text = "--";
            BtnSkipCycle.Visible = false;
            BtnSettings.Enabled = true;
            BtnFill.Enabled = true;
        }

        private void UICommBad()
        {
            GBoxSystemStatus.BackColor = System.Drawing.SystemColors.Control;
            LblUUT.Text = "Lost COMM with Device!";
            LblUUT.Visible = true;
            BtnControl.Enabled = false;
            BtnControl.Text = "Prepare For Therapy";
            LblTimeRemaining.Text = "--:--:--";
            LblCurrentSteps.Text = "--";
            LblActualTempSteps.Text = "--";
            LblColdCyclesCount.Text = "--";
            LblHotCyclesCount.Text = "--";
            LblColdSetpoint.Text = "--";
            LblHotSetpoint.Text = "--";
            BtnMoreIntense.Text = "--";
            BtnLessIntense.Text = "--";
            BtnSkipCycle.Visible = false;
            BtnSettings.Enabled = true;
            BtnFill.Enabled = false;
            BtnStartTreatment.Visible = false;
            Serial.Instance.LostComm();
            CycleState = Cycle.OFF;
            SM_Func = SM_WaitForComm;
        }
        #endregion USER_INTERFACE

        #region PAIN_LEVEL

        int PainLevel;
        private void GetCurrentPainLevel()
        {
            PainLevel = -1;
            using (var form = new PainForm())
            {

                var result = form.ShowDialog();
                PainLevel = form.PainLevel;
                ControllerEvent evt = ConvertPainLevelToEvent();
                CSVFile.Instance.Update(evt);
            }

        }

        private ControllerEvent ConvertPainLevelToEvent()
        {
            ControllerEvent evt;

            switch (PainLevel)
            {
                default:
                case 10:
                    evt = ControllerEvent.evPainLevel10;
                    break;
                case 9:
                    evt = ControllerEvent.evPainLevel9;
                    break;
                case 8:
                    evt = ControllerEvent.evPainLevel8;
                    break;
                case 7:
                    evt = ControllerEvent.evPainLevel7;
                    break;
                case 6:
                    evt = ControllerEvent.evPainLevel6;
                    break;
                case 5:
                    evt = ControllerEvent.evPainLevel5;
                    break;
                case 4:
                    evt = ControllerEvent.evPainLevel4;
                    break;
                case 3:
                    evt = ControllerEvent.evPainLevel3;
                    break;
                case 2:
                    evt = ControllerEvent.evPainLevel2;
                    break;
                case 1:
                    evt = ControllerEvent.evPainLevel1;
                    break;
                case 0:
                    evt = ControllerEvent.evPainLevel0;
                    break;
            }

            return evt;
        }
        #endregion PAIN_LEVEL

        private void PrepareForColdCycle()
        {
            SM_Func = SM_ColdCycle;
            GBoxSystemStatus.BackColor = System.Drawing.Color.LightBlue;
            if (ColdCyclesCount < 3)
            {
                TimeRemainSecs = (uint)MySettings.Instance.ColdCycleTimeMins[ColdCyclesCount] * 60;
            }
            else
            {
                TimeRemainSecs = (uint)MySettings.Instance.ColdCycleTimeMins[3] * 60;
            }

            LblUUT.Text = "Cold Cycle";
            BtnMoreIntense.Text = "More Cold";
            BtnLessIntense.Text = "Less Cold";
            BtnSkipCycle.Text = "Skip Cold Cycle";
            UpdateBtnIntenseAttributes(true, true);

            UpdateTimeRemaining();
            LblHotCyclesCount.Text = HotCyclesCount.ToString();
            Serial.Instance.SetMode(Serial.SysMode.COOLING);
            CycleState = Cycle.COOLING;
            LblCurrentSteps.Text = ConvertTempToSteps(ColdSetPoint);
        }
        private void PrepareForHotCycle()
        {
            LblHotCyclesCount.Text = HotCyclesCount.ToString();
            LblColdCyclesCount.Text = ColdCyclesCount.ToString();
            GBoxSystemStatus.BackColor = System.Drawing.Color.IndianRed;
            SM_Func = SM_HotCycle;
            LblUUT.Text = "Hot Cycle";
            BtnMoreIntense.Text = "More Hot";
            BtnLessIntense.Text = "Less Hot";
            BtnSkipCycle.Text = "Skip Hot Cycle";
            UpdateBtnIntenseAttributes(true, true);

            GetSetpointsFromSettings(HotCyclesCount);
            SendSetpointsToDevice();

            if (HotCyclesCount < 3)
            {
                TimeRemainSecs = (uint)MySettings.Instance.HotCycleTimeMins[HotCyclesCount] * 60;
            }
            else
            {
                TimeRemainSecs = (uint)MySettings.Instance.HotCycleTimeMins[3] * 60;
            }

            UpdateTimeRemaining();
            Serial.Instance.SetMode(Serial.SysMode.HEATING);
            CycleState = Cycle.HEATING;
            LblCurrentSteps.Text = ConvertTempToSteps(HotSetPoint);
        }

        #region STATE_MACHINE
        private void SM_WaitForComm(ControllerEvent evt)
        {
            if (evt == ControllerEvent.evCommGood)
            {
                Serial.Instance.Flush();
                BtnControl.Enabled = true;
                SM_Func = SM_Prepare;
                LblUUT.Text = "Click \"Prepare For Therapy\" button";
                Serial.Instance.SetMode(Serial.SysMode.OFF);
                Console.WriteLine("Set Mode 1");
                BtnFill.Enabled = true;
                CommOK = true;
            }
            else if (evt == ControllerEvent.evCommBad)
            {
                Serial.Instance.GetVersion();
            }
        }

        private void SM_Filling(ControllerEvent evt)
        {
            if (evt == ControllerEvent.evTimer)
            {
                GetTemperatures();
            }
            else if (evt == ControllerEvent.evFillBtnClicked)
            {
                BtnControl.Enabled = true;
                BtnFill.Text = "Start Fill";
                Serial.Instance.Fill(false);
                SM_Func = SM_Prepare;
            }
        }

        private void SM_Prepare(ControllerEvent evt)
        {
            if (evt == ControllerEvent.evPrepareCancelBtnClicked)
            {
                GBoxSystemStatus.BackColor = System.Drawing.SystemColors.Control;
                BtnSettings.Enabled = false;
                BtnFill.Enabled = false;
                BtnControl.Text = "Cancel Therapy";
                LblUUT.Text = "Preparing...";

                Serial.Instance.SetMode(Serial.SysMode.PREPARING);//
                CycleState = Cycle.PREPARING;//

                HotCyclesCount = 0;
                ColdCyclesCount = 0;

                GetSetpointsFromSettings(HotCyclesCount);

                /* Send the setpoints and set the step size in degrees F */
                SendSetpointsToDevice();//
                CalcStepSizeDegreesF();//

                SM_Func = SM_WaitingForSystemReady;
            }
            else if (evt == ControllerEvent.evTimer)
            {
                GetTemperatures();
            }
            else if (evt == ControllerEvent.evFillBtnClicked)
            {
                BtnControl.Enabled = false;
                BtnFill.Text = "End Fill";
                Serial.Instance.Fill(true);
                SM_Func = SM_Filling;
            }
        }

        private void SM_WaitingForSystemReady(ControllerEvent evt)
        {
            if (evt == ControllerEvent.evPrepareCancelBtnClicked)
            {
                UICancel(false);
            }
            else if (evt == ControllerEvent.evReadyToRun)
            {
                GBoxSystemStatus.BackColor = System.Drawing.Color.Green;
                SM_Func = SM_WaitForReadyClick;
                LblUUT.Text = "System Ready";
                BtnStartTreatment.Visible = true;
                CycleState = Cycle.READY;
            }
            else if (evt == ControllerEvent.evTimer)
            {
                GetTemperatures();
                CheckForTemperaturesReady();
            }
        }

        private void SM_WaitForReadyClick(ControllerEvent evt)
        {
            if (evt == ControllerEvent.evPrepareCancelBtnClicked)
            {
                UICancel(false);
            }
            else if (evt == ControllerEvent.evReadyClick)
            {
                SM_Func = SM_PainBegin;
                GetCurrentPainLevel();
            }
            else if (evt == ControllerEvent.evTimer)
            {
                GetTemperatures();
            }
        }

        private void SM_PainBegin(ControllerEvent evt)
        {
            if (evt == ControllerEvent.evPrepareCancelBtnClicked)
            {
                UICancel(false);
            }
            else if (evt == ControllerEvent.evTimer)
            {
                GetTemperatures();
                if (PainLevel != -1)
                {
                    BtnStartTreatment.Visible = false;
                    GBoxSystemStatus.BackColor = System.Drawing.Color.IndianRed;
                    BtnSkipCycle.Visible = true;
                    SM_Func = SM_HotCycle;
                    LblUUT.Visible = false;

                    PrepareForHotCycle();
                }
            }
        }

        private void SM_HotCycle(ControllerEvent evt)
        {
            if (evt == ControllerEvent.evPrepareCancelBtnClicked)
            {
                UICancel(true);
            }
            else if (evt == ControllerEvent.evTimer)
            {
                GetTemperatures();
                if (TimeRemainSecs > 0)
                {
                    TimeRemainSecs--;
                    UpdateTimeRemaining();
                }
                else
                {
                    HotCyclesCount++;
                    PrepareForColdCycle();
                }
            }
            else if (evt == ControllerEvent.evSkipCycle)
            {
                HotCyclesCount++;
                PrepareForColdCycle();
            }
            else if (evt == ControllerEvent.evMoreIntense)
            {
                UpdateHotSetpoint(1);
                LblCurrentSteps.Text = ConvertTempToSteps(HotSetPoint);
            }
            else if (evt == ControllerEvent.evLessIntense)
            {
                UpdateHotSetpoint(-1);
                LblCurrentSteps.Text = ConvertTempToSteps(HotSetPoint);
            }
        }
        private void SM_ColdCycle(ControllerEvent evt)
        {
            if (evt == ControllerEvent.evPrepareCancelBtnClicked)
            {
                UICancel(true);
            }
            else if (evt == ControllerEvent.evTimer)
            {
                GetTemperatures();
                if (TimeRemainSecs > 0)
                {
                    TimeRemainSecs--;
                    UpdateTimeRemaining();
                }
                else
                {
                    ColdCyclesCount++;
                    PrepareForHotCycle();
                }
            }
            else if (evt == ControllerEvent.evSkipCycle)
            {
                ColdCyclesCount++;
                PrepareForHotCycle();
            }
            else if (evt == ControllerEvent.evMoreIntense)
            {
                UpdateColdSetpoint(-1);
                LblCurrentSteps.Text = ConvertTempToSteps(ColdSetPoint);
            }
            else if (evt == ControllerEvent.evLessIntense)
            {
                UpdateColdSetpoint(1);
                LblCurrentSteps.Text = ConvertTempToSteps(ColdSetPoint);
            }
        }

        private void SM_PainEnd(ControllerEvent evt)
        {
            if (evt == ControllerEvent.evPrepareCancelBtnClicked)
            {
                UICancel(false);
            }
            else if (evt == ControllerEvent.evTimer)
            {
                GetTemperatures();
                if (PainLevel != -1)
                {
                    UIComplete();
                }
            }
        }

        #endregion


        #region TIME_REMAINING
        uint TimeRemainSecs;

        public void IncTime()
        {
            TimeRemainSecs += 30;
            UpdateTimeRemaining();
        }

        public void DecTime()
        {
            if (TimeRemainSecs > 30)
            {
                TimeRemainSecs -= 30;
            }
            else if (TimeRemainSecs > 0)
            {
                TimeRemainSecs--;
            }
            UpdateTimeRemaining();
        }

        private void UpdateTimeRemaining()
        {
            LblTimeRemaining.Text = FormatTimeRemaining();
        }

        private string FormatTimeRemaining()
        {
            uint hours = TimeRemainSecs / 3600;
            uint mins = (TimeRemainSecs % 3600) / 60;
            uint secs = (TimeRemainSecs % 3600) % 60;

            string trText = hours.ToString("D2") + ":" + mins.ToString("D2") + ":" + secs.ToString("D2");
            return trText;
        }
        #endregion

        #region TEMPERATURES

        private void GetTemperatures()
        {
            Serial.Instance.GetTemperature(Serial.TempSensor.HOT_RESERVOIR);
            Serial.Instance.GetTemperature(Serial.TempSensor.COLD_RESERVOIR);
            Serial.Instance.GetTemperature(Serial.TempSensor.OUTLET);
            Serial.Instance.GetTemperature(Serial.TempSensor.INLET);
            Serial.Instance.GetTemperature(Serial.TempSensor.ACTUAL);
        }

        private void CheckForTemperaturesReady()
        {
            if (MySettings.Instance.UseShamSettings)
            {
                if ((Serial.Instance.ColdRsvrTemp <= ColdSetPoint + 5) &&
                    (Serial.Instance.ColdRsvrTemp >= ColdSetPoint - 20) &&
                    (Serial.Instance.HotRsvrTemp <= HotSetPoint + 2) &&
                    (Serial.Instance.HotRsvrTemp >= HotSetPoint - 2))
                {
                    StateMachineInvoke(ControllerEvent.evReadyToRun);
                }

            }
            else
            {
                if ((Serial.Instance.ColdRsvrTemp <= ColdSetPoint + 5) &&
                    (Serial.Instance.ColdRsvrTemp >= ColdSetPoint - 5) &&
                    (Serial.Instance.HotRsvrTemp <= HotSetPoint + 2) &&
                    (Serial.Instance.HotRsvrTemp >= HotSetPoint - 2))
                {
                    StateMachineInvoke(ControllerEvent.evReadyToRun);
                }

            }

        }


        private void UpdateHotSetpoint(int steps)
        {
            bool btnMoreEnabled = true;
            bool btnLessEnabled = true;

            HotSetPoint += (steps * HotSetPointIncStepF);
            if (HotSetPoint > HotMax)
            {
                HotSetPoint = HotMax;
                btnMoreEnabled = false;
            }
            if (HotSetPoint < HotMin)
            {
                HotSetPoint = HotMin;
                btnLessEnabled = false;
            }

            UpdateBtnIntenseAttributes(btnMoreEnabled, btnLessEnabled);

            SendSetpointsToDevice();
        }

        private void UpdateColdSetpoint(int steps)
        {
            bool btnMoreEnabled = true;
            bool btnLessEnabled = true;

            ColdSetPoint += (steps * ColdSetPointIncStepF);
            if (ColdSetPoint > ColdMax)
            {
                ColdSetPoint = ColdMax;
                btnLessEnabled = false;
            }
            if (ColdSetPoint < ColdMin)
            {
                ColdSetPoint = ColdMin;
                btnMoreEnabled = false;
            }

            UpdateBtnIntenseAttributes(btnMoreEnabled, btnLessEnabled);

            SendSetpointsToDevice();
        }

        private void UpdateBtnIntenseAttributes(bool btnMoreEnabled, bool btnLessEnabled)
        {
            BtnMoreIntense.Enabled = btnMoreEnabled;
            BtnLessIntense.Enabled = btnLessEnabled;

            if (btnMoreEnabled)
            {
                BtnMoreIntense.BackColor = SystemColors.Control;
            }
            else
            {
                BtnMoreIntense.BackColor = SystemColors.AppWorkspace;
            }
            if (btnLessEnabled)
            {
                BtnLessIntense.BackColor = SystemColors.Control;
            }
            else
            {
                BtnLessIntense.BackColor = SystemColors.AppWorkspace;
            }

        }



        public double ColdSetPoint { get; private set; }
        public double HotSetPoint { get; private set; }

        double ColdSetPointIncStepF;
        double HotSetPointIncStepF;


        private void GetSetpointsFromSettings(uint cycle)
        {
            bool useSham = MySettings.Instance.UseShamSettings;

            if (cycle > 3)
            {
                cycle = 3;
            }

            if (useSham)
            {
                ColdSetPoint = MySettings.Instance.ShamColdSetpoint[cycle];
                HotSetPoint = MySettings.Instance.ShamHotSetpoint[cycle];
            }
            else
            {
                ColdSetPoint = MySettings.Instance.ActiveColdSetpoint[cycle];
                HotSetPoint = MySettings.Instance.ActiveHotSetpoint[cycle];
            }
        }

        double ColdMax;
        double ColdMin;
        double HotMax;
        double HotMin;

        private void CalcStepSizeDegreesF()
        {
            bool useSham = MySettings.Instance.UseShamSettings;

            ColdMax = useSham ? MySettings.Instance.ShamColdMaxF : MySettings.Instance.ActiveColdMaxF;
            ColdMin = useSham ? MySettings.Instance.ShamColdMinF : MySettings.Instance.ActiveColdMinF;
            HotMax = useSham ? MySettings.Instance.ShamHotMaxF : MySettings.Instance.ActiveHotMaxF;
            HotMin = useSham ? MySettings.Instance.ShamHotMinF : MySettings.Instance.ActiveHotMinF;

            ColdSetPointIncStepF = ((ColdMax - ColdMin) / (MySettings.Instance.NumberOfSteps));
            HotSetPointIncStepF = ((HotMax - HotMin) / (MySettings.Instance.NumberOfSteps));
        }


        private void SendSetpointsToDevice()
        {
            Serial.Instance.HotSetpoint(HotSetPoint);
            Serial.Instance.ColdSetpoint(ColdSetPoint);

            LblHotSetpoint.Text = HotSetPoint.ToString("F2");
            LblColdSetpoint.Text = ColdSetPoint.ToString("F2");
        }


        public string ConvertTempToSteps(double actualTemp)
        {
            string str = null;
            bool sham = MySettings.Instance.UseShamSettings;
            double max = 0.0;
            double min = 0.0;
            double setpointStep = 1.0;
            bool exeAlgorithm = false;
            if (CycleState == Cycle.PREPARING)
            {
                str = "--";
            }
            else if (CycleState == Cycle.COOLING)
            {
                // Get cool setpoint
                max = ColdMax;
                min = ColdMin;
                setpointStep = ColdSetPointIncStepF;
                exeAlgorithm = true;

            }
            else if (CycleState == Cycle.HEATING)
            {
                max = HotMax;
                min = HotMin;
                setpointStep = HotSetPointIncStepF;
                exeAlgorithm = true;
            }

            if (exeAlgorithm)
            {
                // Get number of steps
                if ( ((actualTemp < min) && (CycleState == Cycle.HEATING)) ||
                     ((actualTemp > max) && (CycleState == Cycle.COOLING)) )
                {
                    str = "< 0";
                }
                else if ( ((actualTemp > max) && (CycleState == Cycle.HEATING)) ||
                          ((actualTemp < min) && (CycleState == Cycle.COOLING)))
                {
                    str = "> " + MySettings.Instance.NumberOfSteps;
                }
                else
                {
                    // Create lookup array based on steps 
                    double[] lookupTemp = new double[MySettings.Instance.NumberOfSteps];
                    double halfStep = setpointStep / 2;
                    if (CycleState == Cycle.HEATING)
                    {
                        lookupTemp[0] = min + halfStep;
                        for (uint i = 1; i < lookupTemp.Length; i++)
                        {
                            lookupTemp[i] = lookupTemp[i - 1] + setpointStep;
                        }
                        for (uint i = 0; i < lookupTemp.Length; i++)
                        {
                            if (actualTemp <= lookupTemp[i])
                            {
                                str = i.ToString();
                                break;
                            }
                        }
                    }
                    else if (CycleState == Cycle.COOLING)
                    {
                        lookupTemp[0] = max - halfStep;
                        for (uint i = 1; i < lookupTemp.Length; i++)
                        {
                            lookupTemp[i] = lookupTemp[i - 1] - setpointStep;
                        }
                        for (uint i = 0; i < lookupTemp.Length; i++)
                        {
                            if (actualTemp >= lookupTemp[i])
                            {
                                str = i.ToString();
                                break;
                            }
                        }
                    }

                    if (str == null)
                    {
                        str = MySettings.Instance.NumberOfSteps.ToString();
                    }
                }
            }
            return str;
        }


        #endregion

    }
}
