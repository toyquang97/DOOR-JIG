﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace ThermaquilSixPatientUI
{
    internal class CSVFile
    {
        private enum CSVState
        {
            INIT,
            LOGGING
        }

        private readonly string CSV_FILE_DIRECTORY = @"C:\ProgramData\Thermaquil\SixPatientUI";
        private string FileName;
        private Label LblCsvFileInfo;
        private Button BtnCsvSave;

        private CSVState CsvState;


        private CSVFile() { }
        private static CSVFile instance = null;
        public static CSVFile Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new CSVFile();
                }
                return instance;
            }
        }

        public void CreateNewFile()
        {
            CreateStorageDirectory();
            CreateFileName();
            AddSettings();
        }

        // Constructor creates the new CSV file
        public void Init(Label lblCsvFileInfo, Button btnSave)
        {
            LblCsvFileInfo = lblCsvFileInfo;
            BtnCsvSave = btnSave;
        }

        private void WriteToFile(String text)
        {
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(FileName, true))
            {
                file.WriteLine(text);
            }
        }

        private void CreateFileName()
        {
            FileName = CSV_FILE_DIRECTORY + @"\" + DateTime.Now.ToString("yyyy-MM-dd__HH-mm-ss") + ".csv";
        }

        private void CreateStorageDirectory()
        {
            if (!Directory.Exists(CSV_FILE_DIRECTORY))
            {
                Directory.CreateDirectory(CSV_FILE_DIRECTORY);
            }
        }

        private void AddSettings()
        {
            StringBuilder csvString = new StringBuilder();
            csvString.Append("AppVersion,FirmwareVersion,NumberOfSteps,ShamActive," +
                             "ShamHotMaxF,ShamHotMinF,ShamColdMaxF,ShamColdMinF,ActiveHotMaxF,ActiveHotMinF,ActiveColdMaxF,ActiveColdMinF," +
                             "HotCycle1Mins,HotCycle2Mins,HotCycle3Mins,HotCycle4Mins," +
                             "ColdCycle1Mins,ColdCycle2Mins,ColdCycle3Mins,ColdCycle4Mins," +
                             "ShamHotSetPoint1,ShamHotSetPoint2,ShamHotSetPoint3,ShamHotSetPoint4," +
                             "ShamColdSetPoint1,ShamColdSetPoint2,ShamColdSetPoint3,ShamColdSetPoint4," +
                             "ActiveHotSetPoint1,ActiveHotSetPoint2,ActiveHotSetPoint3,ActiveHotSetPoint4," +
                             "ActiveColdSetPoint1,ActiveColdSetPoint2,ActiveColdSetPoint3,ActiveColdSetPoint4");
            WriteToFile(csvString.ToString());

            csvString.Clear();
            csvString.Append(Form1.AppVersion + "," +
                            Serial.Instance.FirmwareVersion + "," +
                            MySettings.Instance.NumberOfSteps.ToString() + "," +
                            MySettings.Instance.UseShamSettings.ToString() + "," +
                            MySettings.Instance.ShamHotMaxF.ToString() + "," +
                            MySettings.Instance.ShamHotMinF.ToString() + "," +
                            MySettings.Instance.ShamColdMaxF.ToString() + "," +
                            MySettings.Instance.ShamColdMinF.ToString() + "," +
                            MySettings.Instance.ActiveHotMaxF.ToString() + "," +
                            MySettings.Instance.ActiveHotMinF.ToString() + "," +
                            MySettings.Instance.ActiveColdMaxF.ToString() + "," +
                            MySettings.Instance.ActiveColdMinF.ToString() + ",");

            for (int i = 0; i < 4; i++)
            {
                csvString.Append(MySettings.Instance.HotCycleTimeMins[i].ToString() + ",");
            }
            for (int i = 0; i < 4; i++)
            {
                csvString.Append(MySettings.Instance.ColdCycleTimeMins[i].ToString() + ",");
            }
            for (int i = 0; i < 4; i++)
            {
                csvString.Append(MySettings.Instance.ShamHotSetpoint[i].ToString() + ",");
            }
            for (int i = 0; i < 4; i++)
            {
                csvString.Append(MySettings.Instance.ShamColdSetpoint[i].ToString() + ",");
            }
            for (int i = 0; i < 4; i++)
            {
                csvString.Append(MySettings.Instance.ActiveHotSetpoint[i].ToString() + ",");
            }
            for (int i = 0; i < 4; i++)
            {
                csvString.Append(MySettings.Instance.ActiveColdSetpoint[i].ToString());
                if (i != 3)
                {
                    csvString.Append(",");
                }
            }

            WriteToFile(csvString.ToString());

            csvString.Clear();
            csvString.Append("Time,Event,CycleTimeRemaining,Cycle,HotResvTempF,ColdResvTempF,OutletTempF,InletTempF,ActualTempF,HotSetpointF,ColdSetpointF");
            WriteToFile(csvString.ToString());
        }

        public void Update (Controller.ControllerEvent evt)
        {
            switch (CsvState)
            {
                case CSVState.INIT:
                    if (evt == Controller.ControllerEvent.evCommGood)
                    {
                        // Open new file
                        CreateNewFile();
                        BtnCsvSave.Enabled = true;
                        LblCsvFileInfo.Visible = true;
                        CsvState = CSVState.LOGGING;
                        SampleVarValues(evt);
                    }
                    break;

                case CSVState.LOGGING:
                    if ((evt == Controller.ControllerEvent.evCommBad) || (evt == Controller.ControllerEvent.evForceCSVFileSave) || 
                        (evt == Controller.ControllerEvent.evSettingsChanged))
                    {
                        SampleVarValues(evt);
                        BtnCsvSave.Enabled = false;
                        LblCsvFileInfo.Text = "Software SAVED " + FileName;
                        LblCsvFileInfo.ForeColor = System.Drawing.Color.Green;
                        FileClose();
                        CsvState = CSVState.INIT;
                    }
                    else if (evt == Controller.ControllerEvent.evCommGood)
                    {
                        LblCsvFileInfo.Text = "Software UPDATING " + FileName;
                        LblCsvFileInfo.ForeColor = System.Drawing.Color.Blue;
                    }
                    else 
                    {
                        // Log all other events
                        SampleVarValues(evt);
                    }
                    break;
            }
        }

        private void FileClose()
        {
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(FileName, true))
            {
                file.Close();
            }
        }

        private void SampleVarValues(Controller.ControllerEvent evt)
        {
            // Same as timer event, so filter it
            StringBuilder csvString = new StringBuilder();
            string sampleTime = DateTime.Now.ToString("HH:mm:ss:fff");
            csvString.Append(sampleTime + ",");
            csvString.Append(evt.ToString() + ",");
            csvString.Append(Controller.Instance.LblTimeRemaining.Text + ",");
            csvString.Append(Controller.Instance.CycleState.ToString() + ",");
            csvString.Append(Serial.Instance.HotRsvrTemp.ToString("F2") + ",");
            csvString.Append(Serial.Instance.ColdRsvrTemp.ToString("F2") + ",");
            csvString.Append(Serial.Instance.OutletTemp.ToString("F2") + ",");
            csvString.Append(Serial.Instance.InletTemp.ToString("F2") + ",");
            csvString.Append(Serial.Instance.ActualTemp.ToString("F2") + ",");
            csvString.Append(Controller.Instance.HotSetPoint.ToString("F2") + ",");
            csvString.Append(Controller.Instance.ColdSetPoint.ToString("F2"));

            WriteToFile(csvString.ToString());
        }

    }
}