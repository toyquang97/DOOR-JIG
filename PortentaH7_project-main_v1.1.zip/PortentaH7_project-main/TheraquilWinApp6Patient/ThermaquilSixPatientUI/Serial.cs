﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace ThermaquilSixPatientUI
{
    internal class Serial
    {
        private enum CommandList
        {
            HOT_SETPOINT,
            COLD_SETPOINT,
            VERSION,
            MODE,
            TEMP_HOT_RSVR,
            TEMP_COLD_RSVR,
            TEMP_OUTLET,
            TEMP_INLET,
            TEMP_ACTUAL,
            UPDATE_FIRMWARE_WDOG,
            
            EMPTY,
        }

        public enum SysMode
        {
            OFF = 1,
            PREPARING = 2,
            HEATING = 3,
            COOLING = 4,
        }

        public enum TempSensor
        {
            HOT_RESERVOIR = 1,
            COLD_RESERVOIR = 2,
            OUTLET = 3,
            INLET = 4, 
            ACTUAL = 5,
        }

        // C# .NET serial port
        private SerialPort serial;

        // Serial receive buffer
        private char []RxBuffer = new char [1000];
        // Read index of serial receive buffer
        private uint RxReadIndex;
        // Labels to update on main form when data receievd from UUT
        private Label lblHotRsvrTemp;
        private Label lblColdRsvrTemp;
        private Label lblOutletTemp;
        private Label lblInletTemp;
        private Label lblActualTempF;
        private Label lblActualTempSteps;
        private Label lblVersion;

        // Allows multiple commands to be queued while waiting for a response
        private Queue<string> OutgoingCmdQueue = new Queue<string>();

        // Serial received character count, used for watchdog check
        public uint RxByteCount { get; private set; }

        // Becomes true if command sent requires a response
        bool WaitingForUUTResponse = false;

        // Stores the current command so that the response is recognizd (no identifier on response data)
        CommandList CurrentCmd;

        // Require the multi-parameter constructior 
        private Serial() { }
        private static Serial instance = null;
        public static Serial Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Serial();
                }
                return instance;
            }
        }
        public void Init(string comPort, Label lblTmpHotRsvr, Label lblTmpColdRsvr, Label lblTmpOutlet, Label lblTmpInlet, Label lblActTemp,
                                         Label lblActSteps, Label lblV)
        {
            serial = new SerialPort(comPort, 115200, Parity.None, 8, StopBits.One);
            serial.Open();
            serial.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
            // Allow this object to update temperatures on the main form
            lblHotRsvrTemp = lblTmpHotRsvr;
            lblColdRsvrTemp = lblTmpColdRsvr;
            lblOutletTemp = lblTmpOutlet;
            lblInletTemp = lblTmpInlet;
            lblActualTempF = lblActTemp;
            lblActualTempSteps = lblActSteps;
            lblVersion = lblV;
        }

        // Set the hot setpoint
        public void HotSetpoint(double sp)
        {
            string str = "A " + sp.ToString("F4") + " \r";
            OutgoingCmdQueue.Enqueue(str);
            ServiceQueue();
        }

        // Set the cold setpoint
        public void ColdSetpoint(double sp)
        {
            string str = "B " + sp.ToString("F4") + " \r";
            OutgoingCmdQueue.Enqueue(str);
            ServiceQueue();
        }

        // Set the mode
        public void SetMode(SysMode mode)
        {
            uint m = (uint)mode;
            string str = "M " + m.ToString() + " \r";
            OutgoingCmdQueue.Enqueue(str);
            ServiceQueue();
        }


        // Get the desired temperture
        public void GetTemperature (TempSensor tempSensor)
        {
            uint ts = (uint)tempSensor;
            string str = "D " + ts.ToString() + " \r";
            OutgoingCmdQueue.Enqueue(str);
            ServiceQueue();
        }

        // Get the firmware version
        public void GetVersion()
        {
            string str = "V \r";
            OutgoingCmdQueue.Enqueue(str);
            ServiceQueue();
        }

        public void UpdateFirmwareWatchdog()
        {
            string str = "W \r";
            OutgoingCmdQueue.Enqueue(str);
            ServiceQueue();
        }

        // Flush the command queue... user cancels treatment or loss of COMM
        public bool Flush()
        {
            OutgoingCmdQueue.Clear();
            WaitingForUUTResponse = false;
            RxReadIndex = 0;
            return false;
        }

        public void Fill (bool fill)
        {
            string arg = fill ? "1" : "0";
            string str = "F " + arg + " \r";
            OutgoingCmdQueue.Enqueue(str);
            ServiceQueue();
        }


        public void LostComm()
        {
            lblHotRsvrTemp.Text = "--";
            lblColdRsvrTemp.Text = "--";
            lblOutletTemp.Text = "--";
            lblInletTemp.Text = "--";
            lblActualTempF.Text = "--";
            lblActualTempSteps.Text = "--";
            lblVersion.Text = "--";
        }

        private void ServiceQueue()
        {
            // Check if there is a command in the queue and we're not waiting for a response from the 
            // previous command just sent
            if (!WaitingForUUTResponse && (OutgoingCmdQueue.Count != 0))
            {
                string  str = OutgoingCmdQueue.Peek();
                SetCurrentCommand(str);
                try
                {
                    serial.Write(str);
                    // Used for debug
                    //TODO Console.WriteLine("TX: " + str);
                }
                catch
                {
                    Controller.Instance.StateMachineInvoke(Controller.ControllerEvent.evCommBad);
                }

                OutgoingCmdQueue.Dequeue();
            }
        }

        private void SetCurrentCommand(string cmd)
        {
            if (cmd[0] == 'D')
            {
                WaitingForUUTResponse = true;
                switch (cmd[2])
                {
                    case '1':
                        CurrentCmd = CommandList.TEMP_HOT_RSVR;
                        break;
                    case '2':
                        CurrentCmd = CommandList.TEMP_COLD_RSVR;
                        break;
                    case '3':
                        CurrentCmd = CommandList.TEMP_OUTLET;
                        break;
                    case '4':
                        CurrentCmd = CommandList.TEMP_INLET;
                        break;
                    case '5':
                        CurrentCmd = CommandList.TEMP_ACTUAL;
                        break;
                }
            }
            else if (cmd[0] == 'V')
            {
                // Intentionally don't do this so "V" keeps occurring
                // WaitingForUUTResponse = true;
                CurrentCmd = CommandList.VERSION;
            }
        }


        // Occurs on a seperate thread (not on UI), therefore any updates to
        // UI objects (in ProcessResponse()) need to use method invoke
        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            int rxByteCount = sp.BytesToRead;

            while (rxByteCount != 0)
            {
                RxByteCount++;
                int rx = sp.ReadByte();
                RxBuffer[RxReadIndex] = (char)rx;
                if (rx == '\r')
                {
                    RxBuffer[RxReadIndex + 1] = '\0';
                    ProcessResponse();
                }
                else
                {
                    RxReadIndex++;
                }
                rxByteCount--;
            }
        }

        private void WriteBytes(Byte[] txData, UInt16 length)
        {
            serial.Write(txData, 0, length);
        }

        public double HotRsvrTemp { get; private set; }
        public double ColdRsvrTemp { get; private set; }
        public double OutletTemp { get; private set; }
        public double InletTemp { get; private set; }
        public double ActualTemp { get; private set; }
        public string FirmwareVersion { get; private set; }

        private void ProcessResponse()
        {
            // Get the string from the serial data
            string str = new string(RxBuffer).TrimEnd('\0');
            
            // TODO Console.WriteLine("RX: " + str);
            RxReadIndex = 0;
            // Response received so no longer waiting for response
            WaitingForUUTResponse = false;

            List <LabelStrPair> lblStr = new List<LabelStrPair>();
            switch (CurrentCmd)
            {
                case CommandList.TEMP_HOT_RSVR:
                    try
                    {
                        HotRsvrTemp = Convert.ToDouble(str);
                        lblStr.Add(new LabelStrPair(lblHotRsvrTemp, str));
                    }
                    catch
                    { }
                    break;
                case CommandList.TEMP_COLD_RSVR:
                    try
                    {
                        ColdRsvrTemp = Convert.ToDouble(str);
                        lblStr.Add(new LabelStrPair(lblColdRsvrTemp, str));
                    }
                    catch
                    { }
                    break;
                case CommandList.TEMP_OUTLET:
                    try
                    {
                        OutletTemp = Convert.ToDouble(str);
                        lblStr.Add(new LabelStrPair(lblOutletTemp, str));
                    }
                    catch
                    { }
                    break;
                case CommandList.TEMP_INLET:
                    try
                    {
                        InletTemp = Convert.ToDouble(str);
                        lblStr.Add(new LabelStrPair(lblInletTemp, str));
                    }
                    catch
                    { }
                    break;
                case CommandList.TEMP_ACTUAL:
                    try
                    {
                        ActualTemp = Convert.ToDouble(str);
                        lblStr.Add(new LabelStrPair(lblActualTempF, str));


                        str = Controller.Instance.ConvertTempToSteps(ActualTemp);
                        lblStr.Add(new LabelStrPair(lblActualTempSteps, str));

                    }
                    catch
                    { }
                    break;
                case CommandList.VERSION:
                    lblStr.Add(new LabelStrPair(lblVersion, str));
                    // Used in CSV file, so remove the <CR>
                    FirmwareVersion = str.TrimEnd('\r');
                    break;
                default:
                    break;

            }

            // Clear the receive buffer
            for (uint i = 0; i < RxBuffer.Length; i++)
            {
                RxBuffer[i] = '\0';
            }

            UpdateLabels(lblStr);

            ServiceQueue();

        }

        private void UpdateLabels(List<LabelStrPair> lblStr)
        {
            foreach (LabelStrPair ls in lblStr)
            {
                ls.Lbl.Invoke(new Action(() => ls.Lbl.Text = ls.Str));
            }
        }


        private class LabelStrPair
        {
            public Label Lbl;
            public string Str;

            public LabelStrPair(Label l, String s)
            {
                Lbl = l;
                Str = s;
            }

        }


    }
}