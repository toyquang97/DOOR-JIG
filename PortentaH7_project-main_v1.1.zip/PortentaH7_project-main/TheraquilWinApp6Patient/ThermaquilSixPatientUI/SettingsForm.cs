﻿using System;
using System.Windows.Forms;

namespace ThermaquilSixPatientUI
{
    public partial class SettingsForm : Form
    {
        const int UNIQUE_CYCLES = 4;

        NumericUpDown[] nudHotCycleMins = new NumericUpDown[UNIQUE_CYCLES];
        NumericUpDown[] nudColdCycleMins = new NumericUpDown[UNIQUE_CYCLES];
        NumericUpDown[] nudActiveHeatSetpoint = new NumericUpDown[UNIQUE_CYCLES];
        NumericUpDown[] nudActiveColdSetpoint = new NumericUpDown[UNIQUE_CYCLES];
        NumericUpDown[] nudShamHeatSetpoint = new NumericUpDown[UNIQUE_CYCLES];
        NumericUpDown[] nudShamColdSetpoint = new NumericUpDown[UNIQUE_CYCLES];

        public SettingsForm()
        {
            InitializeComponent();
            PopulateArrays();
            LoadControlsWithSavedSettings();
        }

        private void PopulateArrays()
        {
            nudHotCycleMins[0] = nudHotCycle1Mins;
            nudHotCycleMins[1] = nudHotCycle2Mins;
            nudHotCycleMins[2] = nudHotCycle3Mins;
            nudHotCycleMins[3] = nudHotCycle4Mins;

            nudColdCycleMins[0] = nudColdCycle1Mins;
            nudColdCycleMins[1] = nudColdCycle2Mins;
            nudColdCycleMins[2] = nudColdCycle3Mins;
            nudColdCycleMins[3] = nudColdCycle4Mins;

            nudActiveHeatSetpoint[0] = nudActiveCycle1Heat;
            nudActiveHeatSetpoint[1] = nudActiveCycle2Heat;
            nudActiveHeatSetpoint[2] = nudActiveCycle3Heat;
            nudActiveHeatSetpoint[3] = nudActiveCycle4Heat;

            nudActiveColdSetpoint[0] = nudActiveCycle1Cold;
            nudActiveColdSetpoint[1] = nudActiveCycle2Cold;
            nudActiveColdSetpoint[2] = nudActiveCycle3Cold;
            nudActiveColdSetpoint[3] = nudActiveCycle4Cold;

            nudShamHeatSetpoint[0] = nudShamCycle1Heat;
            nudShamHeatSetpoint[1] = nudShamCycle2Heat;
            nudShamHeatSetpoint[2] = nudShamCycle3Heat;
            nudShamHeatSetpoint[3] = nudShamCycle4Heat;

            nudShamColdSetpoint[0] = nudShamCycle1Cold;
            nudShamColdSetpoint[1] = nudShamCycle2Cold;
            nudShamColdSetpoint[2] = nudShamCycle3Cold;
            nudShamColdSetpoint[3] = nudShamCycle4Cold;
        }

        private void LoadControlsWithSavedSettings()
        {
            nudNumOfSteps.Value = Properties.Settings.Default.NumberOfSteps;

            try
            {
                for (int i = 0; i < 4; i++)
                {
                    nudHotCycleMins[i].Value = (decimal)Properties.Settings.Default.HotCycleTimeMins[i];
                    nudColdCycleMins[i].Value = (decimal)Properties.Settings.Default.ColdCycleTimeMins[i];
                    nudActiveHeatSetpoint[i].Value = (decimal)Properties.Settings.Default.ActiveHotSetpoint[i];
                    nudActiveColdSetpoint[i].Value = (decimal)Properties.Settings.Default.ActiveColdSetpoint[i];
                    nudShamHeatSetpoint[i].Value = (decimal)Properties.Settings.Default.ShamHotSetpoint[i];
                    nudShamColdSetpoint[i].Value = (decimal)Properties.Settings.Default.ShamColdSetpoint[i];
                }

            }
            catch
            {
                for (int i = 0; i < 4; i++)
                {
                    nudHotCycleMins[i].Value = (decimal)45;
                    nudColdCycleMins[i].Value = (decimal)15;
                    nudActiveHeatSetpoint[i].Value = (decimal)140;
                    nudActiveColdSetpoint[i].Value = (decimal)15;
                    nudShamHeatSetpoint[i].Value = (decimal)140;
                    nudShamColdSetpoint[i].Value = (decimal)15;
                }
            }

            try
            {
                nudShamColdCycleMax.Value = (decimal)Properties.Settings.Default.ShamColdMaxF;
            }
            catch
            {
                nudShamColdCycleMax.Value = nudShamColdCycleMax.Minimum;
            }
            try
            {
                nudShamColdCycleMin.Value = (decimal)Properties.Settings.Default.ShamColdMinF;
            }
            catch
            {
                nudShamColdCycleMin.Value = nudShamColdCycleMin.Minimum;
            }



            try
            {
                nudShamHotCycleMax.Value = (decimal)Properties.Settings.Default.ShamHotMaxF;
            }
            catch
            {
                nudShamHotCycleMax.Value = nudShamHotCycleMax.Maximum;
            }
            try
            {
                nudShamHotCycleMin.Value = (decimal)Properties.Settings.Default.ShamHotMinF;
            }
            catch
            {
                nudShamHotCycleMin.Value = nudShamHotCycleMin.Maximum;
            }


            try
            {
                nudActiveColdCycleMax.Value = (decimal)Properties.Settings.Default.ActiveColdMaxF;
            }
            catch
            {
                nudActiveColdCycleMax.Value = nudActiveColdCycleMax.Minimum;
            }
            try
            {
                nudActiveColdCycleMin.Value = (decimal)Properties.Settings.Default.ActiveColdMinF;
            }
            catch
            {
                nudActiveColdCycleMin.Value = nudActiveColdCycleMin.Minimum;
            }


            try
            {
                nudActiveHotCycleMax.Value = (decimal)Properties.Settings.Default.ActiveHotMaxF;
            }
            catch
            {
                nudActiveHotCycleMax.Value = nudActiveHotCycleMax.Minimum;
            }
            try
            {
                nudActiveHotCycleMin.Value = (decimal)Properties.Settings.Default.ActiveHotMinF;
            }
            catch
            {
                nudActiveHotCycleMin.Value = nudActiveHotCycleMin.Maximum;
            }


            if (Properties.Settings.Default.UseShamSettings)
            {
                rbSham.Select();
            }
            else
            {
                rbActive.Select();
            }

        }

        private void SetActiveHeatValues()
        {
            for (int i = 0; i < 4; i++)
            {
                nudActiveHeatSetpoint[i].Maximum = nudActiveHotCycleMax.Value;
                nudActiveHeatSetpoint[i].Minimum = nudActiveHotCycleMin.Value;

                if (nudActiveHeatSetpoint[i].Value > nudActiveHotCycleMax.Value)
                {
                    nudActiveHeatSetpoint[i].Value = nudActiveHotCycleMax.Value;
                }
                if (nudActiveHeatSetpoint[i].Value < nudActiveHotCycleMin.Value)
                {
                    nudActiveHeatSetpoint[i].Value = nudActiveHotCycleMin.Value;
                }
            }
        }

        private void SetActiveColdValues()
        {
            for (int i = 0; i < 4; i++)
            {
                nudActiveColdSetpoint[i].Maximum = nudActiveColdCycleMax.Value;
                nudActiveColdSetpoint[i].Minimum = nudActiveColdCycleMin.Value;

                if (nudActiveColdSetpoint[i].Value > nudActiveColdCycleMax.Value)
                {
                    nudActiveColdSetpoint[i].Value = nudActiveColdCycleMax.Value;
                }
                if (nudActiveColdSetpoint[i].Value < nudActiveColdCycleMin.Value)
                {
                    nudActiveColdSetpoint[i].Value = nudActiveColdCycleMin.Value;
                }
            }
        }

        private void SetShamHeatValues()
        {
            for (int i = 0; i < 4; i++)
            {
                nudShamHeatSetpoint[i].Maximum = nudShamHotCycleMax.Value;
                nudShamHeatSetpoint[i].Minimum = nudShamHotCycleMin.Value;

                if (nudShamHeatSetpoint[i].Value > nudShamHotCycleMax.Value)
                {
                    nudShamHeatSetpoint[i].Value = nudShamHotCycleMax.Value;
                }
                if (nudShamHeatSetpoint[i].Value < nudShamHotCycleMin.Value)
                {
                    nudShamHeatSetpoint[i].Value = nudShamHotCycleMin.Value;
                }

            }
        }

        private void SetShamColdValues()
        {
            for (int i = 0; i < 4; i++)
            {
                nudShamColdSetpoint[i].Maximum = nudShamColdCycleMax.Value;
                nudShamColdSetpoint[i].Minimum = nudShamColdCycleMin.Value;

                if (nudShamColdSetpoint[i].Value > nudShamColdCycleMax.Value)
                {
                    nudShamColdSetpoint[i].Value = nudShamColdCycleMax.Value;
                }
                if (nudShamColdSetpoint[i].Value < nudShamColdCycleMin.Value)
                {
                    nudShamColdSetpoint[i].Value = nudShamColdCycleMin.Value;
                }
            }
        }

        private void SaveSettings()
        {
            Properties.Settings.Default.NumberOfSteps = (uint)nudNumOfSteps.Value;
            Properties.Settings.Default.UseShamSettings = rbSham.Checked;
            Properties.Settings.Default.ShamColdMinF = (double)nudShamColdCycleMin.Value;
            Properties.Settings.Default.ShamColdMaxF = (double)nudShamColdCycleMax.Value;
            Properties.Settings.Default.ShamHotMinF = (double)nudShamHotCycleMin.Value;
            Properties.Settings.Default.ShamHotMaxF = (double)nudShamHotCycleMax.Value;
            Properties.Settings.Default.ActiveColdMinF = (double)nudActiveColdCycleMin.Value;
            Properties.Settings.Default.ActiveColdMaxF = (double)nudActiveColdCycleMax.Value;
            Properties.Settings.Default.ActiveHotMinF = (double)nudActiveHotCycleMin.Value;
            Properties.Settings.Default.ActiveHotMaxF = (double)nudActiveHotCycleMax.Value;

            for (int i = 0; i < UNIQUE_CYCLES; i++)
            {
                Properties.Settings.Default.HotCycleTimeMins[i] = (int)nudHotCycleMins[i].Value;
                Properties.Settings.Default.ColdCycleTimeMins[i] = (int)nudColdCycleMins[i].Value;

                Properties.Settings.Default.ActiveHotSetpoint[i] = (int)nudActiveHeatSetpoint[i].Value;
                Properties.Settings.Default.ActiveColdSetpoint[i] = (int)nudActiveColdSetpoint[i].Value;

                Properties.Settings.Default.ShamHotSetpoint[i] = (int)nudShamHeatSetpoint[i].Value;
                Properties.Settings.Default.ShamColdSetpoint[i] = (int)nudShamColdSetpoint[i].Value;
            }

            // Save all settings
            Properties.Settings.Default.Save();
            // Update local copy of settings for subsequent treatments
            MySettings.Instance.Update();

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveSettings();
            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void nudShamHotCycleMax_ValueChanged(object sender, EventArgs e)
        {
            if (nudShamHotCycleMax.Value < nudShamHotCycleMin.Value)
            {
                nudShamHotCycleMin.Value = nudShamHotCycleMax.Value;
            }

            SetShamHeatValues();

        }

        private void nudShamColdCycleMax_ValueChanged(object sender, EventArgs e)
        {
            if (nudShamColdCycleMax.Value < nudShamColdCycleMin.Value)
            {
                nudShamColdCycleMin.Value = nudShamColdCycleMax.Value;
            }

            SetShamColdValues();

        }

        private void nudActiveHotCycleMax_ValueChanged(object sender, EventArgs e)
        {
            if (nudActiveHotCycleMax.Value < nudActiveHotCycleMin.Value)
            {
                nudActiveHotCycleMin.Value = nudActiveHotCycleMax.Value;
            }

            SetActiveHeatValues();
        }

        private void nudActiveColdCycleMax_ValueChanged(object sender, EventArgs e)
        {
            if (nudActiveColdCycleMax.Value < nudActiveColdCycleMin.Value)
            {
                nudActiveColdCycleMin.Value = nudActiveColdCycleMax.Value;
            }

            SetActiveColdValues();
        }

        private void nudShamHotCycleMin_ValueChanged(object sender, EventArgs e)
        {
            if (nudShamHotCycleMin.Value > nudShamHotCycleMax.Value)
            {
                nudShamHotCycleMax.Value = nudShamHotCycleMin.Value;
            }

            SetShamHeatValues();
        }

        private void nudShamColdCycleMin_ValueChanged(object sender, EventArgs e)
        {
            if (nudShamColdCycleMin.Value > nudShamColdCycleMax.Value)
            {
                nudShamColdCycleMax.Value = nudShamColdCycleMin.Value;
            }

            SetShamColdValues();

        }

        private void nudActiveHotCycleMin_ValueChanged(object sender, EventArgs e)
        {
            if (nudActiveHotCycleMin.Value > nudActiveHotCycleMax.Value)
            {
                nudActiveHotCycleMax.Value = nudActiveHotCycleMin.Value;
            }

            SetActiveHeatValues();
        }

        private void nudActiveColdCycleMin_ValueChanged(object sender, EventArgs e)
        {
            if (nudActiveColdCycleMin.Value > nudActiveColdCycleMax.Value)
            {
                nudActiveColdCycleMax.Value = nudActiveColdCycleMin.Value;
            }

            SetActiveColdValues();

        }
    }
}
