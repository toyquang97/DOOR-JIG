﻿using System;
using System.Windows.Forms;
using System.IO.Ports;

namespace ThermaquilSixPatientUI
{
    public partial class Form1 : Form
    {
        public const string AppVersion = "0.32";

        public Form1()
        {
            InitializeComponent();
            if (Properties.Settings.Default.UpgradeRequired)
            {
                Properties.Settings.Default.Upgrade();
                Properties.Settings.Default.UpgradeRequired = false;
                Properties.Settings.Default.Save();
            }


            Size = new System.Drawing.Size(693, 687);
            Text = Text + " (" + AppVersion + ")";
            PopulateCommPortList();
            MySettings.Instance.Update();
            Controller.Instance.SetFormControlReferences(gBoxTherapyState, lblHotCyclesCount, lblColdCyclesCount, 
                                                        lblSystemStatus, lblTimeRemaining, 
                                                        btnControl, btnSettings, lblHotSetpointF, lblColdSetpointF, lblSetPointSteps, lblActualTemperatureSteps,
                                                        btnIncSteps, btnDecSteps, btnFill, btnStartTreatment, btnSkipCycle);

            Controller.Instance.UIIniitialize();
            CSVFile.Instance.Init(lblCSVFileInfo, btnCSVSave);
            lblSystemStatus.Text = "Connect a COM Port";
            // Support "Alt-T" to display temperatures
            KeyPreview = true;
            UpdateHiddenSettings();
        }

        private void cbCommPort_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnCommPortConnect.Enabled = true;
        }

        private void PopulateCommPortList()
        {
            // Remove any existing items in case of a refresh
            cbCommPort.Items.Clear();

            // Populate the comm port list
            String[] commPorts = SerialPort.GetPortNames();
            foreach (String s in commPorts)
            {
                cbCommPort.Items.Add(s);
            }

            // Select the most recent used comm port; user can still change if desired
            string lastUsedCommport = Properties.Settings.Default.LastUsedCommPort;

            int index = Array.IndexOf(commPorts, lastUsedCommport);
            if (index != -1)
            {
                cbCommPort.SelectedIndex = index;
            }
        }



        private void btnCommPortConnect_Click(object sender, EventArgs e)
        {
            CommPortButtonConnect();
        }

        private void CommPortButtonConnect()
        {
            try
            {
                Serial.Instance.Init(cbCommPort.SelectedItem.ToString(), lblHotResvTempF, lblColdResvTempF, lblOutletTempF, lblInletTempF, lblActualTempF, lblActualTemperatureSteps, lblFirmwareVersion);
                Properties.Settings.Default.LastUsedCommPort = cbCommPort.SelectedItem.ToString();
                Properties.Settings.Default.Save();
                cbCommPort.Enabled = false;
                btnCommPortConnect.Visible = false;
                timer1.Enabled = true;
                lblSystemStatus.Text = "Waiting For Communication with Device";
            }
            catch
            {
                MessageBox.Show("Serial Port not available. Please select another or close existing connection",
                                "Serial Port Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            CommWatchDog();
            Controller.Instance.StateMachineInvoke(Controller.ControllerEvent.evTimer);
        }

        uint DeadCnt;
        uint CurrRxByteCnt;
        private void CommWatchDog()
        {
            uint rxByteCnt = Serial.Instance.RxByteCount;

            // This keeps UUT in WinApp mode
            Serial.Instance.UpdateFirmwareWatchdog();
            if (CurrRxByteCnt == rxByteCnt)
            {
                DeadCnt++;
                if (DeadCnt >= 3)
                {
                    Controller.Instance.StateMachineInvoke(Controller.ControllerEvent.evCommBad);
                    Serial.Instance.Flush();
                }
            }
            else
            {
                Controller.Instance.StateMachineInvoke(Controller.ControllerEvent.evCommGood);
                DeadCnt = 0;
            }

            CurrRxByteCnt = rxByteCnt;

        }



        private void btnIncTime_Click(object sender, EventArgs e)
        {
            Controller.Instance.IncTime();
        }

        private void btnDecTime_Click(object sender, EventArgs e)
        {
            Controller.Instance.DecTime();
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            using (var form = new SettingsForm())
            {
                var result = form.ShowDialog();
                if (result == DialogResult.OK)
                {
                    CSVFile.Instance.Update(Controller.ControllerEvent.evSettingsChanged);
                    UpdateHiddenSettings();
                }
            }
        }

        private void btnControl_Click(object sender, EventArgs e)
        {
            Controller.Instance.StateMachineInvoke(Controller.ControllerEvent.evPrepareCancelBtnClicked);
        }


        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Alt && e.KeyCode == Keys.T)       // Alt-T (show hide temps)
            {
                gBoxTemps.Visible = !gBoxTemps.Visible;
                if (gBoxTemps.Visible)
                {
                    Size = new System.Drawing.Size(1240, 691);
                }
                else
                {
                    Size = new System.Drawing.Size(693, 687);
                }
                e.SuppressKeyPress = true;  // Stops other controls on the form receiving event.
            }
        }

        private void btnIncSteps_Click(object sender, EventArgs e)
        {
            Controller.Instance.StateMachineInvoke(Controller.ControllerEvent.evMoreIntense);
        }

        private void btnDecSteps_Click(object sender, EventArgs e)
        {
            Controller.Instance.StateMachineInvoke(Controller.ControllerEvent.evLessIntense);
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            Controller.Instance.StateMachineInvoke(Controller.ControllerEvent.evFillBtnClicked);
        }

        private void UpdateHiddenSettings()
        {
            lblSetNumSteps.Text = MySettings.Instance.NumberOfSteps.ToString();
            lblHotCycleTime1.Text = MySettings.Instance.HotCycleTimeMins[0].ToString();
            lblHotCycleTime2.Text = MySettings.Instance.HotCycleTimeMins[1].ToString();
            lblHotCycleTime3.Text = MySettings.Instance.HotCycleTimeMins[2].ToString();
            lblHotCycleTime4.Text = MySettings.Instance.HotCycleTimeMins[3].ToString();
            lblColdCycleTime1.Text = MySettings.Instance.ColdCycleTimeMins[0].ToString();
            lblColdCycleTime2.Text = MySettings.Instance.ColdCycleTimeMins[1].ToString();
            lblColdCycleTime3.Text = MySettings.Instance.ColdCycleTimeMins[2].ToString();
            lblColdCycleTime4.Text = MySettings.Instance.ColdCycleTimeMins[3].ToString();

            bool useSham = MySettings.Instance.UseShamSettings;

            if (useSham)
            {
                lblHotCycleTemp1.Text = MySettings.Instance.ShamHotSetpoint[0].ToString();
                lblHotCycleTemp2.Text = MySettings.Instance.ShamHotSetpoint[1].ToString();
                lblHotCycleTemp3.Text = MySettings.Instance.ShamHotSetpoint[2].ToString();
                lblHotCycleTemp4.Text = MySettings.Instance.ShamHotSetpoint[3].ToString();

                lblColdCycleTemp1.Text = MySettings.Instance.ShamColdSetpoint[0].ToString();
                lblColdCycleTemp2.Text = MySettings.Instance.ShamColdSetpoint[1].ToString();
                lblColdCycleTemp3.Text = MySettings.Instance.ShamColdSetpoint[2].ToString();
                lblColdCycleTemp4.Text = MySettings.Instance.ShamColdSetpoint[3].ToString();

                lblHotTempMax.Text = MySettings.Instance.ShamHotMaxF.ToString();
                lblHotTempMin.Text = MySettings.Instance.ShamHotMinF.ToString();
                lblColdTempMax.Text = MySettings.Instance.ShamColdMaxF.ToString();
                lblColdTempMin.Text = MySettings.Instance.ShamColdMinF.ToString();
            }
            else
            {
                lblHotCycleTemp1.Text = MySettings.Instance.ActiveHotSetpoint[0].ToString();
                lblHotCycleTemp2.Text = MySettings.Instance.ActiveHotSetpoint[1].ToString();
                lblHotCycleTemp3.Text = MySettings.Instance.ActiveHotSetpoint[2].ToString();
                lblHotCycleTemp4.Text = MySettings.Instance.ActiveHotSetpoint[3].ToString();

                lblColdCycleTemp1.Text = MySettings.Instance.ActiveColdSetpoint[0].ToString();
                lblColdCycleTemp2.Text = MySettings.Instance.ActiveColdSetpoint[1].ToString();
                lblColdCycleTemp3.Text = MySettings.Instance.ActiveColdSetpoint[2].ToString();
                lblColdCycleTemp4.Text = MySettings.Instance.ActiveColdSetpoint[3].ToString();

                lblHotTempMax.Text = MySettings.Instance.ActiveHotMaxF.ToString();
                lblHotTempMin.Text = MySettings.Instance.ActiveHotMinF.ToString();
                lblColdTempMax.Text = MySettings.Instance.ActiveColdMaxF.ToString();
                lblColdTempMin.Text = MySettings.Instance.ActiveColdMinF.ToString();
            }

        }

        private void btnStartTreatment_Click(object sender, EventArgs e)
        {
            Controller.Instance.StateMachineInvoke(Controller.ControllerEvent.evReadyClick);
        }

        private void btnSkipCycle_Click(object sender, EventArgs e)
        {
            Controller.Instance.StateMachineInvoke(Controller.ControllerEvent.evSkipCycle);
        }

        private void btnCSVSave_Click(object sender, EventArgs e)
        {
            Controller.Instance.StateMachineInvoke(Controller.ControllerEvent.evForceCSVFileSave);
        }
    }
}
