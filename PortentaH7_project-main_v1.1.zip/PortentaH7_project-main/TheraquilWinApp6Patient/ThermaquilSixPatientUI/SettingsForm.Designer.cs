﻿namespace ThermaquilSixPatientUI
{
    partial class SettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nudNumOfSteps = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbActive = new System.Windows.Forms.RadioButton();
            this.rbSham = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.nudShamHotCycleMax = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nudShamColdCycleMin = new System.Windows.Forms.NumericUpDown();
            this.nudShamColdCycleMax = new System.Windows.Forms.NumericUpDown();
            this.nudShamHotCycleMin = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.nudActiveHotCycleMax = new System.Windows.Forms.NumericUpDown();
            this.nudActiveHotCycleMin = new System.Windows.Forms.NumericUpDown();
            this.nudActiveColdCycleMax = new System.Windows.Forms.NumericUpDown();
            this.nudActiveColdCycleMin = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.nudHotCycle1Mins = new System.Windows.Forms.NumericUpDown();
            this.nudHotCycle2Mins = new System.Windows.Forms.NumericUpDown();
            this.nudHotCycle3Mins = new System.Windows.Forms.NumericUpDown();
            this.nudHotCycle4Mins = new System.Windows.Forms.NumericUpDown();
            this.nudActiveCycle1Heat = new System.Windows.Forms.NumericUpDown();
            this.nudActiveCycle2Heat = new System.Windows.Forms.NumericUpDown();
            this.nudActiveCycle3Heat = new System.Windows.Forms.NumericUpDown();
            this.nudActiveCycle4Heat = new System.Windows.Forms.NumericUpDown();
            this.nudShamCycle1Heat = new System.Windows.Forms.NumericUpDown();
            this.nudShamCycle2Heat = new System.Windows.Forms.NumericUpDown();
            this.nudShamCycle3Heat = new System.Windows.Forms.NumericUpDown();
            this.nudShamCycle4Heat = new System.Windows.Forms.NumericUpDown();
            this.nudColdCycle1Mins = new System.Windows.Forms.NumericUpDown();
            this.nudColdCycle2Mins = new System.Windows.Forms.NumericUpDown();
            this.nudColdCycle3Mins = new System.Windows.Forms.NumericUpDown();
            this.nudColdCycle4Mins = new System.Windows.Forms.NumericUpDown();
            this.nudActiveCycle1Cold = new System.Windows.Forms.NumericUpDown();
            this.nudActiveCycle2Cold = new System.Windows.Forms.NumericUpDown();
            this.nudActiveCycle3Cold = new System.Windows.Forms.NumericUpDown();
            this.nudActiveCycle4Cold = new System.Windows.Forms.NumericUpDown();
            this.nudShamCycle1Cold = new System.Windows.Forms.NumericUpDown();
            this.nudShamCycle2Cold = new System.Windows.Forms.NumericUpDown();
            this.nudShamCycle3Cold = new System.Windows.Forms.NumericUpDown();
            this.nudShamCycle4Cold = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudNumOfSteps)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamHotCycleMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamColdCycleMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamColdCycleMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamHotCycleMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveHotCycleMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveHotCycleMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveColdCycleMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveColdCycleMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudHotCycle1Mins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHotCycle2Mins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHotCycle3Mins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHotCycle4Mins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle1Heat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle2Heat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle3Heat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle4Heat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle1Heat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle2Heat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle3Heat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle4Heat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudColdCycle1Mins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudColdCycle2Mins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudColdCycle3Mins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudColdCycle4Mins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle1Cold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle2Cold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle3Cold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle4Cold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle1Cold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle2Cold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle3Cold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle4Cold)).BeginInit();
            this.SuspendLayout();
            // 
            // nudNumOfSteps
            // 
            this.nudNumOfSteps.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudNumOfSteps.Location = new System.Drawing.Point(12, 288);
            this.nudNumOfSteps.Margin = new System.Windows.Forms.Padding(2);
            this.nudNumOfSteps.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudNumOfSteps.Name = "nudNumOfSteps";
            this.nudNumOfSteps.Size = new System.Drawing.Size(69, 30);
            this.nudNumOfSteps.TabIndex = 0;
            this.nudNumOfSteps.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(86, 290);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Number Of Steps";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbActive);
            this.groupBox1.Controls.Add(this.rbSham);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(126, 325);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 46);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // rbActive
            // 
            this.rbActive.AutoSize = true;
            this.rbActive.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbActive.Location = new System.Drawing.Point(11, 16);
            this.rbActive.Name = "rbActive";
            this.rbActive.Size = new System.Drawing.Size(93, 29);
            this.rbActive.TabIndex = 1;
            this.rbActive.TabStop = true;
            this.rbActive.Text = "Active";
            this.rbActive.UseVisualStyleBackColor = true;
            // 
            // rbSham
            // 
            this.rbSham.AutoSize = true;
            this.rbSham.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbSham.Location = new System.Drawing.Point(104, 16);
            this.rbSham.Name = "rbSham";
            this.rbSham.Size = new System.Drawing.Size(89, 29);
            this.rbSham.TabIndex = 0;
            this.rbSham.TabStop = true;
            this.rbSham.Text = "Sham";
            this.rbSham.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.label14, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.label18, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.label11, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label15, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.label12, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.label17, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.nudShamHotCycleMax, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.label16, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label3, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.nudShamColdCycleMin, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.nudShamColdCycleMax, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.nudShamHotCycleMin, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.label13, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.nudActiveHotCycleMax, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.nudActiveHotCycleMin, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.nudActiveColdCycleMax, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.nudActiveColdCycleMin, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label4, 1, 0);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 382);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(395, 192);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(366, 159);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(24, 25);
            this.label14.TabIndex = 16;
            this.label14.Text = "F";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(366, 121);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(24, 25);
            this.label18.TabIndex = 20;
            this.label18.Text = "F";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(258, 45);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 25);
            this.label11.TabIndex = 13;
            this.label11.Text = "F";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(366, 45);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(24, 25);
            this.label15.TabIndex = 17;
            this.label15.Text = "F";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(366, 83);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 25);
            this.label12.TabIndex = 14;
            this.label12.Text = "F";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(258, 159);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(24, 25);
            this.label17.TabIndex = 19;
            this.label17.Text = "F";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nudShamHotCycleMax
            // 
            this.nudShamHotCycleMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudShamHotCycleMax.Location = new System.Drawing.Point(290, 43);
            this.nudShamHotCycleMax.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudShamHotCycleMax.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamHotCycleMax.Name = "nudShamHotCycleMax";
            this.nudShamHotCycleMax.Size = new System.Drawing.Size(53, 30);
            this.nudShamHotCycleMax.TabIndex = 0;
            this.nudShamHotCycleMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudShamHotCycleMax.Value = new decimal(new int[] {
            80,
            0,
            0,
            0});
            this.nudShamHotCycleMax.ValueChanged += new System.EventHandler(this.nudShamHotCycleMax_ValueChanged);
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(258, 83);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(24, 25);
            this.label16.TabIndex = 18;
            this.label16.Text = "F";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(290, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 36);
            this.label3.TabIndex = 8;
            this.label3.Text = "Sham";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nudShamColdCycleMin
            // 
            this.nudShamColdCycleMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudShamColdCycleMin.Location = new System.Drawing.Point(290, 157);
            this.nudShamColdCycleMin.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudShamColdCycleMin.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamColdCycleMin.Name = "nudShamColdCycleMin";
            this.nudShamColdCycleMin.Size = new System.Drawing.Size(53, 30);
            this.nudShamColdCycleMin.TabIndex = 3;
            this.nudShamColdCycleMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudShamColdCycleMin.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamColdCycleMin.ValueChanged += new System.EventHandler(this.nudShamColdCycleMin_ValueChanged);
            // 
            // nudShamColdCycleMax
            // 
            this.nudShamColdCycleMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudShamColdCycleMax.Location = new System.Drawing.Point(290, 119);
            this.nudShamColdCycleMax.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudShamColdCycleMax.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamColdCycleMax.Name = "nudShamColdCycleMax";
            this.nudShamColdCycleMax.Size = new System.Drawing.Size(53, 30);
            this.nudShamColdCycleMax.TabIndex = 2;
            this.nudShamColdCycleMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudShamColdCycleMax.Value = new decimal(new int[] {
            39,
            0,
            0,
            0});
            this.nudShamColdCycleMax.ValueChanged += new System.EventHandler(this.nudShamColdCycleMax_ValueChanged);
            // 
            // nudShamHotCycleMin
            // 
            this.nudShamHotCycleMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudShamHotCycleMin.Location = new System.Drawing.Point(290, 81);
            this.nudShamHotCycleMin.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudShamHotCycleMin.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamHotCycleMin.Name = "nudShamHotCycleMin";
            this.nudShamHotCycleMin.Size = new System.Drawing.Size(53, 30);
            this.nudShamHotCycleMin.TabIndex = 1;
            this.nudShamHotCycleMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudShamHotCycleMin.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.nudShamHotCycleMin.ValueChanged += new System.EventHandler(this.nudShamHotCycleMin_ValueChanged);
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(258, 121);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(24, 25);
            this.label13.TabIndex = 15;
            this.label13.Text = "F";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(5, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(165, 36);
            this.label5.TabIndex = 10;
            this.label5.Text = "Hot Cycle Max";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(5, 78);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(165, 36);
            this.label6.TabIndex = 11;
            this.label6.Text = "Hot Cycle Min";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(165, 36);
            this.label7.TabIndex = 12;
            this.label7.Text = "Cold Cycle Max";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(5, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(165, 36);
            this.label8.TabIndex = 13;
            this.label8.Text = "ColdCycle Min";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nudActiveHotCycleMax
            // 
            this.nudActiveHotCycleMax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.nudActiveHotCycleMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudActiveHotCycleMax.Location = new System.Drawing.Point(197, 43);
            this.nudActiveHotCycleMax.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudActiveHotCycleMax.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveHotCycleMax.Name = "nudActiveHotCycleMax";
            this.nudActiveHotCycleMax.Size = new System.Drawing.Size(53, 30);
            this.nudActiveHotCycleMax.TabIndex = 4;
            this.nudActiveHotCycleMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudActiveHotCycleMax.Value = new decimal(new int[] {
            109,
            0,
            0,
            0});
            this.nudActiveHotCycleMax.ValueChanged += new System.EventHandler(this.nudActiveHotCycleMax_ValueChanged);
            // 
            // nudActiveHotCycleMin
            // 
            this.nudActiveHotCycleMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nudActiveHotCycleMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudActiveHotCycleMin.Location = new System.Drawing.Point(197, 81);
            this.nudActiveHotCycleMin.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudActiveHotCycleMin.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveHotCycleMin.Name = "nudActiveHotCycleMin";
            this.nudActiveHotCycleMin.Size = new System.Drawing.Size(53, 30);
            this.nudActiveHotCycleMin.TabIndex = 5;
            this.nudActiveHotCycleMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudActiveHotCycleMin.Value = new decimal(new int[] {
            80,
            0,
            0,
            0});
            this.nudActiveHotCycleMin.ValueChanged += new System.EventHandler(this.nudActiveHotCycleMin_ValueChanged);
            // 
            // nudActiveColdCycleMax
            // 
            this.nudActiveColdCycleMax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nudActiveColdCycleMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudActiveColdCycleMax.Location = new System.Drawing.Point(197, 119);
            this.nudActiveColdCycleMax.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudActiveColdCycleMax.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveColdCycleMax.Name = "nudActiveColdCycleMax";
            this.nudActiveColdCycleMax.Size = new System.Drawing.Size(53, 30);
            this.nudActiveColdCycleMax.TabIndex = 6;
            this.nudActiveColdCycleMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudActiveColdCycleMax.Value = new decimal(new int[] {
            39,
            0,
            0,
            0});
            this.nudActiveColdCycleMax.ValueChanged += new System.EventHandler(this.nudActiveColdCycleMax_ValueChanged);
            // 
            // nudActiveColdCycleMin
            // 
            this.nudActiveColdCycleMin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nudActiveColdCycleMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudActiveColdCycleMin.Location = new System.Drawing.Point(197, 157);
            this.nudActiveColdCycleMin.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudActiveColdCycleMin.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveColdCycleMin.Name = "nudActiveColdCycleMin";
            this.nudActiveColdCycleMin.Size = new System.Drawing.Size(53, 30);
            this.nudActiveColdCycleMin.TabIndex = 7;
            this.nudActiveColdCycleMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudActiveColdCycleMin.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveColdCycleMin.ValueChanged += new System.EventHandler(this.nudActiveColdCycleMin_ValueChanged);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(178, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 36);
            this.label4.TabIndex = 9;
            this.label4.Text = "Active";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(764, 445);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(103, 46);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(764, 504);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(103, 46);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(122, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(106, 52);
            this.label9.TabIndex = 8;
            this.label9.Text = "Hot Cycle Time (mins)";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ThermaquilSixPatientUI.Properties.Resources.ThermaquilLogoColor;
            this.pictureBox1.InitialImage = global::ThermaquilSixPatientUI.Properties.Resources.ThermaquilLogoColor;
            this.pictureBox1.Location = new System.Drawing.Point(556, 290);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(311, 132);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 42;
            this.pictureBox1.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 8;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.label9, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label19, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label20, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label21, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label22, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label23, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label10, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.label25, 7, 0);
            this.tableLayoutPanel2.Controls.Add(this.nudHotCycle1Mins, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.nudHotCycle2Mins, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.nudHotCycle3Mins, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.nudHotCycle4Mins, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.nudActiveCycle1Heat, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.nudActiveCycle2Heat, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.nudActiveCycle3Heat, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.nudActiveCycle4Heat, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.nudShamCycle1Heat, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.nudShamCycle2Heat, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.nudShamCycle3Heat, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.nudShamCycle4Heat, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.nudColdCycle1Mins, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.nudColdCycle2Mins, 5, 2);
            this.tableLayoutPanel2.Controls.Add(this.nudColdCycle3Mins, 5, 3);
            this.tableLayoutPanel2.Controls.Add(this.nudColdCycle4Mins, 5, 4);
            this.tableLayoutPanel2.Controls.Add(this.nudActiveCycle1Cold, 6, 1);
            this.tableLayoutPanel2.Controls.Add(this.nudActiveCycle2Cold, 6, 2);
            this.tableLayoutPanel2.Controls.Add(this.nudActiveCycle3Cold, 6, 3);
            this.tableLayoutPanel2.Controls.Add(this.nudActiveCycle4Cold, 6, 4);
            this.tableLayoutPanel2.Controls.Add(this.nudShamCycle1Cold, 7, 1);
            this.tableLayoutPanel2.Controls.Add(this.nudShamCycle2Cold, 7, 2);
            this.tableLayoutPanel2.Controls.Add(this.nudShamCycle3Cold, 7, 3);
            this.tableLayoutPanel2.Controls.Add(this.nudShamCycle4Cold, 7, 4);
            this.tableLayoutPanel2.Controls.Add(this.label24, 6, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(855, 255);
            this.tableLayoutPanel2.TabIndex = 43;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(5, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 32);
            this.label2.TabIndex = 9;
            this.label2.Text = "1st Cycle";
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(236, 2);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(111, 86);
            this.label19.TabIndex = 10;
            this.label19.Text = "Active Heating Temperature (F)";
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(5, 130);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(109, 32);
            this.label20.TabIndex = 11;
            this.label20.Text = "2nd Cycle";
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(5, 168);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(109, 32);
            this.label21.TabIndex = 12;
            this.label21.Text = "3rd Cycle";
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(5, 204);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(109, 48);
            this.label22.TabIndex = 13;
            this.label22.Text = "Subsequent Cycles";
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(355, 2);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(120, 86);
            this.label23.TabIndex = 14;
            this.label23.Text = "Sham Heating Temperature (F)";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(505, 36);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 52);
            this.label10.TabIndex = 15;
            this.label10.Text = "Cold Cycle Time (mins)";
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(736, 2);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(114, 86);
            this.label25.TabIndex = 17;
            this.label25.Text = "Sham Cooling Temperature (F)";
            // 
            // nudHotCycle1Mins
            // 
            this.nudHotCycle1Mins.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudHotCycle1Mins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudHotCycle1Mins.Location = new System.Drawing.Point(142, 93);
            this.nudHotCycle1Mins.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nudHotCycle1Mins.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudHotCycle1Mins.Name = "nudHotCycle1Mins";
            this.nudHotCycle1Mins.Size = new System.Drawing.Size(66, 30);
            this.nudHotCycle1Mins.TabIndex = 18;
            this.nudHotCycle1Mins.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudHotCycle1Mins.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudHotCycle2Mins
            // 
            this.nudHotCycle2Mins.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudHotCycle2Mins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudHotCycle2Mins.Location = new System.Drawing.Point(142, 131);
            this.nudHotCycle2Mins.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nudHotCycle2Mins.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudHotCycle2Mins.Name = "nudHotCycle2Mins";
            this.nudHotCycle2Mins.Size = new System.Drawing.Size(66, 30);
            this.nudHotCycle2Mins.TabIndex = 19;
            this.nudHotCycle2Mins.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudHotCycle2Mins.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudHotCycle3Mins
            // 
            this.nudHotCycle3Mins.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudHotCycle3Mins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudHotCycle3Mins.Location = new System.Drawing.Point(142, 169);
            this.nudHotCycle3Mins.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nudHotCycle3Mins.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudHotCycle3Mins.Name = "nudHotCycle3Mins";
            this.nudHotCycle3Mins.Size = new System.Drawing.Size(66, 30);
            this.nudHotCycle3Mins.TabIndex = 20;
            this.nudHotCycle3Mins.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudHotCycle3Mins.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudHotCycle4Mins
            // 
            this.nudHotCycle4Mins.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudHotCycle4Mins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudHotCycle4Mins.Location = new System.Drawing.Point(142, 213);
            this.nudHotCycle4Mins.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nudHotCycle4Mins.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudHotCycle4Mins.Name = "nudHotCycle4Mins";
            this.nudHotCycle4Mins.Size = new System.Drawing.Size(66, 30);
            this.nudHotCycle4Mins.TabIndex = 21;
            this.nudHotCycle4Mins.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudHotCycle4Mins.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudActiveCycle1Heat
            // 
            this.nudActiveCycle1Heat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudActiveCycle1Heat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudActiveCycle1Heat.Location = new System.Drawing.Point(258, 93);
            this.nudActiveCycle1Heat.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudActiveCycle1Heat.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveCycle1Heat.Name = "nudActiveCycle1Heat";
            this.nudActiveCycle1Heat.Size = new System.Drawing.Size(66, 30);
            this.nudActiveCycle1Heat.TabIndex = 22;
            this.nudActiveCycle1Heat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudActiveCycle1Heat.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudActiveCycle2Heat
            // 
            this.nudActiveCycle2Heat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudActiveCycle2Heat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudActiveCycle2Heat.Location = new System.Drawing.Point(258, 131);
            this.nudActiveCycle2Heat.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudActiveCycle2Heat.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveCycle2Heat.Name = "nudActiveCycle2Heat";
            this.nudActiveCycle2Heat.Size = new System.Drawing.Size(66, 30);
            this.nudActiveCycle2Heat.TabIndex = 23;
            this.nudActiveCycle2Heat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudActiveCycle2Heat.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudActiveCycle3Heat
            // 
            this.nudActiveCycle3Heat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudActiveCycle3Heat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudActiveCycle3Heat.Location = new System.Drawing.Point(258, 169);
            this.nudActiveCycle3Heat.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudActiveCycle3Heat.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveCycle3Heat.Name = "nudActiveCycle3Heat";
            this.nudActiveCycle3Heat.Size = new System.Drawing.Size(66, 30);
            this.nudActiveCycle3Heat.TabIndex = 24;
            this.nudActiveCycle3Heat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudActiveCycle3Heat.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudActiveCycle4Heat
            // 
            this.nudActiveCycle4Heat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudActiveCycle4Heat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudActiveCycle4Heat.Location = new System.Drawing.Point(258, 213);
            this.nudActiveCycle4Heat.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudActiveCycle4Heat.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveCycle4Heat.Name = "nudActiveCycle4Heat";
            this.nudActiveCycle4Heat.Size = new System.Drawing.Size(66, 30);
            this.nudActiveCycle4Heat.TabIndex = 25;
            this.nudActiveCycle4Heat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudActiveCycle4Heat.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudShamCycle1Heat
            // 
            this.nudShamCycle1Heat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudShamCycle1Heat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudShamCycle1Heat.Location = new System.Drawing.Point(382, 93);
            this.nudShamCycle1Heat.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudShamCycle1Heat.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamCycle1Heat.Name = "nudShamCycle1Heat";
            this.nudShamCycle1Heat.Size = new System.Drawing.Size(66, 30);
            this.nudShamCycle1Heat.TabIndex = 26;
            this.nudShamCycle1Heat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudShamCycle1Heat.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudShamCycle2Heat
            // 
            this.nudShamCycle2Heat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudShamCycle2Heat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudShamCycle2Heat.Location = new System.Drawing.Point(382, 131);
            this.nudShamCycle2Heat.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudShamCycle2Heat.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamCycle2Heat.Name = "nudShamCycle2Heat";
            this.nudShamCycle2Heat.Size = new System.Drawing.Size(66, 30);
            this.nudShamCycle2Heat.TabIndex = 27;
            this.nudShamCycle2Heat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudShamCycle2Heat.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudShamCycle3Heat
            // 
            this.nudShamCycle3Heat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudShamCycle3Heat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudShamCycle3Heat.Location = new System.Drawing.Point(382, 169);
            this.nudShamCycle3Heat.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudShamCycle3Heat.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamCycle3Heat.Name = "nudShamCycle3Heat";
            this.nudShamCycle3Heat.Size = new System.Drawing.Size(66, 30);
            this.nudShamCycle3Heat.TabIndex = 28;
            this.nudShamCycle3Heat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudShamCycle3Heat.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudShamCycle4Heat
            // 
            this.nudShamCycle4Heat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudShamCycle4Heat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudShamCycle4Heat.Location = new System.Drawing.Point(382, 213);
            this.nudShamCycle4Heat.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudShamCycle4Heat.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamCycle4Heat.Name = "nudShamCycle4Heat";
            this.nudShamCycle4Heat.Size = new System.Drawing.Size(66, 30);
            this.nudShamCycle4Heat.TabIndex = 29;
            this.nudShamCycle4Heat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudShamCycle4Heat.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudColdCycle1Mins
            // 
            this.nudColdCycle1Mins.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudColdCycle1Mins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudColdCycle1Mins.Location = new System.Drawing.Point(522, 93);
            this.nudColdCycle1Mins.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nudColdCycle1Mins.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudColdCycle1Mins.Name = "nudColdCycle1Mins";
            this.nudColdCycle1Mins.Size = new System.Drawing.Size(66, 30);
            this.nudColdCycle1Mins.TabIndex = 30;
            this.nudColdCycle1Mins.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudColdCycle1Mins.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudColdCycle2Mins
            // 
            this.nudColdCycle2Mins.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudColdCycle2Mins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudColdCycle2Mins.Location = new System.Drawing.Point(522, 131);
            this.nudColdCycle2Mins.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nudColdCycle2Mins.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudColdCycle2Mins.Name = "nudColdCycle2Mins";
            this.nudColdCycle2Mins.Size = new System.Drawing.Size(66, 30);
            this.nudColdCycle2Mins.TabIndex = 31;
            this.nudColdCycle2Mins.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudColdCycle2Mins.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudColdCycle3Mins
            // 
            this.nudColdCycle3Mins.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudColdCycle3Mins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudColdCycle3Mins.Location = new System.Drawing.Point(522, 169);
            this.nudColdCycle3Mins.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nudColdCycle3Mins.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudColdCycle3Mins.Name = "nudColdCycle3Mins";
            this.nudColdCycle3Mins.Size = new System.Drawing.Size(66, 30);
            this.nudColdCycle3Mins.TabIndex = 32;
            this.nudColdCycle3Mins.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudColdCycle3Mins.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudColdCycle4Mins
            // 
            this.nudColdCycle4Mins.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudColdCycle4Mins.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudColdCycle4Mins.Location = new System.Drawing.Point(522, 213);
            this.nudColdCycle4Mins.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.nudColdCycle4Mins.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudColdCycle4Mins.Name = "nudColdCycle4Mins";
            this.nudColdCycle4Mins.Size = new System.Drawing.Size(66, 30);
            this.nudColdCycle4Mins.TabIndex = 33;
            this.nudColdCycle4Mins.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudColdCycle4Mins.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudActiveCycle1Cold
            // 
            this.nudActiveCycle1Cold.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudActiveCycle1Cold.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudActiveCycle1Cold.Location = new System.Drawing.Point(637, 93);
            this.nudActiveCycle1Cold.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudActiveCycle1Cold.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveCycle1Cold.Name = "nudActiveCycle1Cold";
            this.nudActiveCycle1Cold.Size = new System.Drawing.Size(66, 30);
            this.nudActiveCycle1Cold.TabIndex = 34;
            this.nudActiveCycle1Cold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudActiveCycle1Cold.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudActiveCycle2Cold
            // 
            this.nudActiveCycle2Cold.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudActiveCycle2Cold.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudActiveCycle2Cold.Location = new System.Drawing.Point(637, 131);
            this.nudActiveCycle2Cold.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudActiveCycle2Cold.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveCycle2Cold.Name = "nudActiveCycle2Cold";
            this.nudActiveCycle2Cold.Size = new System.Drawing.Size(66, 30);
            this.nudActiveCycle2Cold.TabIndex = 35;
            this.nudActiveCycle2Cold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudActiveCycle2Cold.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudActiveCycle3Cold
            // 
            this.nudActiveCycle3Cold.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudActiveCycle3Cold.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudActiveCycle3Cold.Location = new System.Drawing.Point(637, 169);
            this.nudActiveCycle3Cold.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudActiveCycle3Cold.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveCycle3Cold.Name = "nudActiveCycle3Cold";
            this.nudActiveCycle3Cold.Size = new System.Drawing.Size(66, 30);
            this.nudActiveCycle3Cold.TabIndex = 36;
            this.nudActiveCycle3Cold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudActiveCycle3Cold.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudActiveCycle4Cold
            // 
            this.nudActiveCycle4Cold.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudActiveCycle4Cold.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudActiveCycle4Cold.Location = new System.Drawing.Point(637, 213);
            this.nudActiveCycle4Cold.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudActiveCycle4Cold.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudActiveCycle4Cold.Name = "nudActiveCycle4Cold";
            this.nudActiveCycle4Cold.Size = new System.Drawing.Size(66, 30);
            this.nudActiveCycle4Cold.TabIndex = 37;
            this.nudActiveCycle4Cold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudActiveCycle4Cold.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudShamCycle1Cold
            // 
            this.nudShamCycle1Cold.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudShamCycle1Cold.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudShamCycle1Cold.Location = new System.Drawing.Point(760, 93);
            this.nudShamCycle1Cold.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudShamCycle1Cold.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamCycle1Cold.Name = "nudShamCycle1Cold";
            this.nudShamCycle1Cold.Size = new System.Drawing.Size(66, 30);
            this.nudShamCycle1Cold.TabIndex = 38;
            this.nudShamCycle1Cold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudShamCycle1Cold.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudShamCycle2Cold
            // 
            this.nudShamCycle2Cold.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudShamCycle2Cold.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudShamCycle2Cold.Location = new System.Drawing.Point(760, 131);
            this.nudShamCycle2Cold.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudShamCycle2Cold.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamCycle2Cold.Name = "nudShamCycle2Cold";
            this.nudShamCycle2Cold.Size = new System.Drawing.Size(66, 30);
            this.nudShamCycle2Cold.TabIndex = 39;
            this.nudShamCycle2Cold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudShamCycle2Cold.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudShamCycle3Cold
            // 
            this.nudShamCycle3Cold.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudShamCycle3Cold.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudShamCycle3Cold.Location = new System.Drawing.Point(760, 169);
            this.nudShamCycle3Cold.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudShamCycle3Cold.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamCycle3Cold.Name = "nudShamCycle3Cold";
            this.nudShamCycle3Cold.Size = new System.Drawing.Size(66, 30);
            this.nudShamCycle3Cold.TabIndex = 40;
            this.nudShamCycle3Cold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudShamCycle3Cold.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudShamCycle4Cold
            // 
            this.nudShamCycle4Cold.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nudShamCycle4Cold.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudShamCycle4Cold.Location = new System.Drawing.Point(760, 213);
            this.nudShamCycle4Cold.Maximum = new decimal(new int[] {
            140,
            0,
            0,
            0});
            this.nudShamCycle4Cold.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudShamCycle4Cold.Name = "nudShamCycle4Cold";
            this.nudShamCycle4Cold.Size = new System.Drawing.Size(66, 30);
            this.nudShamCycle4Cold.TabIndex = 41;
            this.nudShamCycle4Cold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nudShamCycle4Cold.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(613, 2);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(115, 86);
            this.label24.TabIndex = 16;
            this.label24.Text = "Active Cooling Temperature (F)";
            // 
            // SettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 572);
            this.ControlBox = false;
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nudNumOfSteps);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "SettingsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Thermaquil Settings";
            ((System.ComponentModel.ISupportInitialize)(this.nudNumOfSteps)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamHotCycleMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamColdCycleMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamColdCycleMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamHotCycleMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveHotCycleMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveHotCycleMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveColdCycleMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveColdCycleMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudHotCycle1Mins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHotCycle2Mins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHotCycle3Mins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHotCycle4Mins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle1Heat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle2Heat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle3Heat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle4Heat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle1Heat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle2Heat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle3Heat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle4Heat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudColdCycle1Mins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudColdCycle2Mins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudColdCycle3Mins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudColdCycle4Mins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle1Cold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle2Cold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle3Cold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudActiveCycle4Cold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle1Cold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle2Cold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle3Cold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudShamCycle4Cold)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown nudNumOfSteps;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbActive;
        private System.Windows.Forms.RadioButton rbSham;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.NumericUpDown nudShamHotCycleMax;
        private System.Windows.Forms.NumericUpDown nudShamHotCycleMin;
        private System.Windows.Forms.NumericUpDown nudShamColdCycleMax;
        private System.Windows.Forms.NumericUpDown nudShamColdCycleMin;
        private System.Windows.Forms.NumericUpDown nudActiveHotCycleMax;
        private System.Windows.Forms.NumericUpDown nudActiveHotCycleMin;
        private System.Windows.Forms.NumericUpDown nudActiveColdCycleMax;
        private System.Windows.Forms.NumericUpDown nudActiveColdCycleMin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown nudHotCycle1Mins;
        private System.Windows.Forms.NumericUpDown nudHotCycle2Mins;
        private System.Windows.Forms.NumericUpDown nudHotCycle3Mins;
        private System.Windows.Forms.NumericUpDown nudHotCycle4Mins;
        private System.Windows.Forms.NumericUpDown nudActiveCycle1Heat;
        private System.Windows.Forms.NumericUpDown nudActiveCycle2Heat;
        private System.Windows.Forms.NumericUpDown nudActiveCycle3Heat;
        private System.Windows.Forms.NumericUpDown nudActiveCycle4Heat;
        private System.Windows.Forms.NumericUpDown nudShamCycle1Heat;
        private System.Windows.Forms.NumericUpDown nudShamCycle2Heat;
        private System.Windows.Forms.NumericUpDown nudShamCycle3Heat;
        private System.Windows.Forms.NumericUpDown nudShamCycle4Heat;
        private System.Windows.Forms.NumericUpDown nudColdCycle1Mins;
        private System.Windows.Forms.NumericUpDown nudColdCycle2Mins;
        private System.Windows.Forms.NumericUpDown nudColdCycle3Mins;
        private System.Windows.Forms.NumericUpDown nudColdCycle4Mins;
        private System.Windows.Forms.NumericUpDown nudActiveCycle1Cold;
        private System.Windows.Forms.NumericUpDown nudActiveCycle2Cold;
        private System.Windows.Forms.NumericUpDown nudActiveCycle3Cold;
        private System.Windows.Forms.NumericUpDown nudActiveCycle4Cold;
        private System.Windows.Forms.NumericUpDown nudShamCycle1Cold;
        private System.Windows.Forms.NumericUpDown nudShamCycle2Cold;
        private System.Windows.Forms.NumericUpDown nudShamCycle3Cold;
        private System.Windows.Forms.NumericUpDown nudShamCycle4Cold;
    }
}