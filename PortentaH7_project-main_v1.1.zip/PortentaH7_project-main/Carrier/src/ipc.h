#ifndef _IPC_H_
#define _IPC_H_

#include "error.h"
#include "version.h"

#define IPC_REGISTER_MAP_SIZE 45

typedef enum
{
	IPC_ACCESS_RO = 0x00,
	IPC_ACCESS_RW,
	IPC_ACCESS_W0,
	IPC_ACCESS__MAX__,
} ipc_access_type_t;

typedef struct
{
	union
	{
		struct
		{
			uint8_t HEAT : 1;
			uint8_t COOL : 1;
			uint8_t START : 1;
			uint8_t STOP : 1;
			uint8_t PAUSE : 1;
			uint8_t RSVD2 : 3;
		} bits;
		uint8_t byte;
	} EVENTS;

	union
	{
		struct
		{
			uint8_t PAUSED : 1;
			uint8_t RSVD : 7;
		} bits;
		uint8_t byte;
	} FLAGS;
} ipc_registers_events_flags_t;
typedef struct
{
	union
	{
		struct
		{
			uint8_t THERM0_BOUNDARY_ERR : 1;
			uint8_t THERM1_BOUNDARY_ERR : 1;
			uint8_t THERM2_BOUNDARY_ERR : 1;
			uint8_t THERM3_BOUNDARY_ERR : 1;
			uint8_t THERM4_BOUNDARY_ERR : 1;
			uint8_t THERM5_BOUNDARY_ERR : 1;
			uint8_t RSVD : 2;
		} bits;
		uint8_t byte;
	} FAULT_0;

	union
	{
		struct
		{
			uint8_t DAC_COMM_ERR : 1;
			uint8_t EEPROM_COMM_ERR : 1;
			uint8_t BATT_COMM_ERR : 1;
			uint8_t RSVD : 5;
		} bits;
		uint8_t byte;
	} FAULT_1;
} ipc_registers_faults_t;

typedef struct
{
	uint8_t FW_VER_MAJOR;
	uint8_t FW_VER_MINOR;
	uint8_t FW_VER_PATCH;
	uint8_t FW_VER_DBG;
	uint8_t RSVD[12];
} ipc_registers_revision_t;

typedef union
{
	struct MyStruct
	{
		float TEMP_0;
		float INLET_TEMP;
		float OUTLET_TEMP;
		float COLD_RESV_TEMP;
		float HOT_RESV_TEMP;
		float TEMP_5;
	}floats;
	float array[6];
}ipc_registers_temperatures_t;
typedef union
{
	struct
	{
		ipc_registers_temperatures_t TEMPERATURES;	// 24 bytes
		float HEAT_SETPOINT;
		float COLD_SETPOINT;
		ipc_registers_events_flags_t EVTS_FLAGS;	// 2 bytes
		ipc_registers_revision_t REVISION;			// 5 bytes
		ipc_registers_faults_t FAULTS;				// 2 bytes
	} bitfields;
	uint8_t bytes[IPC_REGISTER_MAP_SIZE];
} ipc_register_map_t;

app_return_code_t ipc_init(void);
app_return_code_t ipc_update(void);

ipc_register_map_t ipc_register_map = {0x00};
ipc_access_type_t ipc_register_access[IPC_REGISTER_MAP_SIZE] = {0x00};

const ipc_register_map_t ipc_register_map_defaults = {
	.bitfields.REVISION.FW_VER_MAJOR = VERSION_MAJOR,
	.bitfields.REVISION.FW_VER_MINOR = VERSION_MINOR,
	.bitfields.REVISION.FW_VER_PATCH = VERSION_PATCH,
	.bitfields.REVISION.FW_VER_DBG = VERSION_DEBUG};

#endif // _IPC_H_