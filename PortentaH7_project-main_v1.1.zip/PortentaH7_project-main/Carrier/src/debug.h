/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
debug.h
*******************************************************************************/

#ifndef _DEBUG_H_
#define _DEBUG_H_

#include <stdint.h>
#include "error.h"

app_return_code_t debug_writeLine(const char* frmt, ...);
app_return_code_t debug_writeArray(const uint8_t* arr, const uint16_t len);
#endif // _DEBUG_H_