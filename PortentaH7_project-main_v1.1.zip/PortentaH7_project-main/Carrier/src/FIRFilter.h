/*
 * FIRFilter.h
 *
 *  Created on: Dec 1, 2021
 *      Author: gyurk
 */

#ifndef FIRFILTER_H_
#define FIRFILTER_H_

typedef struct
{
    int numTaps;
    int lastIndex;
    double filterTaps[40];
    double history[40];
}tFIRFilterStruct;

void FIR_Initialize(tFIRFilterStruct* filterStruct, float taps[], int numTaps);
void FIR_PutSample(float input, tFIRFilterStruct* filterStruct);
float FIR_GetOutput(tFIRFilterStruct* fs);


#endif /* FIRFILTER_H_ */
