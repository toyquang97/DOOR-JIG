/*
 * FIRTaps.h
 *
 *  Created on: Dec 2, 2021
 *      Author: gyurk
 */

#ifndef FIRTAPS_H_
#define FIRTAPS_H_

extern float tenAvgTaps[10];
extern float fiveAvgTaps[5];

#endif /* SRC_UTILITIES_FIRTAPS_H_ */
