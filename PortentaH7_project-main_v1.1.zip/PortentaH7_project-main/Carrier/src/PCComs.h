/*****************************************************************************/
/* This document and its contents are the property of Vixiar Inc. This
 * document contains confidential and/or proprietary information. The
 * reproduction, distribution, utilization or the communication of this
 * document or any part thereof, without express authorization is strictly
 * prohibited. Offenders will be held liable for the payment of damages.
 *
 * (C) 2017-2018, Vixiar.  All rights reserved.
 *
 * Project      :  Indicor Handheld Embedded Application Software
 *//**
 * \file TestOverride.h
 *//*
 *
 * Revision: 25SEP2018 - D.Smail : Original Release
 *
 *
 *****************************************************************************/

#ifndef PCCOMS_H_
#define PCCOMS_H_

#include <stdint.h>

/*******************************************************************
 *
 *     C  O  N  S  T  A  N  T  S
 *
 *******************************************************************/

/*******************************************************************
 *
 *     E  N  U  M  S
 *
 *******************************************************************/

/*******************************************************************
 *
 *    S  T  R  U  C  T  S
 *
 *******************************************************************/

/*******************************************************************
 *
 *    E  X  T  E  R  N      V  A  R  I  A  B  L  E  S
 *
 *******************************************************************/

/*******************************************************************
 *
 *    E  X  T  E  R  N      F  U  N  C  T  I  O  N  S
 *
 *******************************************************************/
void PCComs();
void PCComsProcessCommand(char command, float data);

#endif /* TESTOVERRIDE_H_ */

/* [] END OF FILE */
