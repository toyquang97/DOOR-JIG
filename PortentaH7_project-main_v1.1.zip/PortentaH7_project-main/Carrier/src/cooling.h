/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
cooling.h
*******************************************************************************/

#ifndef _COOLING_H_
#define _COOLING_H_

#include <stdint.h>
#include "error.h"

app_return_code_t cooling_init(void);
app_return_code_t cooling_update(void);
app_return_code_t cooling_disable(void);

void setDACoutput(uint16_t value);
void turnOnCooling(void);
void turnOffCooling(void);

#endif // _COOLING_H_