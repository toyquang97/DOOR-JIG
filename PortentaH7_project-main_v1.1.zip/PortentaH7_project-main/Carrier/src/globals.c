#include "globals.h"

output_states_t g_outputStates;
system_state_t g_systemState;
remote_command_t g_remoteCommand;
float g_hotSetpoint;
float g_coldSetpoint;
float g_inletTemperature;
float g_outletTemperature;
float g_coldResevoirTemperature;
float g_hotResevoirTemperature;
bool g_bFilling;
float g_heaterPWMLevel;
