/*
 * FIRFilter.c
 *
 *  Created on: Dec 1, 2021
 *      Author: gyurk
 */
#include "FIRFilter.h"

void FIR_Initialize(tFIRFilterStruct* filterStruct, float taps[], int numTaps)
{
	filterStruct->numTaps = numTaps;
	for (int i = 0; i < filterStruct->numTaps; ++i)
	{
		filterStruct->history[i] = 0;
		filterStruct->filterTaps[i] = taps[i];
	}
	filterStruct->lastIndex = 0;
}

void FIR_PutSample(float input, tFIRFilterStruct* filterStruct)
{
	filterStruct->history[filterStruct->lastIndex++] = input;
	if (filterStruct->lastIndex == filterStruct->numTaps)
	{
		filterStruct->lastIndex = 0;
	}
}

float FIR_GetOutput(tFIRFilterStruct* fs)
{
	float acc = 0;
	int index = fs->lastIndex;
	for (int i = 0; i < fs->numTaps; ++i)
	{
		index = index != 0 ? index - 1 : fs->numTaps - 1;
		acc += fs->history[index] * fs->filterTaps[i];
	}
	return acc;
}

