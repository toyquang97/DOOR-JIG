/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
main.c
*******************************************************************************/

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "ipc.h"
#include "error.h"
#include "board_spi.h"

#define MAX_COMMAND_QUE     8
#define MAX_COMMAND_LEN     8
#define CIRC_BUFF_OPEN      (   circularBuffHead == circularBuffTail                \
                                    ? true                                          \
                                    : circularBuffTail == (MAX_COMMAND_QUE - 1)     \
                                        ? (circularBuffHead == 0x00)                \
                                            ? false                                 \
                                            : true                                  \
                                        : (circularBuffHead - circularBuffTail) > 1 \
                                            ? true                                  \
                                            : false )
#define CIRC_BUFF_EMPTY    ((circularBuffHead == circularBuffTail) ? true : false)

typedef enum {
    IPC_CMD_NONE = 0x00,
    IPC_CMD_SET_ADDR = 0x01,
    IPC_CMD_WRITE = 0x02,
    IPC_CMD_READ = 0x03,
} ipc_cmd_t;

uint8_t circularBuff[MAX_COMMAND_QUE][MAX_COMMAND_LEN] = {0x00};
uint8_t circularBuffHead = 0x00;
uint8_t circularBuffTail = 0x00;
uint8_t circularBuffFill = 0x00;

app_return_code_t spi_cb(void) {
    app_return_code_t ret = APP_RET_OK;

    // First check if there is room in the circular buff
    if( CIRC_BUFF_OPEN ) {
        // There's room. So let's retrieve the command from the que and place it in
        ret = BOARD_SPI_GetRxData((uint8_t *)&circularBuff[circularBuffTail][0], MAX_COMMAND_LEN);

        if( (ret == APP_RET_OK) && (circularBuff[circularBuffTail][0] != 0x00) ) {
            // Increment the index of our tail
            circularBuffTail++;

            // Check if our tail is now out of bounds
            if( circularBuffTail >= MAX_COMMAND_QUE ) {
                // It is. Wrap around to the start
                circularBuffTail = 0x00;
            }
        }
    }

    return ret;
}

app_return_code_t ipc_init(void) {
    app_return_code_t ret = APP_RET_OK;

    // Setup our Access list.. Set everything to read only and then set any of our RW
    memset(ipc_register_access, IPC_ACCESS_RO, sizeof(ipc_register_access));
    ipc_register_access[0x24] = IPC_ACCESS_RW; // DEV_HOT_RSVR_SETPOINT
    ipc_register_access[0x25] = IPC_ACCESS_RW; // DEV_COLD_RSVR_SETPOINT
    ipc_register_access[0x26] = IPC_ACCESS_RW; // DEV_EVENT_0
    ipc_register_access[0x2A] = IPC_ACCESS_RW; // DEV_TEMP_STEP_VAL
    ipc_register_access[0x40] = IPC_ACCESS_RW; // DBG_DEVICE_IO_STATE

    // Copy our default IPC register values
    // memcpy(ipc_register_map.bytes, ipc_register_map_defaults.bytes, sizeof(ipc_register_map));
    // for( uint16_t i = 0; i < sizeof(ipc_register_map.bytes); i++ ) {
    //     ipc_register_map.bytes[i] = i;
    // }

    // Clear out all of our faults to begin with
    ipc_register_map.bitfields.FAULTS.FAULT_0.byte = 0x00;
    ipc_register_map.bitfields.FAULTS.FAULT_1.byte = 0x00;

    // Load up the callback for receiving new commands
    ret = BOARD_SPI_SetRxCallback(spi_cb);

    if( ret == APP_RET_OK ) {
        // Set our TX buffer
        ret = BOARD_SPI_SetTxBuffer(ipc_register_map.bytes, sizeof(ipc_register_map.bytes));
    }

    return ret;
}

app_return_code_t ipc_update(void) {
    app_return_code_t ret = APP_RET_OK;
    uint8_t *spiCmdPtr = NULL;

    // Check if we are all caught up on commands
    if( CIRC_BUFF_EMPTY ) {
        return ret;
    }

    while( !CIRC_BUFF_EMPTY ) {
        // Grab the next command
        spiCmdPtr = &circularBuff[circularBuffHead][0];

        // We have data to process
        switch( spiCmdPtr[0] ) {
            case IPC_CMD_SET_ADDR:
                if( spiCmdPtr[1] > IPC_REGISTER_MAP_SIZE )
                    ret = BOARD_SPI_SetTxBuffer((uint8_t *)ipc_register_map.bytes, sizeof(ipc_register_map.bytes));
                    // ret = BOARD_SPI_SetTxIndex(0);
                else {
                    ret = BOARD_SPI_SetTxBuffer((uint8_t *)ipc_register_map.bytes + spiCmdPtr[1], sizeof(ipc_register_map.bytes));
                    // ret = BOARD_SPI_SetTxIndex(spi_data[1]);
                }
                break;

            case IPC_CMD_WRITE:
                // [0] - Write Commands
                // [1] - Register Address
                // [2] - Len
                // [3..Len] - Value
                // Make sure the address is in range
                if( spiCmdPtr[1] > IPC_REGISTER_MAP_SIZE )
                    return APP_RET_INV_PARAM;

                // Now make sure the length plus the address is within range
                if( (spiCmdPtr[1] + spiCmdPtr[2]) > IPC_REGISTER_MAP_SIZE )
                    return APP_RET_INV_PARAM;

                // Loop through all of the bytes sent to us, but before writing them, make sure
                // they have RW access.
                for( uint8_t i = 0; i < spiCmdPtr[2]; i++ ) {
                    // Check if it has RW access
                    if( ipc_register_access[spiCmdPtr[1] + i] == IPC_ACCESS_RW ) {
                        // This byte has RW access. Set it with the given value.
                        ipc_register_map.bytes[spiCmdPtr[1] + i] = spiCmdPtr[3 + i];
                    }
                }
                break;

            default:
                break;
        }

        // Clear out the command
        memset(spiCmdPtr, 0x00, MAX_COMMAND_LEN);

        // Increment our head index
        circularBuffHead++;

        // Make sure we are in bounds
        if( circularBuffHead >= MAX_COMMAND_QUE ) {
            circularBuffHead = 0x00;
        }
    }

    return ret;
}



