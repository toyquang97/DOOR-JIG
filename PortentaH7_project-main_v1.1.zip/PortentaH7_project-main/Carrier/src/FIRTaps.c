/*
 * FIRTaps.c
 *
 *  Created on: Feb 23, 2022
 *      Author: gyurk
 */




float tenAvgTaps[10] =
{
	0.1,
	0.1,
	0.1,
	0.1,
	0.1,
	0.1,
	0.1,
	0.1,
	0.1,
	0.1
};

float fiveAvgTaps[5] =
{
    0.2,
    0.2,
    0.2,
    0.2,
    0.2
};

