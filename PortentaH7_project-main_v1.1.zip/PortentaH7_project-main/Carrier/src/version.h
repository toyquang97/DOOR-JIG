/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
version.h
*******************************************************************************/

#ifndef _VERSION_H_
#define _VERSION_H_

// Thermaquil follows the Semantic versioning scheme.
// https://semver.org/

// Major versions must match between the RT and Carrier firmware.
// Any breaking changes to the IPC or configuration registers will
// cause a rev of the Major revision. Most all other changes will
// cause a Minor or Patch change.
#define VERSION_MAJOR   3
#define VERSION_MINOR   5
#define VERSION_PATCH   1
#ifdef DEBUG_BUILD
    #define VERSION_DEBUG   1
#else
    #define VERSION_DEBUG   0
#endif

#endif // _VERSION_H_