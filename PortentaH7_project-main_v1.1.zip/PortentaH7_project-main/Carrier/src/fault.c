/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
fault.c
*******************************************************************************/

#include "fault.h"
#include "cooling.h"
#include "debug.h"
#include "error.h"
#include "ipc.h"
#include "temperature.h"
#include <stdint.h>

static int faultMsgPrinted = 0;

static app_return_code_t fault_checkForThermFaults(void)
{
	app_return_code_t ret = APP_RET_OK;
	float thermVal = 0.0;

	// First check all of the thermistors for faults
	for (uint8_t i = 0; i < sizeof(ipc_register_map.bitfields.TEMPERATURES.array); i++)
	{
		if (((i == 0) || (i == 5)))
		{
			// We don't want to report errors for Thermistor 0 or 6
			continue;
		}
		// Store the therm val for comparison
		thermVal = ipc_register_map.bitfields.TEMPERATURES.array[i];

		// Check if the current themistor is unplugged
		if ((thermVal <= -15) || (thermVal >= 58))
		{
			// Set our error return value
			ret = APP_RET_ERROR;
			// We found a problem with the thermistor
			ipc_register_map.bitfields.FAULTS.FAULT_0.byte |= (1 << i);
		}
	}

	ipc_register_map.bitfields.FAULTS.FAULT_0.byte &= ~(1 << 7);
	ipc_register_map.bitfields.FAULTS.FAULT_0.byte &= ~(1 << 6);

	return ret;
}

app_return_code_t fault_checkForFaults(void)
{
	// fault_checkForThermFaults();

	if ((ipc_register_map.bitfields.FAULTS.FAULT_0.byte || ipc_register_map.bitfields.FAULTS.FAULT_1.byte))
	{
		if (!faultMsgPrinted)
		{
			debug_writeLine(">> FAULT OCCURED [0](%02X) [1](%02X) <<", ipc_register_map.bitfields.FAULTS.FAULT_0.byte, ipc_register_map.bitfields.FAULTS.FAULT_1.byte);
			faultMsgPrinted = 1;
		}
		return APP_RET_ERROR;
	}

	return APP_RET_OK;
}

app_return_code_t fault_setFault(fault_codes_t faultCode)
{
	switch (faultCode)
	{
	case FAULT_THERM0:
		ipc_register_map.bitfields.FAULTS.FAULT_0.bits.THERM0_BOUNDARY_ERR = 0b0;
		break;

	case FAULT_THERM1:
		ipc_register_map.bitfields.FAULTS.FAULT_0.bits.THERM1_BOUNDARY_ERR = 0b0;
		break;

	case FAULT_THERM2:
		ipc_register_map.bitfields.FAULTS.FAULT_0.bits.THERM2_BOUNDARY_ERR = 0b0;
		break;

	case FAULT_THERM3:
		ipc_register_map.bitfields.FAULTS.FAULT_0.bits.THERM3_BOUNDARY_ERR = 0b0;
		break;

	case FAULT_THERM4:
		ipc_register_map.bitfields.FAULTS.FAULT_0.bits.THERM4_BOUNDARY_ERR = 0b0;
		break;

	case FAULT_THERM5:
		ipc_register_map.bitfields.FAULTS.FAULT_0.bits.THERM5_BOUNDARY_ERR = 0b0;
		break;

	case FAULT_DAC:
		ipc_register_map.bitfields.FAULTS.FAULT_1.bits.DAC_COMM_ERR = 0b0;
		break;

	case FAULT_EEPROM:
		ipc_register_map.bitfields.FAULTS.FAULT_1.bits.EEPROM_COMM_ERR = 0b0;
		break;

	case FAULT_BATT:
		ipc_register_map.bitfields.FAULTS.FAULT_1.bits.BATT_COMM_ERR = 0b0;
		break;
	default:
		break;
	}

	return APP_RET_OK;
}