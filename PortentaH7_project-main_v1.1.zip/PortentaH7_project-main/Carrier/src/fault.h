/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
fault.h
*******************************************************************************/
#ifndef _FAULT_H_
#define _FAULT_H_

#include "error.h"

typedef enum {
    FAULT_THERM0 = 0x00,
    FAULT_THERM1,
    FAULT_THERM2,
    FAULT_THERM3,
    FAULT_THERM4,
    FAULT_THERM5,
    FAULT_DAC,
    FAULT_EEPROM,
    FAULT_BATT,
    FAULT__MAX__
} fault_codes_t;

app_return_code_t fault_checkForFaults(void);
app_return_code_t fault_setFault(fault_codes_t faultCode);

#endif // _FAULT_H_