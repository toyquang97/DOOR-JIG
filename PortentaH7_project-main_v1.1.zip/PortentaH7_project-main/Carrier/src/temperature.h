#ifndef _TEMPERATURE_H_
#define _TEMPERATURE_H_

#include "error.h"
#include "ipc.h"

#define INLET_TEMPERATURE ipc_register_map.bitfields.TEMPERATURES.floats.INLET_TEMP
#define OUTLET_TEMPERATURE ipc_register_map.bitfields.TEMPERATURES.floats.OUTLET_TEMP
#define COLD_RESERVOIR_TEMPERATURE ipc_register_map.bitfields.TEMPERATURES.floats.COLD_RESV_TEMP
#define HOT_RESERVOIR_TEMPERATURE ipc_register_map.bitfields.TEMPERATURES.floats.HOT_RESV_TEMP

#define INLET_THERMISTOR_INDEX 1
#define OUTLET_THERMISTOR_INDEX 2
#define COLD_RESV_THERMISTOR_INDEX 3
#define HOT_RESV_THERMISTOR_INDEX 4

app_return_code_t temperature_init(void);
app_return_code_t temperature_retrieve(void);
float getPadTemperatue(void);

#endif // _TEMPERATURE_H_