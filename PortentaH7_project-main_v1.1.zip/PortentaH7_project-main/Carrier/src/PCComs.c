/*****************************************************************************/
/* This document and its contents are the property of Vixiar Inc. This
 * document contains confidential and/or proprietary information. The
 * reproduction, distribution, utilization or the communication of this
 * document or any part thereof, without express authorization is strictly
 * prohibited. Offenders will be held liable for the payment of damages.
 *
 * (C) 2017-2018, Vixiar.  All rights reserved.
 *
 * Project      :  Indicor Handheld Embedded Application Software
 */
/**
 * \file TestOverride.c
 */
/*
 *
 * Revision: 25SEP2018 - D.Smail : Original Release
 *           27SEP2018 - D.Smail : Modified TestGenLedPwmSineWave()
 *           01OCT2018 - D.Smail : Added TestModeViaSerial(),
 *                                 TestModeSerialInterface()  &
 *                                 GetTestModeViaSerial()
 *           28JUN2019 - D.Smail : Modified TestGenLedPwmSineWave()
 *
 *****************************************************************************/
#include "PCComs.h"
#include "board.h"
#include "cooling.h"
#include "debug.h"
#include "fsl_debug_console.h"
#include "fsl_gpio.h"
#include "globals.h"
#include "heating.h"
#include "pin_mux.h"
#include "temperature.h"
#include <math.h>
#include <stdint.h>
#include <stdlib.h>

/*******************************************************************
 *
 *     C  O  N  S  T  A  N  T  S
 *
 *******************************************************************/

/*******************************************************************
 *
 *     E  N  U  M  S
 *
 *******************************************************************/

/*******************************************************************
 *
 *    S  T  R  U  C  T  S
 *
 *******************************************************************/
uint8_t g_PCTestMode = 0;
bool m_bCheckingWatchdog = false;
uint32_t m_watchdogTimeoutTicks;

/** @brief Data structure that contains the test command and
 * data. Must be "packed". */
typedef struct
{
	/** ASCII command received via BLE */
	uint8_t command;
	/** Any data associated with the command... may or may not be used depending on the command */
	uint32_t data;
} __attribute__((packed)) sTestInfo;

/*******************************************************************
 *
 *    S  T  A  T  I  C      V  A  R  I  A  B  L  E  S
 *
 *******************************************************************/
#define TICKS_TO_DISPLAY_TEMP 2000
#define WATCHDOG_TIMEOUT_TICKS 10000

bool m_displayTemperatures = false;
uint32_t m_displayTempTime = 0;


/*******************************************************************
 *
 *    S  T  A  T  I  C      F  U  N  C  T  I  O  N  S
 *
 *******************************************************************/

/*****************************************************************************/
/**
 * @brief      Handle test mode serial commands
 *
 *             This function is called when in test mode to handle valid
 *             characters entered by the uyser via the serial port.
 *
 * @param command - user entered keystroke via the serial port
 *
 *
 */
/*
 * Revision History:
 *
 * Date & Author : 01_OCT_2018 - D.Smail
 * Description   : Original Release
 *
 *****************************************************************************/
void DisplayTemperatures(void)
{
	debug_writeLine("\r\nInlet temp = %f", g_inletTemperature);
	debug_writeLine("Outlet temp = %f", g_outletTemperature);
	debug_writeLine("Pad temp = %f", getPadTemperatue());
	debug_writeLine("Hot resv temp = %f", g_hotResevoirTemperature);
	debug_writeLine("Cold resv temp = %f", g_coldResevoirTemperature);
	debug_writeLine("States - Mode-(%d) HSP-(%f) CSP-(%f) RS-(%d) OS-(%d) CB-(%d) HB-(%d) PWM-(%f)", 
					g_systemState,
					g_hotSetpoint,
					g_coldSetpoint,
					g_outputStates.bits.RETURN_SOLENOID,
					g_outputStates.bits.OUTLET_SOLENOID,
					g_outputStates.bits.COLD_BYPASS,
					g_outputStates.bits.HOT_BYPASS,
					g_heaterPWMLevel);
}

void PCComs()
{
	char ch;
	/* List of valid characters */
	char validChars[] =
		{'+', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'D', 'd', 'A', 'a', 'V', 'W', 'w', 'F', 'f', 
	  'v', 'B', 'b', 'C', 'c', 'M', 'm', 'T', 't', 'P', 'p', 'l', 's', 'S', 'C', 'c', 'H', 'h', '.', '\r', '\n'};
	/* Holds the current string prior to a CR/LF */
	static char cmdString[50];
	/* Index into the current user entered command */
	static uint8_t cmdIndex = 0;

	status_t stat = DbgConsole_TryGetchar(&ch);
	//char command = DbgConsole_Getchar();

	if (stat != kStatus_Fail)
	{

		if (ch == '+')
		{
			if (g_PCTestMode)
			{
				g_PCTestMode = false;
			}
			else
			{
				g_PCTestMode = true;
				DbgConsole_Printf("\n\r=> ");
			}
		}

		/* Check for either CR or LF and terminate the string */
		if (ch == '\n' || ch == '\r')
		{
			cmdString[cmdIndex] = 0;
			float xdata = strtof(&cmdString[1], NULL);
			if (g_PCTestMode)
			{
				DbgConsole_Printf("\n\r");
			}
			PCComsProcessCommand(cmdString[0], xdata);
			cmdIndex = 0;
			for (int i = 0; i < 50; i++)
			{
				cmdString[i] = ' ';
			}
			if (g_PCTestMode)
			{
				DbgConsole_Printf("\n\r=> ");
			}
		}

		for (unsigned i = 0; i < sizeof(validChars); i++)
		{
			if (ch == validChars[i] && ch != '+' && ch != '\r')
			{
				/* Echo valid char back to user, invalid chars will neither be
                * echoed or stored */
				if (g_PCTestMode)
				{
					DbgConsole_Putchar(ch);
				}
				cmdString[cmdIndex++] = ch;
				break;
			}
		}
	}
	if (m_displayTemperatures)
	{
		if (BOARD_GetTick() > m_displayTempTime)
		{
			DisplayTemperatures();
			m_displayTempTime = BOARD_GetTick() + TICKS_TO_DISPLAY_TEMP;
		}
	}
	if (m_bCheckingWatchdog)
	{
		// chek for timeout
		if (BOARD_GetTick() > m_watchdogTimeoutTicks)
		{
			g_systemState = STATE_OFF;
			turnOffCooling();
			g_heaterPWMLevel = 0.0;
		}
	}
}
/*****************************************************************************/
/**
 * @brief      Processes user commands
 *
 *             This function is called to process user commands from the BLE
 *             service or from the serial port. Each message contains a character
 *             command and optional 32 bit data. This data can be anything, and
 *             in the case of the pressure override, contains a float value, which
 *             in turn must be cast to a float pointer in order to extract the
 *             proper floating point value
 *
 * @param command - ASCII command to indicate what override user wishes to change
 * @param data - optional 32 bit data associated with the command
 *
 */
/*
 * Revision History:
 *
 * Date & Author : 12_SEP_2018 - D.Smail
 * Description   : Original Release
 *
 *****************************************************************************/
void PCComsProcessCommand(char command, float data)
{
	switch (command)
	{
	case 'F':
	case 'f':
		if ((int)data == 1)
		{
			g_bFilling = true;
		}
		else
		{
			g_bFilling = false;
		}
		break;
		
	case 'w': // UpdateWatchdog
	case 'W':
		if (!m_bCheckingWatchdog)
		{
			m_bCheckingWatchdog = true;
		}
		m_watchdogTimeoutTicks = BOARD_GetTick() + WATCHDOG_TIMEOUT_TICKS;
		break;
		
	case 'T':
		m_displayTemperatures = true;
		m_displayTempTime = 0;
		break;

	case 't':
		m_displayTemperatures = false;
		break;

	case 'P':
		if (data == 1)
		{
			GPIO_PinWrite(GPIO, BOARD_PUMP1_EN_GPIO_PORT, BOARD_PUMP1_EN_GPIO_PIN, 1);
		}
		else if (data == 2)
		{
			GPIO_PinWrite(GPIO, BOARD_PUMP2_EN_GPIO_PORT, BOARD_PUMP2_EN_GPIO_PIN, 1);
		}
		break;

	case 'p':
		if (data == 1)
		{
			GPIO_PinWrite(GPIO, BOARD_PUMP1_EN_GPIO_PORT, BOARD_PUMP1_EN_GPIO_PIN, 0);
		}
		else if (data == 2)
		{
			GPIO_PinWrite(GPIO, BOARD_PUMP2_EN_GPIO_PORT, BOARD_PUMP2_EN_GPIO_PIN, 0);
		}
		break;

	case 'S':
		if (data == 1)
		{
			GPIO_PinWrite(GPIO, BOARD_nSHDN_SOL1_GPIO_PORT, BOARD_nSHDN_SOL1_GPIO_PIN, 1);
		}
		else if (data == 2)
		{
			GPIO_PinWrite(GPIO, BOARD_nSHDN_SOL2_GPIO_PORT, BOARD_nSHDN_SOL2_GPIO_PIN, 1);
		}
		else if (data == 3)
		{
			GPIO_PinWrite(GPIO, BOARD_SPARE1_EN_GPIO_PORT, BOARD_SPARE1_EN_GPIO_PIN, 1);
		}
		else if (data == 4)
		{
			GPIO_PinWrite(GPIO, BOARD_SPARE2_EN_GPIO_PORT, BOARD_SPARE2_EN_GPIO_PIN, 1);
		}

		break;

	case 's':
		if (data == 1)
		{
			GPIO_PinWrite(GPIO, BOARD_nSHDN_SOL1_GPIO_PORT, BOARD_nSHDN_SOL1_GPIO_PIN, 0);
		}
		else if (data == 2)
		{
			GPIO_PinWrite(GPIO, BOARD_nSHDN_SOL2_GPIO_PORT, BOARD_nSHDN_SOL2_GPIO_PIN, 0);
		}
		else if (data == 3)
		{
			GPIO_PinWrite(GPIO, BOARD_SPARE1_EN_GPIO_PORT, BOARD_SPARE1_EN_GPIO_PIN, 0);
		}
		else if (data == 4)
		{
			GPIO_PinWrite(GPIO, BOARD_SPARE2_EN_GPIO_PORT, BOARD_SPARE2_EN_GPIO_PIN, 0);
		}
		break;

	case 'H':
		BOARD_PWM_SetDutyCycle(100 - data);
		break;

	case 'h':
		BOARD_PWM_SetDutyCycle(100);
		break;

	case 'C':
		turnOnCooling();
		break;

	case 'c':
		turnOffCooling();
		break;

	case 'M': //Set Mode
	case 'm':
		switch ((int)data)
		{
		case 1:
			g_remoteCommand = COMMAND_GO_OFF;
			break;
		case 2:
			g_remoteCommand = COMMAND_GO_PREPARE;
			break;
		case 3:
			g_remoteCommand = COMMAND_GO_HEAT;
			break;
		case 4:
			g_remoteCommand = COMMAND_GO_COOL;
			break;
		default:
			break;
		}
		break;

	case 'V': //GetVersion
	case 'v':
		debug_writeLine("%d.%d.%d", VERSION_MAJOR, VERSION_MINOR, VERSION_PATCH);
		break;

	case 'A': // hot setpoint
	case 'a':
		g_hotSetpoint = data;
		break;

	case 'B': // cold setpoint
	case 'b':
		g_coldSetpoint = data;
		break;

	case 'D': //Get Temperature
	case 'd':
		switch ((int)data)
		{
		case 1:
			debug_writeLine("%f", g_hotResevoirTemperature);
			break;
		case 2:
			debug_writeLine("%f", g_coldResevoirTemperature);
			break;
		case 3:
			debug_writeLine("%f", g_outletTemperature);
			break;
		case 4:
			debug_writeLine("%f", g_inletTemperature);
			break;
		case 5:
			debug_writeLine("%f", getPadTemperatue());
			break;
		default:
			break;
		}

	default:
		break;
	}
}
