   /******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
heating.c
*******************************************************************************/

#include "heating.h"
#include "board.h"
#include "board_pwm.h"
#include "debug.h"
#include "error.h"
#include "fsl_gpio.h"
#include "globals.h"
#include "ipc.h"
#include "pin_mux.h"
#include "temperature.h"
#include "math.h"
#include <stdint.h>
   
static float heaterPIControl(float tubeHeatSetpoint, float currentTemperature);

#define HEATER_ON_PWM_PCT (60)
#define HEATING_TICK_RATE (500)
#define MIN_RESISTOR_ON_TIME (1000)
#define MIN_RESISTOR_OFF_TIME (1000)
#define HEATING_OVERSHOOT_AMNT (0)
#define HEATING_SETPOINT_ADJUST (3)

uint32_t heating_refTime = 0x00;

app_return_code_t heating_init(void)
{
	app_return_code_t ret = APP_RET_OK;

	heating_refTime = 0x00;
	g_heaterPWMLevel = 0.0;

	return ret;
}

app_return_code_t heating_update(void)
{
	app_return_code_t ret = APP_RET_OK;
	float currentTemperature = 0x00;

	if ((g_systemState == STATE_FAULT) ||
		(g_systemState == STATE_OFF))
	{
		return g_heaterPWMLevel = 0.0;
	}

	// Only tick the heating checks every 500ms
	if (BOARD_GetTick() > (heating_refTime + HEATING_TICK_RATE))
	{
		// Update the heating refTime
		heating_refTime = BOARD_GetTick();

		if ((g_systemState == STATE_HEAT) || (g_systemState == STATE_TRANSITION_TO_HEAT))
		{
			currentTemperature = getPadTemperatue();
		}
		else
		{
			// pretend the resevoir temp is a little lower so it heats more
			// for when the cooling cycle is going to make sure the hot resevoir is higher than the setpoint
			if ((g_systemState != STATE_PREPARING))
			{
				currentTemperature = g_hotResevoirTemperature - HEATING_SETPOINT_ADJUST;
			}
			else
			{
				currentTemperature = g_hotResevoirTemperature;
			}
		}

		if ((g_systemState == STATE_OFF) || (g_systemState == STATE_FAULT))
		{
			g_heaterPWMLevel = 0;
		}
		else
		{
			g_heaterPWMLevel = heaterPIControl(g_hotSetpoint, currentTemperature);
		}

#if 0
		// Check our reservoir temp against the setpoint
		if ((!g_outputStates.bits.HEATER) && (currentTemperature < g_hotSetpoint))
		{
			// Reservoir is not hot enough. Turn on the resistor if we can.
			// First make sure we are within our cycle time
			// OR if the off ref time is zero (meaning it's our first time turning the resistor on.)
//			if ((resistor_off_refTime == 0x00) || (BOARD_GetTick() > (resistor_off_refTime + MIN_RESISTOR_OFF_TIME)))
			{
				// Store our flag saying the resistor is on.
				g_outputStates.bits.HEATER = 1;
				// Update the time that we turned on the resistor
				resistor_on_refTime = BOARD_GetTick();
			}
		}
		else if ((g_outputStates.bits.HEATER) && (currentTemperature >= (g_hotSetpoint - HEATING_OVERSHOOT_AMNT)))
		{
			// We've met our exceeded the heating reservoir setpoint.. We should turn off the resistor if we can
			// First make sure we are within our cycle time
//			if ((BOARD_GetTick() > (resistor_on_refTime + MIN_RESISTOR_ON_TIME)))
			{
				g_outputStates.bits.HEATER = 0;
			}
		}
#endif
		
	}

	return ret;
}

#if 0
app_return_code_t heating_disable(void)
{
	// Deinit the Heater PWM and set our pin to a GPIO
	g_heaterPWMLevel = 0.0;
	BOARD_PWM_DeInit();

	return APP_RET_OK;
}
#endif

#define HEATER_I_GAIN (0.03)
#define HEATER_P_GAIN (15)
#define MAX_PWM (100)
static float m_heaterControlIntegrator = 0.0;

static float heaterPIControl(float tubeHeatSetpoint, float currentTemperature)
{
	float error = tubeHeatSetpoint - currentTemperature;
	float outputPWM = error * HEATER_P_GAIN + m_heaterControlIntegrator * HEATER_I_GAIN;
	if (outputPWM < 0)
	{
		outputPWM = 0.0;
	}
	if (outputPWM > MAX_PWM)
	{
		outputPWM = MAX_PWM;
	}
	if (outputPWM < MAX_PWM && outputPWM > 0.0)
	{
		m_heaterControlIntegrator += error;
	}
	return outputPWM;
}