/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
board_i2c.h
*******************************************************************************/

#ifndef _BOARD_I2C_H_
#define _BOARD_I2C_H_

#include "error.h"

typedef enum {
    BOARD_I2C_DEV_DAC = 0x00,
    BOARD_I2C_DEV_HPI,
    BOARD_I2C_DEV_iMX,
    BOARD_I2C_DEV_CHG,
    BOARD_I2C_DEV__MAX__
} board_i2c_dev_t;

#ifdef TEST
void __TEST__BOARD_I2C_SetCallbackFlag(bool val);
#endif
void BOARD_I2C_Init(void);
app_return_code_t BOARD_I2C_Write(const board_i2c_dev_t device, const uint8_t busAddr, const uint8_t *buff, const uint32_t len);
app_return_code_t BOARD_I2C_Read(const board_i2c_dev_t device, const uint8_t busAddr, uint8_t *buff, const uint32_t len);

#endif // _BOARD_I2C_H_