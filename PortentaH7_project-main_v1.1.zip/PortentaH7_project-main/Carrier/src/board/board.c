/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
board.c
*******************************************************************************/

#include <stdint.h>
#include "fsl_common.h"
#include "fsl_debug_console.h"
#include "fsl_inputmux.h"
#include "fsl_power.h"
#include "clock_config.h"
#include "pin_mux.h"
#include "board.h"
#include "board_adc.h"
#include "board_spi.h"
#include "board_i2c.h"
#include "board_uart.h"
#include "board_pwm.h"

/*******************************************************************************
 * Variables
 ******************************************************************************/
volatile uint32_t g_systickCounter;
volatile uint32_t g_delayCounter;

/*******************************************************************************
 * Code
 ******************************************************************************/
void SysTick_Handler(void)
{
    if (g_delayCounter != 0U)
    {
        g_delayCounter--;
    }

    g_systickCounter++;
}

void BOARD_Init(void) {


    // Power Init
    POWER_SetBodVbatLevel(kPOWER_BodVbatLevel1650mv, kPOWER_BodHystLevel50mv, false);

    // Clock configuration
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM0);
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM1);
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM2);
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM3);
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM4);
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM5);
    CLOCK_AttachClk(kFRO12M_to_FLEXCOMM6);
    CLOCK_AttachClk(kMAIN_CLK_to_ADC_CLK);
    CLOCK_SetClkDiv(kCLOCK_DivAdcAsyncClk, 8U, true);
    // Set our bot clock
    BOARD_InitBootClocks();
    // Set our SysTick frequency
    SysTick_Config(SystemCoreClock / 1000U);
    // Power Init
    POWER_DisablePD(kPDRUNCFG_PD_LDOGPADC);

    // Reset all of our flexcomm modules
    RESET_PeripheralReset(kFC0_RST_SHIFT_RSTn);
    RESET_PeripheralReset(kFC1_RST_SHIFT_RSTn);
    RESET_PeripheralReset(kFC2_RST_SHIFT_RSTn);
    RESET_PeripheralReset(kFC3_RST_SHIFT_RSTn);
    RESET_PeripheralReset(kFC4_RST_SHIFT_RSTn);
    RESET_PeripheralReset(kFC5_RST_SHIFT_RSTn);
    RESET_PeripheralReset(kFC6_RST_SHIFT_RSTn);

    // Board pin init
    BOARD_InitPins();
    // Init our serial comm modules
    BOARD_UART_Init();
    BOARD_I2C_Init();
    BOARD_SPI_Slave_Init();
    // Init the ADC module
    BOARD_ADC_Init();
    // Init the PWM module
    BOARD_PWM_Init();
}

void BOARD_DelayTicks(uint32_t n)
{
    g_delayCounter = n;
    while (g_delayCounter != 0U)
    {
    }
}

uint32_t BOARD_GetTick(void) {
    return g_systickCounter;
}