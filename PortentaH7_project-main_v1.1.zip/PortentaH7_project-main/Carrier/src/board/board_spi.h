/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
board_spi.h
*******************************************************************************/

#ifndef _BOARD_SPI_H_
#define _BOARD_SPI_H_

#include "error.h"

typedef app_return_code_t(*board_spi_xfer_fptr_t)(void);

void BOARD_SPI_Slave_Init(void);
app_return_code_t BOARD_SPI_SetRxCallback(board_spi_xfer_fptr_t cb);
app_return_code_t BOARD_SPI_SetTxBuffer(uint8_t *txBuff, uint16_t len);
app_return_code_t BOARD_SPI_GetRxData(uint8_t *dest, uint16_t len);

#endif // _BOARD_SPI_H_