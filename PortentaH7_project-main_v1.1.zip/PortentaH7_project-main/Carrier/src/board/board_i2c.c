/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
board_i2c.c
*******************************************************************************/

#include <stdint.h>
#include "fsl_i2c.h"
#include "board.h"
#include "board_i2c.h"
#include "error.h"

// DAC I2C
#define BOARD_DAC_I2C_BASE          I2C3_BASE
#define BOARD_DAC_I2C_FREQ          12000000U
#define BOARD_DAC_I2C_BAUD          100000U
// HPI I2C
#define BOARD_HPI_I2C_BASE          I2C1_BASE
#define BOARD_HPI_I2C_FREQ          12000000U
#define BOARD_HPI_I2C_BAUD          100000U
// iMX I2C
#define BOARD_iMX_I2C_BASE          I2C2_BASE
#define BOARD_iMX_I2C_FREQ          12000000U
#define BOARD_iMX_I2C_BAUD          100000U
// CHG I2C
#define BOARD_CHG_I2C_BASE          I2C6_BASE
#define BOARD_CHG_I2C_FREQ          12000000U
#define BOARD_CHG_I2C_BAUD          100000U
// I2C Transfer Timeout
#define BOARD_I2C_TIMEOUT_DUR       500

static i2c_master_handle_t DAC_I2C_handle;
static i2c_master_handle_t HPI_I2C_handle;
static i2c_master_handle_t iMX_I2C_handle;
static i2c_master_handle_t CHG_I2C_handle;
static bool i2c_complete_flag = false;

#ifdef TEST
// Use this function in unit tests to write
// our i2c complete flag
void __TEST__BOARD_I2C_SetCallbackFlag(bool val) {
    i2c_complete_flag = val;
}
#endif

static void _BOARD_I2C_Callback(I2C_Type *base, i2c_master_handle_t *handle, status_t status, void *userData) {
    if( status == kStatus_Success ) {
        i2c_complete_flag = true;
    }
}

static app_return_code_t _BOARD_I2C_Transfer(const board_i2c_dev_t device, bool write_nread, const uint8_t busAddr, uint8_t *buff, const uint32_t len) {
    i2c_master_transfer_t xferConfig = {0};
    uint32_t retVal = 0;
    uint32_t tickCount = 0;
    uint32_t base = 0x00;
    i2c_master_handle_t *handle;


    if( (device >= BOARD_I2C_DEV__MAX__) || (busAddr > 0x7F) || (len <= 0)) {
        return APP_RET_INV_PARAM;
    }
    else if( buff == NULL ) {
        return APP_RET_NULL_PTR;
    }

    xferConfig.slaveAddress = busAddr;
    xferConfig.direction = (write_nread ? kI2C_Write : kI2C_Read);
    xferConfig.data = buff;
    xferConfig.dataSize = len;
    xferConfig.flags = kI2C_TransferDefaultFlag;

// When running unit tests, we want to use our API to determine the
// complete flag value. Don't overwrite it.
#ifndef TEST
    i2c_complete_flag = false;
#endif

    switch(device) {
        case BOARD_I2C_DEV_DAC:
            base = BOARD_DAC_I2C_BASE;
            handle = &DAC_I2C_handle;
            break;
        case BOARD_I2C_DEV_HPI:
            base = BOARD_HPI_I2C_BASE;
            handle = &HPI_I2C_handle;
            break;
        case BOARD_I2C_DEV_iMX:
            base = BOARD_iMX_I2C_BASE;
            handle = &iMX_I2C_handle;
            break;
        case BOARD_I2C_DEV_CHG:
            base = BOARD_CHG_I2C_BASE;
            handle = &CHG_I2C_handle;
            break;
        default:
            return APP_RET_INV_PARAM;
            break;
    }

    retVal = I2C_MasterTransferNonBlocking((I2C_Type *)base, handle, &xferConfig);

    if( kStatus_I2C_Busy == retVal ) {
        return APP_RET_BUSY;
    }
    else if( kStatus_Success != retVal ) {
        return APP_RET_ERROR;
    }

    while(!i2c_complete_flag) {
        BOARD_DelayTicks(1);
        tickCount++;

        if( tickCount >= BOARD_I2C_TIMEOUT_DUR ) {
            I2C_MasterTransferAbort((I2C_Type *)base, handle);
            return APP_RET_TIMEOUT;
        }
    }

    return APP_RET_OK;
}

void BOARD_I2C_Init(void) {
    i2c_master_config_t DAC_I2C_Config;
    i2c_master_config_t HPI_I2C_Config;
    i2c_master_config_t iMX_I2C_Config;
    i2c_master_config_t CHG_I2C_Config;

    // ****************************** DAC ******************************
    // Retrieve the default config
    I2C_MasterGetDefaultConfig(&DAC_I2C_Config);
    // Set our desired baud rate
    DAC_I2C_Config.baudRate_Bps = BOARD_DAC_I2C_BAUD;
    // Init the DAC I2C bus using our config
    I2C_MasterInit((I2C_Type *)BOARD_DAC_I2C_BASE, &DAC_I2C_Config, BOARD_DAC_I2C_FREQ);
    // Init the handle & callback for this I2C module
    I2C_MasterTransferCreateHandle((I2C_Type *)BOARD_DAC_I2C_BASE, &DAC_I2C_handle, _BOARD_I2C_Callback, NULL);

    // ****************************** HPI ******************************
    // Retrieve the default config
    I2C_MasterGetDefaultConfig(&HPI_I2C_Config);
    // Set our desired baud rate
    HPI_I2C_Config.baudRate_Bps = BOARD_HPI_I2C_BAUD;
    // Init the DAC I2C bus using our config
    I2C_MasterInit((I2C_Type *)BOARD_HPI_I2C_BASE, &HPI_I2C_Config, BOARD_HPI_I2C_FREQ);
    // Init the handle & callback for this I2C module
    I2C_MasterTransferCreateHandle((I2C_Type *)BOARD_HPI_I2C_BASE, &HPI_I2C_handle, _BOARD_I2C_Callback, NULL);

    // ****************************** iMX ******************************
    // Retrieve the default config
    I2C_MasterGetDefaultConfig(&iMX_I2C_Config);
    // Set our desired baud rate
    iMX_I2C_Config.baudRate_Bps = BOARD_iMX_I2C_BAUD;
    // Init the DAC I2C bus using our config
    I2C_MasterInit((I2C_Type *)BOARD_iMX_I2C_BASE, &iMX_I2C_Config, BOARD_iMX_I2C_FREQ);
    // Init the handle & callback for this I2C module
    I2C_MasterTransferCreateHandle((I2C_Type *)BOARD_iMX_I2C_BASE, &iMX_I2C_handle, _BOARD_I2C_Callback, NULL);

    // ****************************** CHG ******************************
    // Retrieve the default config
    I2C_MasterGetDefaultConfig(&CHG_I2C_Config);
    // Set our desired baud rate
    CHG_I2C_Config.baudRate_Bps = BOARD_CHG_I2C_BAUD;
    // Init the DAC I2C bus using our config
    I2C_MasterInit((I2C_Type *)BOARD_CHG_I2C_BASE, &CHG_I2C_Config, BOARD_CHG_I2C_FREQ);
    // Init the handle & callback for this I2C module
    I2C_MasterTransferCreateHandle((I2C_Type *)BOARD_CHG_I2C_BASE, &CHG_I2C_handle, _BOARD_I2C_Callback, NULL);
}

app_return_code_t BOARD_I2C_Write(const board_i2c_dev_t device, const uint8_t busAddr, const uint8_t *buff, const uint32_t len) {
    return _BOARD_I2C_Transfer(device, true, busAddr, (uint8_t *)buff, len);
}

app_return_code_t BOARD_I2C_Read(const board_i2c_dev_t device, const uint8_t busAddr, uint8_t *buff, const uint32_t len) {
    return _BOARD_I2C_Transfer(device, false, busAddr, buff, len);
}