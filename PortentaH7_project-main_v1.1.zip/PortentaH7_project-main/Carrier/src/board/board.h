/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
board.h
*******************************************************************************/

#ifndef _BOARD_H_
#define _BOARD_H_

#include <stdint.h>

/*******************************************************************************
 * Definitions
 ******************************************************************************/
/*! @brief The board name */
#define BOARD_NAME "ThermaquilQuantumController"

/*******************************************************************************
 * API
 ******************************************************************************/
void BOARD_Init(void);
void BOARD_DelayTicks(uint32_t n);
uint32_t BOARD_GetTick(void);

#endif /* _BOARD_H_ */
