/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
board_uart.c
*******************************************************************************/

#include <stdint.h>
#include "board.h"
#include "board_uart.h"
#include "error.h"
#include "fsl_debug_console.h"

#define BOARD_DEBUG_UART_TYPE       kSerialPort_Uart
#define BOARD_DEBUG_UART_INSTANCE   5U
#define BOARD_DEBUG_UART_FREQ       12000000U
#define BOARD_UART_IRQ_HANDLER      FLEXCOMM5_IRQHandler
#define BOARD_UART_IRQ              FLEXCOMM5_IRQn
#define BOARD_DEBUG_UART_BAUDRATE   115200U

void BOARD_UART_Init(void) {
    DbgConsole_Init(BOARD_DEBUG_UART_INSTANCE, BOARD_DEBUG_UART_BAUDRATE, BOARD_DEBUG_UART_TYPE, BOARD_DEBUG_UART_FREQ);
}