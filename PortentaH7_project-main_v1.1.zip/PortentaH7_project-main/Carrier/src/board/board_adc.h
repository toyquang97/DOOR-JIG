/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
board_adc.h
*******************************************************************************/

#ifndef _BOARD_ADC_H_
#define _BOARD_ADC_H_

#include <stdint.h>
#include <stdbool.h>
#include "error.h"

typedef enum {
    BOARD_ADC_CH_VTHERM1 = 0x00,
    BOARD_ADC_CH_VTHERM2,
    BOARD_ADC_CH_VTHERM3,
    BOARD_ADC_CH_VTHERM4,
    BOARD_ADC_CH_VTHERM5,
    BOARD_ADC_CH_VTHERM6,
    BOARD_ADC_CH_RES,
    BOARD_ADC_CH_COMP,
    BOARD_ADC_CH__MAX__
} adc_channels_t;

typedef app_return_code_t(*board_adc_conv_complete_fptr_t)(void);

void BOARD_ADC_Init(void);
app_return_code_t BOARD_ADC_Read(void);
app_return_code_t BOARD_ADC_SetConvCompleteCallback(board_adc_conv_complete_fptr_t cb);

extern uint16_t board_adc_conv_results[BOARD_ADC_CH__MAX__];

#endif // _BOARD_ADC_H_