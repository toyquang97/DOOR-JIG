/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
board_pwm.c
*******************************************************************************/

#include "error.h"
#include "board_pwm.h"
#include "pin_mux.h"
#include "fsl_sctimer.h"

#define SCTIMER_BASE        SCT0
#define SCTIMER_CLK_FREQ    CLOCK_GetFreq(kCLOCK_BusClk)
#define H_RES_SCTIMER_OUT   kSCTIMER_Out_2
#define FAN_SCTIMER_OUT     kSCTIMER_Out_4

static bool initialized = false;
static sctimer_config_t sctimerInfo;
uint32_t sctimerEvent;

app_return_code_t BOARD_PWM_Init(void) {
    app_return_code_t retVal = APP_RET_OK;
    sctimer_pwm_signal_param_t pwmParam = {0x00};

    pwmParam.level = kSCTIMER_HighTrue;
    pwmParam.dutyCyclePercent = 0x00;
    pwmParam.output = H_RES_SCTIMER_OUT;

    // Remux the PWM pin as a PWM
    BOARD_MuxPwmAsGpio(false);

    // Retrieve the default sctimeInfo
    SCTIMER_GetDefaultConfig(&sctimerInfo);

    // Initialize SCTimer module
    SCTIMER_Init(SCTIMER_BASE, &sctimerInfo);

    // Setup the PWM
    SCTIMER_SetupPwm(SCTIMER_BASE, &pwmParam, kSCTIMER_EdgeAlignedPwm, 5000, SCTIMER_CLK_FREQ, &sctimerEvent);

    // Start the timer
    SCTIMER_StartTimer(SCTIMER_BASE, kSCTIMER_Counter_U);

    // Set our initialized flag
    initialized = true;

    // Turn the Heating resistor off to being with
    retVal = BOARD_PWM_SetDutyCycle(0x00);

    return retVal;
}

void BOARD_PWM_DeInit(void) {

    if( initialized ) {
        // Deinit the SCTIMER
        SCTIMER_Deinit(SCTIMER_BASE);
        // Mux the PWM pin as a GPIO
        BOARD_MuxPwmAsGpio(true);
        // Clear our initialized flag
        initialized = false;
    }
}

app_return_code_t BOARD_PWM_SetDutyCycle(const uint8_t dutyCycle) {
    if( !initialized ) {
        // Init the PWM
        BOARD_PWM_Init();
    }

    SCTIMER_UpdatePwmDutycycle(SCTIMER_BASE, H_RES_SCTIMER_OUT, dutyCycle, sctimerEvent);

    return APP_RET_OK;
}