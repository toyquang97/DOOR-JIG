/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
board_uart.h
*******************************************************************************/

#ifndef _BOARD_UART_H_
#define _BOARD_UART_H_

#include "error.h"

void BOARD_UART_Init(void);

#endif // _BOARD_UART_H_