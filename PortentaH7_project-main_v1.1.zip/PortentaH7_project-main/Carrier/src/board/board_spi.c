/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
board_spi.c
*******************************************************************************/

#include <stdint.h>
#include "fsl_spi.h"
#include "fsl_spi_dma.h"
#include "fsl_dma.h"
#include "fsl_flexcomm.h"
#include "board.h"
#include "board_spi.h"
#include "error.h"

// SPI RX/TX Buffer size
#define BOARD_iMX_SPI_RX_BUFF_SIZE          128

// iMX RT SPI Slave
#define BOARD_iMX_SPI_SLAVE_BASE            SPI4
#define BOARD_iMX_SPI_SLAVE_SSEL            1
#define BOARD_iMX_SPI_SLAVE_SPOL            kSPI_SpolActiveAllLow
#define BOARD_iMX_SPI_SLAVE_IRQN            FLEXCOMM4_IRQn
#define BOARD_iMX_SPI_DMA                   DMA0
#define BOARD_iMX_SPI_SLAVE_RX_CHANNEL      12
#define BOARD_iMX_SPI_SLAVE_TX_CHANNEL      13

board_spi_xfer_fptr_t CB_spi_data_rcvd = NULL;

uint8_t rxBuff[BOARD_iMX_SPI_RX_BUFF_SIZE] = {0x00};

uint8_t *txBuff_ptr = NULL;
uint16_t txBuff_len = 0x00;
uint16_t rxIndex = 0;
uint16_t txIndex = 0;
uint16_t fifoFillIndex = 0;

dma_handle_t slaveTxHandle;
dma_handle_t slaveRxHandle;
spi_dma_handle_t slaveHandle;

static void _BOARD_SPI_Init(void);
static void _BOARD_SPI_Callback(SPI_Type *base, spi_dma_handle_t *handle, status_t status, void *userData);

static void _BOARD_SPI_Callback(SPI_Type *base, spi_dma_handle_t *handle, status_t status, void *userData) {
    BOARD_SPI_SetTxBuffer(txBuff_ptr, txBuff_len);
}

static void _flexcomm_handler(void *base, void *handle) {
    // Check if the irq is becuase we received new data
    if( BOARD_iMX_SPI_SLAVE_BASE->STAT & SPI_STAT_SSD_MASK ) {
        // Clear the de-asserted status
        BOARD_iMX_SPI_SLAVE_BASE->STAT &= SPI_STAT_SSD_MASK;

        // Check if the callback is NULL. If not, then call it.
        if( NULL != CB_spi_data_rcvd ) {
            // This callback is just to let the consumer know new data was just received.
            if( CB_spi_data_rcvd() == APP_RET_OK ) {
                memset(rxBuff, 0x00, sizeof(rxBuff));
            }
        }
    }
}

static void _BOARD_SPI_Init(void) {
    spi_slave_config_t slaveConfig;

    // Init the SPI slave device
    SPI_SlaveGetDefaultConfig(&slaveConfig);
    slaveConfig.sselPol = (spi_spol_t)BOARD_iMX_SPI_SLAVE_SPOL;
    SPI_SlaveInit(BOARD_iMX_SPI_SLAVE_BASE, &slaveConfig);

    // Init the DMA
    DMA_Init(BOARD_iMX_SPI_DMA);
    /* configure channel/priority and create handle for TX and RX. */
    DMA_EnableChannel(BOARD_iMX_SPI_DMA, BOARD_iMX_SPI_SLAVE_TX_CHANNEL);
    DMA_EnableChannel(BOARD_iMX_SPI_DMA, BOARD_iMX_SPI_SLAVE_RX_CHANNEL);
    DMA_SetChannelPriority(BOARD_iMX_SPI_DMA, BOARD_iMX_SPI_SLAVE_TX_CHANNEL, kDMA_ChannelPriority0);
    DMA_SetChannelPriority(BOARD_iMX_SPI_DMA, BOARD_iMX_SPI_SLAVE_RX_CHANNEL, kDMA_ChannelPriority1);
    DMA_CreateHandle(&slaveTxHandle, BOARD_iMX_SPI_DMA, BOARD_iMX_SPI_SLAVE_TX_CHANNEL);
    DMA_CreateHandle(&slaveRxHandle, BOARD_iMX_SPI_DMA, BOARD_iMX_SPI_SLAVE_RX_CHANNEL);

    /* Create handle for slave instance. */
    SPI_SlaveTransferCreateHandleDMA(BOARD_iMX_SPI_SLAVE_BASE, &slaveHandle, _BOARD_SPI_Callback, NULL, &slaveTxHandle,
                                     &slaveRxHandle);

    // We also want to create a flexcom based handler..
    FLEXCOMM_SetIRQHandler(BOARD_iMX_SPI_SLAVE_BASE, _flexcomm_handler, NULL);

    EnableIRQ(BOARD_iMX_SPI_SLAVE_IRQN);
    // // Enable our interrupts for SSEL Deassert
    BOARD_iMX_SPI_SLAVE_BASE->INTENSET |= SPI_INTENSET_SSDEN_MASK;
}

static void _BOARD_SPI_FlushTx(void) {
    BOARD_iMX_SPI_SLAVE_BASE->FIFOCFG |= SPI_FIFOCFG_EMPTYTX(1);
}

void BOARD_SPI_Slave_Init(void) {
    // Run through our init sub-function
    _BOARD_SPI_Init();
}

app_return_code_t BOARD_SPI_SetRxCallback(board_spi_xfer_fptr_t cb) {

    if( cb == NULL ) {
        return APP_RET_NULL_PTR;
    }

    // Store the callback
    CB_spi_data_rcvd = cb;

    return APP_RET_OK;
}

app_return_code_t BOARD_SPI_SetTxBuffer(uint8_t *buff, uint16_t len) {
    spi_transfer_t slaveXfer;

    if( buff == NULL ) {
        return APP_RET_NULL_PTR;
    }
    else if( len <= 0 ) {
        return APP_RET_INV_PARAM;
    }

    // Store this.. We may need to reset the buffers later and we will use this.
    txBuff_ptr = buff;
    txBuff_len = len;

    slaveXfer.txData   = buff;
    slaveXfer.rxData   = (uint8_t *)&rxBuff;
    slaveXfer.dataSize = sizeof(rxBuff);

    /* Start transfer, when transmission complete, the SPI_SlaveUserCallback will be called. */
    if (kStatus_SPI_Busy == SPI_SlaveTransferDMA(BOARD_iMX_SPI_SLAVE_BASE, &slaveHandle, &slaveXfer))
    {
        SPI_SlaveTransferAbortDMA(BOARD_iMX_SPI_SLAVE_BASE, &slaveHandle);
        SPI_SlaveTransferDMA(BOARD_iMX_SPI_SLAVE_BASE, &slaveHandle, &slaveXfer);
    }

    // Flush the TX fifo so we reload the buffer with our correct data
    _BOARD_SPI_FlushTx();

    return APP_RET_OK;
}

app_return_code_t BOARD_SPI_GetRxData(uint8_t *dest, uint16_t len) {
    app_return_code_t ret = APP_RET_OK;

    if( dest == NULL) {
        return APP_RET_NULL_PTR;
    }

    // Copy the current RX data buffer into the given dest buffer
    memcpy(dest, rxBuff, len);

    // Flush the fifo now that we've handed off the data
    BOARD_SPI_SetTxBuffer(txBuff_ptr, txBuff_len);

    return ret;
}