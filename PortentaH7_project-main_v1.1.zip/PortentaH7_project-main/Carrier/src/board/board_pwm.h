#ifndef _BOARD_PWM_H_
#define _BOARD_PWM_H_

#include "error.h"
#include <stdint.h>

typedef enum {
    BOARD_PWM_DEV_H_RES = 0x00,
    BOARD_PWM_DEV_FANS,
    BOARD_PWM_DEV__MAX__
} board_pwm_dev_t;

app_return_code_t BOARD_PWM_Init(void);
app_return_code_t BOARD_PWM_SetDutyCycle(const uint8_t dutyCycle);
void BOARD_PWM_DeInit();

#endif // _BOARD_PWM_H_