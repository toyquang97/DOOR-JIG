/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
board_adc.c
*******************************************************************************/

#include "error.h"
#include "board_adc.h"
#include "fsl_lpadc.h"

// Command ID used for trigger reads
#define LPADC_USER_CMDID            1U /* CMD1 */

// ADC Configuration
static lpadc_config_t lpadc_config;
// ADC Command Configuration - One for each ADC channel
static lpadc_conv_command_config_t adc_config_vtherm1 = {0};
static lpadc_conv_command_config_t adc_config_vtherm2 = {0};
static lpadc_conv_command_config_t adc_config_vtherm3 = {0};
static lpadc_conv_command_config_t adc_config_vtherm4 = {0};
static lpadc_conv_command_config_t adc_config_vtherm5 = {0};
static lpadc_conv_command_config_t adc_config_vtherm6 = {0};
static lpadc_conv_command_config_t adc_config_ures = {0};
static lpadc_conv_command_config_t adc_config_ucomp = {0};
// ADC Converion Trigger Config
static lpadc_conv_trigger_config_t mLpadcTriggerConfigStruct;
// ADC Results
static lpadc_conv_result_t adc_results;
// ADC Conversion complete flag
static bool adc_conv_complete = true;
// ADC Conversion index variable
static adc_channels_t currentADCchannel = BOARD_ADC_CH_VTHERM1;
// ADC Conversion Complete Callback
static board_adc_conv_complete_fptr_t CB_conversionComplete = NULL;
// Publicly available ADC results
uint16_t board_adc_conv_results[BOARD_ADC_CH__MAX__];

void ADC0_IRQHandler(void) {
    // Retrieve the conversion results
    LPADC_GetConvResult(ADC0, &adc_results, 0);

    switch( currentADCchannel ) {
        case BOARD_ADC_CH_VTHERM1:
            // Store the ADC result
            board_adc_conv_results[currentADCchannel] = adc_results.convValue;
            // Load config for the next ADC channel
            LPADC_SetConvCommandConfig(ADC0, LPADC_USER_CMDID, &adc_config_vtherm2);
            break;

        case BOARD_ADC_CH_VTHERM2:
            // Store the ADC result
            board_adc_conv_results[currentADCchannel] = adc_results.convValue;
            // Load config for the next ADC channel
            LPADC_SetConvCommandConfig(ADC0, LPADC_USER_CMDID, &adc_config_vtherm3);
            break;

        case BOARD_ADC_CH_VTHERM3:
            // Store the ADC result
            board_adc_conv_results[currentADCchannel] = adc_results.convValue;
            // Load config for the next ADC channel
            LPADC_SetConvCommandConfig(ADC0, LPADC_USER_CMDID, &adc_config_vtherm4);
            break;

        case BOARD_ADC_CH_VTHERM4:
            // Store the ADC result
            board_adc_conv_results[currentADCchannel] = adc_results.convValue;
            // Load config for the next ADC channel
            LPADC_SetConvCommandConfig(ADC0, LPADC_USER_CMDID, &adc_config_vtherm5);
            break;

        case BOARD_ADC_CH_VTHERM5:
            // Store the ADC result
            board_adc_conv_results[currentADCchannel] = adc_results.convValue;
            // Load config for the next ADC channel
            LPADC_SetConvCommandConfig(ADC0, LPADC_USER_CMDID, &adc_config_vtherm6);
            break;

        case BOARD_ADC_CH_VTHERM6:
            // Store the ADC result
            board_adc_conv_results[currentADCchannel] = adc_results.convValue;
            // Load config for the next ADC channel
            LPADC_SetConvCommandConfig(ADC0, LPADC_USER_CMDID, &adc_config_ures);
            break;

        case BOARD_ADC_CH_RES:
            // Store the ADC result
            board_adc_conv_results[currentADCchannel] = adc_results.convValue;
            // Load config for the next ADC channel
            LPADC_SetConvCommandConfig(ADC0, LPADC_USER_CMDID, &adc_config_ucomp);
            break;

        case BOARD_ADC_CH_COMP:
            // Store the ADC result
            board_adc_conv_results[currentADCchannel] = adc_results.convValue;
            break;

        default:
            // Ensure the ADC channel is set to our max
            // This will cause the following IF to just cancel further reads
            currentADCchannel = BOARD_ADC_CH__MAX__;
            break;
    }

    if( currentADCchannel >= BOARD_ADC_CH__MAX__ ) {
        // If we have a conversion complete callback. Execute it.
        if( CB_conversionComplete != NULL ) {
            CB_conversionComplete();
        }
        // Mark the ADC conversions as complete.
        adc_conv_complete = true;
        currentADCchannel = BOARD_ADC_CH_VTHERM1;
    }
    else {
        // Increment the current ADC channel
        currentADCchannel++;
        // Start the next ADC read
        LPADC_DoSoftwareTrigger(ADC0, LPADC_USER_CMDID);
    }

    return;
}

void BOARD_ADC_Init(void) {

    // Clear out the conversion results
    memset(board_adc_conv_results, 0x00, sizeof(board_adc_conv_results));

    // Get the default ADC configuration
    LPADC_GetDefaultConfig(&lpadc_config);
    // Enable prelim ADC readiness at the cost of current draw
    lpadc_config.enableAnalogPreliminary = true;
    // Set our reference to VREFP - 3.3V
    lpadc_config.referenceVoltageSource = kLPADC_ReferenceVoltageAlt3;
    // Average 128 samples in software before reporting a result
    lpadc_config.conversionAverageMode = kLPADC_ConversionAverage1;
    // Apply the new configuration for the LPADC module
    LPADC_Init(ADC0, &lpadc_config);

    // Set the corresponding channel mode and numbers for each ADC input
    adc_config_vtherm1.sampleChannelMode = kLPADC_SampleChannelSingleEndSideA;
    adc_config_vtherm1.conversionResolutionMode = kLPADC_ConversionResolutionHigh;
    adc_config_vtherm1.channelNumber = 1;

    adc_config_vtherm2.sampleChannelMode = kLPADC_SampleChannelSingleEndSideA;
    adc_config_vtherm2.conversionResolutionMode = kLPADC_ConversionResolutionHigh;
    adc_config_vtherm2.channelNumber = 2;

    adc_config_vtherm3.sampleChannelMode = kLPADC_SampleChannelSingleEndSideB;
    adc_config_vtherm3.conversionResolutionMode = kLPADC_ConversionResolutionHigh;
    adc_config_vtherm3.channelNumber = 0;

    adc_config_vtherm4.sampleChannelMode = kLPADC_SampleChannelSingleEndSideA;
    adc_config_vtherm4.conversionResolutionMode = kLPADC_ConversionResolutionHigh;
    adc_config_vtherm4.channelNumber = 0;

    adc_config_vtherm5.sampleChannelMode = kLPADC_SampleChannelSingleEndSideA;
    adc_config_vtherm5.conversionResolutionMode = kLPADC_ConversionResolutionHigh;
    adc_config_vtherm5.channelNumber = 3;

    adc_config_vtherm6.sampleChannelMode = kLPADC_SampleChannelSingleEndSideB;
    adc_config_vtherm6.conversionResolutionMode = kLPADC_ConversionResolutionHigh;
    adc_config_vtherm6.channelNumber = 3;

    adc_config_ures.sampleChannelMode = kLPADC_SampleChannelSingleEndSideA;
    adc_config_ures.conversionResolutionMode = kLPADC_ConversionResolutionHigh;
    adc_config_ures.channelNumber = 4;

    adc_config_ucomp.sampleChannelMode = kLPADC_SampleChannelSingleEndSideB;
    adc_config_ucomp.conversionResolutionMode = kLPADC_ConversionResolutionHigh;
    adc_config_ucomp.channelNumber = 4;

    // Get the default ADC conversion trigger configuration
    LPADC_GetDefaultConvTriggerConfig(&mLpadcTriggerConfigStruct);
    mLpadcTriggerConfigStruct.targetCommandId = LPADC_USER_CMDID;
    // Disable any hardware triggers of the ADC
    mLpadcTriggerConfigStruct.enableHardwareTrigger = false;
    // Apply the new conversion trigger configuration
    LPADC_SetConvTriggerConfig(ADC0, 0U, &mLpadcTriggerConfigStruct);

    // Enable the ADC interrupt
    LPADC_EnableInterrupts(ADC0, kLPADC_FIFO0WatermarkInterruptEnable);
    EnableIRQ(ADC0_IRQn);
}

app_return_code_t BOARD_ADC_Read(void) {
    // If we are in the middle of reading results. Return false
    if( !adc_conv_complete )
        return APP_RET_BUSY;

    // Reset the adc conv complete flag
    adc_conv_complete = false;

    // Configure our read for the first thermistor
    LPADC_SetConvCommandConfig(ADC0, LPADC_USER_CMDID, &adc_config_vtherm1);

    // Set our channel index to the first thermistor
    currentADCchannel = BOARD_ADC_CH_VTHERM1;

    // Start the reads
    LPADC_DoSoftwareTrigger(ADC0, LPADC_USER_CMDID);

    return APP_RET_OK;
}

app_return_code_t BOARD_ADC_SetConvCompleteCallback(board_adc_conv_complete_fptr_t cb) {
    if( cb == NULL ) {
        return APP_RET_NULL_PTR;
    }

    CB_conversionComplete = cb;

    return APP_RET_OK;
}