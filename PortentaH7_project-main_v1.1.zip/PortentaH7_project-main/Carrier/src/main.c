/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
main.c
*******************************************************************************/

#include "board.h"
#include "cooling.h"
#include "debug.h"
#include "fault.h"
#include "fsl_gpio.h"
#include "globals.h"
#include "heating.h"
#include "ipc.h"
#include "pin_mux.h"
#include "temperature.h"
#include "PCComs.h"
#include "version.h"
#include "board_pwm.h"
#include <stdio.h>
#include <string.h>

#define TIME_UDPATE_INTV (1000)
#define MAX_TRANSITION_TIME (20000)
#define TRANSITION_WAIT_TIME (8000)

uint32_t refTime = 0x00;
uint32_t transitionRefTime = 0x00;
float adapterTempAtTransition = 25.0;
uint32_t transitionStart = 0;

static void OutputsForHeat(void)
{
	g_outputStates.bits.RETURN_SOLENOID = RETURN_SOLENOID_HOT;
	g_outputStates.bits.OUTLET_SOLENOID = OUTLET_SOLENOID_HOT;
	g_outputStates.bits.HOT_PUMP = 1;
	g_outputStates.bits.COLD_PUMP = 1;
	g_outputStates.bits.COMPRESSOR = 1;
	g_outputStates.bits.HOT_BYPASS = 0;
	g_outputStates.bits.COLD_BYPASS = 1;
	turnOnCooling();
}

static void OutputsForCool(void)
{
	g_outputStates.bits.RETURN_SOLENOID = RETURN_SOLENOID_COLD;
	g_outputStates.bits.OUTLET_SOLENOID = OUTLET_SOLENOID_COLD;
	g_outputStates.bits.HOT_PUMP = 1;
	g_outputStates.bits.COLD_PUMP = 1;
	g_outputStates.bits.COMPRESSOR = 1;
	g_outputStates.bits.HOT_BYPASS = 1;
	g_outputStates.bits.COLD_BYPASS = 0;
	turnOnCooling();
}
static void OutputsForTransitionToCool(void)
{
	g_outputStates.bits.RETURN_SOLENOID = RETURN_SOLENOID_HOT;
	g_outputStates.bits.OUTLET_SOLENOID = OUTLET_SOLENOID_COLD;
	g_outputStates.bits.HOT_PUMP = 1;
	g_outputStates.bits.COLD_PUMP = 1;
	g_outputStates.bits.COMPRESSOR = 1;
	g_outputStates.bits.HOT_BYPASS = 1;
	g_outputStates.bits.COLD_BYPASS = 0;
	turnOnCooling();
}
static void OutputsForTransitionToHeat(void)
{
	g_outputStates.bits.RETURN_SOLENOID = RETURN_SOLENOID_COLD;
	g_outputStates.bits.OUTLET_SOLENOID = OUTLET_SOLENOID_HOT;
	g_outputStates.bits.HOT_PUMP = 1;
	g_outputStates.bits.COLD_PUMP = 1;
	g_outputStates.bits.COMPRESSOR = 1;
	g_outputStates.bits.HOT_BYPASS = 0;
	g_outputStates.bits.COLD_BYPASS = 1;
	turnOnCooling();
}
static void OutputsOff(void)
{
	g_outputStates.bits.RETURN_SOLENOID = RETURN_SOLENOID_HOT;
	g_outputStates.bits.OUTLET_SOLENOID = OUTLET_SOLENOID_HOT;
	g_outputStates.bits.HOT_PUMP = 0;
	g_outputStates.bits.COLD_PUMP = 0;
	g_outputStates.bits.COMPRESSOR = 0;
	g_outputStates.bits.HOT_BYPASS = 0;
	g_outputStates.bits.COLD_BYPASS = 1;
	turnOffCooling();
	g_heaterPWMLevel = 0.0;
}
static void OutputsFilling(void)
{
	g_outputStates.bits.RETURN_SOLENOID = RETURN_SOLENOID_COLD;
	g_outputStates.bits.OUTLET_SOLENOID = OUTLET_SOLENOID_HOT;
	g_outputStates.bits.HOT_PUMP = 1;
	g_outputStates.bits.COLD_PUMP = 0;
	g_outputStates.bits.COMPRESSOR = 0;
	g_outputStates.bits.HOT_BYPASS = 1;
	g_outputStates.bits.COLD_BYPASS = 1;
	turnOffCooling();
}

float oldHeaterPWM = 0.0;
int main(void)
{
	app_return_code_t ret = APP_RET_OK;

	// Init the board pins & clocks
	BOARD_Init();

#if 0
	// Display the project version, variant and compiled time/date
	debug_writeLine("\rThermaquil Quantum Controller %d.%d.%d.%s - COMPILED %s %s",
					VERSION_MAJOR,
					VERSION_MINOR,
					VERSION_PATCH,
					(VERSION_DEBUG == 1 ? "dbg" : "rel"),
					__TIME__,
					__DATE__);
#endif
	// Init our own modules
	ret = ipc_init();
	if (APP_RET_OK != ret)
	{
		debug_writeLine("IPC Init Error (%d)", (int8_t)ret);
	}

	ret = temperature_init();
	if (APP_RET_OK != ret)
	{
		debug_writeLine("Temperature Init Error (%d)", (int8_t)ret);
	}

	ret = cooling_init();
	if (APP_RET_OK != ret)
	{
		debug_writeLine("Cooling Init Error (%d)", (int8_t)ret);
		fault_setFault(FAULT_DAC);
	}

	ret = heating_init();
	if (APP_RET_OK != ret)
	{
		debug_writeLine("Heating Init Error (%d)", (int8_t)ret);
	}

	// Set our current FW version
	ipc_register_map.bitfields.REVISION.FW_VER_MAJOR = VERSION_MAJOR;
	ipc_register_map.bitfields.REVISION.FW_VER_MINOR = VERSION_MINOR;
	ipc_register_map.bitfields.REVISION.FW_VER_PATCH = VERSION_PATCH;

	// Set our device into the idle state at startup
	g_systemState = STATE_OFF;
	g_bFilling = false;

	OutputsOff();

	while (1)
	{
		PCComs();

		// Handle any incoming IPC commands
		// ipc_update();
		// Retrieve temperatures as fast as we can
		temperature_retrieve();

		if (!g_PCTestMode)
		{
			// Update the cooling
			cooling_update();
			// Update the heating
			heating_update();

			switch (g_systemState)
			{
			case STATE_OFF:
				// We are idle and waiting for a "Start" event. Make sure everything is turned off.
				if (g_remoteCommand == COMMAND_GO_PREPARE)
				{
					g_remoteCommand = 0;
					OutputsForHeat();
					g_systemState = STATE_PREPARING;
				}
				else if (g_bFilling)
				{
					OutputsFilling();
				}
				else
				{
					OutputsOff();
				}
				break;

			case STATE_PREPARING:
				// Stay here till the control UI tells us to start heating or cooling
				switch (g_remoteCommand)
				{
				default:
					g_remoteCommand = 0;
					break;

				case COMMAND_GO_HEAT:
					g_remoteCommand = 0;
					OutputsForHeat();
					g_systemState = STATE_TRANSITION_TO_HEAT;
					break;

				case COMMAND_GO_COOL:
					g_remoteCommand = 0;
					OutputsForTransitionToCool();
					transitionRefTime = BOARD_GetTick();
					g_systemState = STATE_TRANSITION_TO_COOL;
					break;

				case COMMAND_GO_OFF:
					g_remoteCommand = 0;
					OutputsOff();	
					g_systemState = STATE_OFF;
					break;
				}
				break;

			case STATE_TRANSITION_TO_COOL:
				// delay here a bit then switch the return solenoid to on
				if (BOARD_GetTick() > (transitionRefTime + TRANSITION_WAIT_TIME))
				{
					OutputsForCool();
					g_systemState = STATE_COOL;
				}
				break;

			case STATE_TRANSITION_TO_HEAT:
				// delay here a bit then switch the return solenoid to off
				if (BOARD_GetTick() > (transitionRefTime + TRANSITION_WAIT_TIME))
				{
					OutputsForHeat();
					g_systemState = STATE_HEAT;
				}
				break;

			case STATE_HEAT:
				switch (g_remoteCommand)
				{
				default:
					g_remoteCommand = 0;
					break;

				case COMMAND_GO_COOL:
					g_remoteCommand = 0;
					OutputsForTransitionToCool();
					transitionRefTime = BOARD_GetTick();
					g_systemState = STATE_TRANSITION_TO_COOL;
					break;

				case COMMAND_GO_OFF:
					g_remoteCommand = 0;
					OutputsOff();
					g_systemState = STATE_OFF;
					break;
				}
				break;

			case STATE_COOL:
				switch (g_remoteCommand)
				{
				default:
					g_remoteCommand = 0;
					break;

				case COMMAND_GO_HEAT:
					g_remoteCommand = 0;
					OutputsForTransitionToHeat();
					transitionRefTime = BOARD_GetTick();
					g_systemState = STATE_TRANSITION_TO_HEAT;
					break;

				case COMMAND_GO_OFF:
					g_remoteCommand = 0;
					OutputsOff();
					g_systemState = STATE_OFF;
					break;
				}
				break;

			case STATE_FAULT:
				// We are in a fault state. Turn off everything.
				OutputsOff();
				g_outputStates.byte = 0x00;
				break;

			default:
				break;
			}
		}

		// Check for any device faults
		if (fault_checkForFaults() != APP_RET_OK)
		{
			// Set our device into a fault state.
			g_systemState = STATE_FAULT;
		}


		if (g_PCTestMode == 0)
		{
			// Set the IO states to their needed states
			GPIO_PinWrite(GPIO, BOARD_nSHDN_SOL1_GPIO_PORT, BOARD_nSHDN_SOL1_GPIO_PIN, g_outputStates.bits.RETURN_SOLENOID);
			GPIO_PinWrite(GPIO, BOARD_nSHDN_SOL2_GPIO_PORT, BOARD_nSHDN_SOL2_GPIO_PIN, g_outputStates.bits.OUTLET_SOLENOID);
			GPIO_PinWrite(GPIO, BOARD_SPARE1_EN_GPIO_PORT, BOARD_SPARE1_EN_GPIO_PIN, g_outputStates.bits.COLD_BYPASS);
			GPIO_PinWrite(GPIO, BOARD_SPARE2_EN_GPIO_PORT, BOARD_SPARE2_EN_GPIO_PIN, g_outputStates.bits.HOT_BYPASS);
			GPIO_PinWrite(GPIO, BOARD_PUMP1_EN_GPIO_PORT, BOARD_PUMP1_EN_GPIO_PIN, g_outputStates.bits.HOT_PUMP);
			GPIO_PinWrite(GPIO, BOARD_PUMP2_EN_GPIO_PORT, BOARD_PUMP2_EN_GPIO_PIN, g_outputStates.bits.COLD_PUMP);
			GPIO_PinWrite(GPIO, BOARD_COMP_EN_GPIO_PORT, BOARD_COMP_EN_GPIO_PIN, !g_outputStates.bits.COMPRESSOR);
			
			// only let the heater go on if the pump is running
			if (g_outputStates.bits.HOT_PUMP)
			{
				if (oldHeaterPWM < g_heaterPWMLevel)
				{
					oldHeaterPWM += 5.0;
					if (oldHeaterPWM >= g_heaterPWMLevel)
					{
						oldHeaterPWM = g_heaterPWMLevel;
					}
					BOARD_PWM_SetDutyCycle(100 - oldHeaterPWM);
				}
				else
				{
					oldHeaterPWM = g_heaterPWMLevel;
					BOARD_PWM_SetDutyCycle(100 - g_heaterPWMLevel);
				}
			}
			else
			{
				oldHeaterPWM = 0.0;
				BOARD_PWM_SetDutyCycle(100);
			}
		}
	}
}