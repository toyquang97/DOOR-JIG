#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include "temperature.h"
#include "error.h"
#include "board_adc.h"
#include "ipc.h"
#include "globals.h"
#include "FIRFilter.h"
#include "FIRTaps.h"

#define NUM_THERMISTORS 8

#define ADC_MAX_INT_VAL (65535)
#define ADC_VREF        (3.2892)
#define ADC_LSB_VALUE   (ADC_VREF / ADC_MAX_INT_VAL)

// Thermistor equation values - For old thermistors
#define A_val   (0.0008972439213)
#define B_val   (0.0002500990711)
#define C_val   (0.0000001961752076)
#define VREF    (3.3)
#define RBOTTOM (10000)

// Thermisotr equation values - For new thermistors
#define A_VAL_RESV   (0.001279011543)
#define B_VAL_RESV   (0.0002371723255)
#define C_VAL_RESV   (0.00000008895615508)
#define RBOTTOM_RESV (5000)

static bool tempsReady = false;

tFIRFilterStruct filtInletTemp;
tFIRFilterStruct filtOutletTemp;
tFIRFilterStruct filtHotResv;
tFIRFilterStruct filtColdResv;

static float CtoF(float degC)
{
	return (degC * 9.0 / 5.0) + 32.0;
}

static void _convertTemps(void) 
{
	float voltage = 0.0;
	float temperature = 0.0;

	for (uint8_t i = 0; i < NUM_THERMISTORS; i++) 
	{
		// If we are converting for the new thermistors use the new equation values
		if ((i == COLD_RESV_THERMISTOR_INDEX) || (i == HOT_RESV_THERMISTOR_INDEX)) 
		{
			voltage = (ADC_LSB_VALUE * board_adc_conv_results[i]);
			// Compute the actual temp value
			temperature = CtoF((1 / (A_VAL_RESV +
								(B_VAL_RESV * log(((VREF - voltage) * RBOTTOM_RESV) / (voltage))) +
								(C_VAL_RESV *
								 pow(log(((VREF - voltage) * RBOTTOM_RESV) / (voltage)), 3)))) -
						  273.15);
		}
		else 
		{
			// Old thermistor equation calculations
			voltage = (ADC_LSB_VALUE * board_adc_conv_results[i]);
			// Compute the actual temp value
			temperature = CtoF((1 / (A_val +
			    (B_val * log(((VREF - voltage) * RBOTTOM) / (voltage))) +
			    (C_val *
			    pow(log(((VREF - voltage) * RBOTTOM) / (voltage)), 3)))) - 273.15);
		}

		if (temperature < 0.0)
		{
			//temperature = 1.0;
		}
		switch (i)
		{
		case COLD_RESV_THERMISTOR_INDEX:
			FIR_PutSample(temperature, &filtColdResv);
			g_coldResevoirTemperature = FIR_GetOutput(&filtColdResv);
			break;
			
		case HOT_RESV_THERMISTOR_INDEX:
			FIR_PutSample(temperature, &filtHotResv);
			g_hotResevoirTemperature = FIR_GetOutput(&filtHotResv);
			break;
			
		case INLET_THERMISTOR_INDEX:
			FIR_PutSample(temperature, &filtInletTemp);
			g_inletTemperature = FIR_GetOutput(&filtInletTemp);
			break;
			
		case OUTLET_THERMISTOR_INDEX:
			FIR_PutSample(temperature, &filtOutletTemp);
			g_outletTemperature = FIR_GetOutput(&filtOutletTemp);
			break;
			
		}
		// Set the temperatures in our array
		ipc_register_map.bitfields.TEMPERATURES.array[i] = temperature;
	}
}

static app_return_code_t adc_cb(void) 
{
	tempsReady = true;
	return APP_RET_OK;
}

app_return_code_t temperature_init(void) 
{

	BOARD_ADC_Read();

	FIR_Initialize(&filtColdResv, tenAvgTaps, 10);
	FIR_Initialize(&filtHotResv, tenAvgTaps, 10);
	FIR_Initialize(&filtInletTemp, tenAvgTaps, 10);
	FIR_Initialize(&filtOutletTemp, tenAvgTaps, 10);

	// Add our callback which should be fired when we finish polling all of the ADC inputs
	return BOARD_ADC_SetConvCompleteCallback(adc_cb);
}

app_return_code_t temperature_retrieve(void) 
{

	if (tempsReady) {
		tempsReady = false;
		_convertTemps();
	}

	return BOARD_ADC_Read();
}

float getPadTemperatue(void)
{
	return (g_inletTemperature + g_outletTemperature) / 2.0;
}