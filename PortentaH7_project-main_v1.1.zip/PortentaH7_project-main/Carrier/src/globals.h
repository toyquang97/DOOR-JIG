#pragma once

#include <stdint.h>
#include <stdbool.h>

typedef union
{
	struct
	{
		uint8_t HOT_PUMP : 1;
		uint8_t COLD_PUMP : 1;
		uint8_t RETURN_SOLENOID : 1;
		uint8_t OUTLET_SOLENOID : 1;
		uint8_t COLD_BYPASS : 1;
		uint8_t HOT_BYPASS : 1;
		uint8_t COMPRESSOR : 1;
	} bits;
	uint8_t byte;
} output_states_t;

#define RETURN_SOLENOID_HOT (1)
#define RETURN_SOLENOID_COLD (0)
#define OUTLET_SOLENOID_HOT (1)
#define OUTLET_SOLENOID_COLD (0)

typedef enum
{
	STATE_OFF = 0x00,
	STATE_PREPARING,
	STATE_HEAT,
	STATE_TRANSITION_TO_COOL,
	STATE_COOL,
	STATE_TRANSITION_TO_HEAT,
	STATE_FAULT,
	STATE__MAX__,
} system_state_t;

typedef enum
{
	COMMAND_GO_OFF = 1,
	COMMAND_GO_PREPARE,
	COMMAND_GO_HEAT,
	COMMAND_GO_COOL
} remote_command_t;

extern output_states_t g_outputStates;
extern system_state_t g_systemState;
extern uint8_t g_PCTestMode;
extern remote_command_t g_remoteCommand;
extern float g_hotSetpoint;
extern float g_coldSetpoint;
extern float g_inletTemperature;
extern float g_outletTemperature;
extern float g_coldResevoirTemperature;
extern float g_hotResevoirTemperature;
extern bool g_bFilling;
extern float g_heaterPWMLevel;
