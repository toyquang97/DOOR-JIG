/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
debug.c
*******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "fsl_debug_console.h"
#include "debug.h"
#include "error.h"

app_return_code_t debug_writeLine(const char* frmt, ...) {
#ifdef DEBUG_BUILD
    char buf[255] = {0};
    va_list args;

    va_start(args, frmt);
    vsnprintf(buf,255,frmt,args);
    va_end(args);

    // Printf returns number of bytes written
    // Check that it wrote successfully
    if( DbgConsole_Printf("%s\r", buf) <= 0 ) {
        return APP_RET_ERROR;
    }
#endif

    return APP_RET_OK;
}

app_return_code_t debug_writeArray(const uint8_t* arr, const uint16_t len) {
#ifdef DEBUG_BUILD
    int result = 0;

    if( arr == NULL ) {
        return APP_RET_NULL_PTR;
    }
    else if( len <= 0 ) {
        return APP_RET_INV_PARAM;
    }

    for(uint16_t i = 0; i < len; i++ ) {
        // Print the byte at index i
        result = DbgConsole_Printf("%02X ", arr[i]);
        // Check that it wrote fine
        if( result <= 0 ) {
            // Failed to write the byre.
            // Return an error
            return APP_RET_ERROR;
        }
    }

    // Printf returns number of bytes written
    // Check that it wrote successfully
    if( DbgConsole_Printf("\n\r") <= 0 ) {
        return APP_RET_ERROR;
    }
#endif

    return APP_RET_OK;
}