/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
heating.h
*******************************************************************************/

#ifndef _HEATING_H_
#define _HEATING_H_

#include <stdint.h>
#include "error.h"

app_return_code_t heating_init(void);
app_return_code_t heating_setSetpoint(int8_t setpoint);
app_return_code_t heating_update(void);

#endif // _HEATING_H_