/******************************************************************************
Thermaquil Quantum Controller Carrier Firmware
Copyright (c) 2021 Glassboard
cooling.c
*******************************************************************************/
#include "cooling.h"
#include "ad5697r.h"
#include "board.h"
#include "board_i2c.h"
#include "debug.h"
#include "error.h"
#include "fsl_gpio.h"
#include "ipc.h"
#include "pin_mux.h"
#include "temperature.h"
#include "globals.h"
#include <math.h>
#include <stdint.h>

#define COOLING_TICK_RATE (500)
#define MIN_COOLING_TEMP (-8.0)
#define MAX_COOLING_TEMP (20.0)
#define MIN_COMPRESSOR_ON_TIME (15000)
#define MIN_COMPRESSOR_OFF_TIME (15000)
#define COOLING_OVERSHOOT_AMNT (0)
#define COOLING_SETPOINT_ADJUST (2)

// Create an instance of our AD56x device
ad5697r_dev_t ad5697_device;
uint32_t cooling_refTime = 0x00;
uint32_t comp_off_refTime = 0x00;
uint32_t comp_on_refTime = 0x00;

static int8_t usr_i2c_write(const uint8_t busAddr, const uint8_t *data, const uint32_t len)
{
	ad5697r_return_code_t ret = AD5697R_RET_OK;

	// Transmit the data to the specified device from the provided
	// data buffer.
	ret = BOARD_I2C_Write(BOARD_I2C_DEV_DAC, busAddr, data, len);

	return ret;
}

static int8_t usr_i2c_read(const uint8_t busAddr, uint8_t *data, const uint32_t len)
{
	ad5697r_return_code_t ret = AD5697R_RET_OK;

	// Received the specified amount of data from the device and store it
	// in the data buffer
	ret = BOARD_I2C_Read(BOARD_I2C_DEV_DAC, busAddr, data, len);

	return ret;
}

static void usr_delay_us(uint32_t period)
{
	// Delay for the requested period
}

app_return_code_t cooling_init(void)
{
	ad5697r_return_code_t ret = AD5697R_RET_OK;

	// Provide the hardware abstraction functions for
	// I2c Read/Write and a micro-second delay function
	ad5697_device.intf.i2c_addr = 0x0F;
	ad5697_device.intf.write = usr_i2c_write;
	ad5697_device.intf.read = usr_i2c_read;
	ad5697_device.intf.delay_us = usr_delay_us;

	// Pull the AD5697 out of reset
	GPIO_PinWrite(GPIO, BOARD_DAC_nRST_GPIO_PORT, BOARD_DAC_nRST_GPIO_PIN, 1);

	// Turn off the AD56x internal reference
	ret = ad5697r_setReferenceMode(&ad5697_device, AD5697R_REF_OFF);

	// Set the desired operation mode for our DAC outputs
	// Enable channel A to run in normal operation
	if (ret == AD5697R_RET_OK)
		ret = ad5697r_setOperatingMode(&ad5697_device, AD5697R_OUTPUT_CH_A, AD5697R_OP_MODE_NORMAL);

	// Disable channel B and put a 1K resistance to ground on the output
	if (ret == AD5697R_RET_OK)
		ret = ad5697r_setOperatingMode(&ad5697_device, AD5697R_OUTPUT_CH_B, AD5697R_OP_MODE_1K_TO_GND);

	// Set the DAC output value to 50% of the reference voltage
	if (ret == AD5697R_RET_OK)
		ret = ad5697r_writeChannel(&ad5697_device, AD5697R_OUTPUT_CH_A, 0x00);

	return ret;
}

app_return_code_t cooling_update(void)
{
	app_return_code_t ret = APP_RET_OK;
	float currentTemperature = 0.0;

	if ((g_systemState == STATE_FAULT) ||
		(g_systemState == STATE_OFF))
	{
		return cooling_disable();
	}

	// At any point if the pump turns off.. And the compressor is on. We need to turn it off to prevent freezing
	if (!g_outputStates.bits.COLD_PUMP && g_outputStates.bits.COMPRESSOR)
	{
		// Turn off the compressor and update our time
		ret = ad5697r_writeChannel(&ad5697_device, AD5697R_OUTPUT_CH_A, 0);
		// Store our flag saying the compressor is off
		g_outputStates.bits.COMPRESSOR = 0;
		// Update the time that we turned off the compressor
		comp_off_refTime = BOARD_GetTick();

		return ret;
	}

	// Only tick the cooling checks every 500ms
	if (BOARD_GetTick() > (cooling_refTime + COOLING_TICK_RATE))
	{
		// Update the cooling refTime
		cooling_refTime = BOARD_GetTick();

		if ((g_systemState == STATE_COOL) || (g_systemState == STATE_TRANSITION_TO_COOL))
		{
			currentTemperature = getPadTemperatue();
		}
		else
		{
			// pretend the resevoir temp is a little higher so it cools more 
			// for when the heating cycle is going to make sure the cold resevoir is lower than the setpoint
			if ((g_systemState != STATE_PREPARING))
			{
				currentTemperature = g_coldResevoirTemperature + COOLING_SETPOINT_ADJUST;
			}
			else
			{
				currentTemperature = g_coldResevoirTemperature;
			}
		}

		// Check our reservoir temp against the setpoint
		if ((!g_outputStates.bits.COMPRESSOR) && (currentTemperature > g_coldSetpoint))
		{
			// Reservoir is not cool enough. Turn on the compressor if we can.
			// First make sure we are within our cycle time
			// OR if the off ref time is zero (meaning it's our first time turning the compressor on.)
			if ((comp_off_refTime == 0x00) || (BOARD_GetTick() > (comp_off_refTime + MIN_COMPRESSOR_OFF_TIME)))
			{
				// We have met our timing restrictions. Now make sure the pump is on.
				if (g_outputStates.bits.COLD_PUMP)
				{
					// Pump is on. We are clear to turn on the compressor at 1V
					ret = ad5697r_writeChannel(&ad5697_device, AD5697R_OUTPUT_CH_A, 2662);
					// Store our flag saying the compressor is on.
					g_outputStates.bits.COMPRESSOR = 1;
					// Update the time that we turned on the compressor
					comp_on_refTime = BOARD_GetTick();
				}
				else
				{
					// Pump was not on.. We shouldn't turn the compressor on.. Just return, and don't update any ref times.
					ret = APP_RET_ERROR;
				}
			}
		}
		else if ((g_outputStates.bits.COMPRESSOR) && (currentTemperature < (g_coldSetpoint - COOLING_OVERSHOOT_AMNT)))
		{
			// We've met our exceeded the cooling reservoir setpoint.. We should turn off the compressor if we can.
			// First make sure we are within our cycle time
			if ((BOARD_GetTick() > (comp_on_refTime + MIN_COMPRESSOR_ON_TIME)))
			{
				// We have met our timing restrictions. Disable cooling
				ret = cooling_disable();
			}
		}
	}

	return ret;
}

app_return_code_t cooling_disable(void)
{
	app_return_code_t ret = APP_RET_OK;

	// Turn off the compressor and update our time
	ret = ad5697r_writeChannel(&ad5697_device, AD5697R_OUTPUT_CH_A, 0);
	// Store our flag saying the compressor is off
	g_outputStates.bits.COMPRESSOR = 0;
	// Update the time that we turned off the compressor
	comp_off_refTime = BOARD_GetTick();

	return ret;
}

void setDACoutput(uint16_t value)
{
	// Turn off the compressor and update our time
	(void)ad5697r_writeChannel(&ad5697_device, AD5697R_OUTPUT_CH_A, value);
}

void turnOnCooling(void)
{
	ad5697r_writeChannel(&ad5697_device, AD5697R_OUTPUT_CH_A, 2662);
	GPIO_PinWrite(GPIO, BOARD_COMP_EN_GPIO_PORT, BOARD_COMP_EN_GPIO_PIN, 0);
}

void turnOffCooling(void)
{
	ad5697r_writeChannel(&ad5697_device, AD5697R_OUTPUT_CH_A, 0);
	GPIO_PinWrite(GPIO, BOARD_COMP_EN_GPIO_PORT, BOARD_COMP_EN_GPIO_PIN, 1);
}