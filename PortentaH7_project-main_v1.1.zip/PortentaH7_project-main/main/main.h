#include <Arduino_MachineControl.h>
#include <Adafruit_NeoPixel.h>
#include "Portenta_H7_TimerInterrupt.h"
#include <ArduinoBLE.h>
#include <string>
#include <SPI.h>
#include <SD.h>
#include "Wire.h"
#include <stdarg.h>
#include <stdio.h>

#define OFF false
#define ON  true
#define ACTIVE  true


#define DEBUG ON //OFF //<------------------------------------
#define LOG_D1_LV	  ON
#define LOG_D2_LV	  ON
#define LOG_D3_LV	  ON
#define LOG_E_LV	  ON


#define MAX_PRINT_BUFF  1000

#define PRINT_LOGD1(data...) \
{\
	if(DEBUG && LOG_D1_LV)   \
	print(data);\
}

#define PRINT_LOGD2(data...) \
{\
	if(DEBUG && LOG_D2_LV)   \
	print(data);\
}

#define PRINT_LOGD3(data...) \
{\
	if(DEBUG && LOG_D3_LV)   \
	print(data);\
}

#define PRINT_LOGE(data...) \
{\
	if(DEBUG && LOG_E_LV)   \
	print(data);\
}


//---------------------------------------------------------------------
//Button
//---------------------------------------------------------------------
#define BUTTON_INTERRUPT_PIN      PB_4 //TCA6424A's Interrupt pin
#define BUTTON_START_PAUSE_PIN          DIN_READ_CH_PIN_00
#define BUTTON_STOP_PIN                 DIN_READ_CH_PIN_01
#define BUTTON_2_PIN              DIN_READ_CH_PIN_02
#define BUTTON_3_PIN              DIN_READ_CH_PIN_03

#define IS_BUTTON_PRESS  1 //pin logic when button is pressed
//------------------------------------------------------
// Switch Sensors
//------------------------------------------------------
#define FLOW_SWITCH_PIN               DIN_READ_CH_PIN_04
#define HOT_LIQUID_LEVEL_PIN          DIN_READ_CH_PIN_05
#define COLD_LIQUID_LEVEL_PIN         DIN_READ_CH_PIN_06

//pin logic when sensor active
#define FLOW_SWITCH_STATE_ACTIVE        1 //high
#define HOT_LIQUID_LEVEL_STATE_ACTIVE   0 //low
#define COLD_LIQUID_LEVEL_STATE_ACTIVE  0 //low

//------------------------------------------------------
// Output define 
//------------------------------------------------------
#define RELAY_PIN     0 //CH0

//------------------------------------------------------
// RGB LED define
//------------------------------------------------------
#define NUMPIXELS   1
#define LED_PIN     D5 //fixed config in \libraries\Adafruit_NeoPixelportenta.c

typedef enum
{
    LED_STATE_OFF,
    LED_STATE_RED,
    LED_STATE_GREEN,
    LED_STATE_BLUE,
    LED_STATE_MAX,
}LED_STATE;

//------------------------------------------------------
// Temperature sensor define
//------------------------------------------------------
#define NTC_SENSOR   0
#define PT100_SENSOR 1

#define TEMPURATURE_SENSOR  NTC_SENSOR

// NTC Thermistor coefficient define
#if (NTC_SENSOR == TEMPURATURE_SENSOR)
  #define NTC_ANALOG_CHANEL   0
  #define NTC_VREF            3 // V
  #define NTC_R1_VALUE        100000 //R1 OHM
  #define NTC_NOMINAL_RES     5000 //R2 OHM
  #define NTC_NOMINAL_TEMP    25
  #define NTC_BETA            3980 //K
  #define ADC_VALUE_MAX       65535
#endif
//------------------------------------------------------
// RTC define
//------------------------------------------------------
typedef struct
{
    uint8_t years;
    uint8_t months;
    uint8_t days;
    uint8_t hours;
    uint8_t minutes;
    uint8_t seconds;
}st_rtcRealTime;

//------------------------------------------------------
// SD CARD
//------------------------------------------------------
/*
   - CS: SDCard_CS_PIN (D6)
   - MOSI: D8
   - MISO: D9
   - CK  : D10
*/
#define SDCard_CS_PIN   D6 //shared pin with Analog in CH2 mode
#define LENGTH_OF_FIND_INDEX    5  // len("65535")
#define LENGTH_OF_FIND_DATA     30

//---------------------------------------------------------------------
//BLE defination https://www.uuidgenerator.net/version4
//---------------------------------------------------------------------
#define BLE_LOCAL_NAME                    "Adruino PMC" 
#define BLE_PMC_SERVICE_UUID              "25b28cef-a1a7-4eca-b3bf-8b91e3925bd8"

#define BLE_APP_COMMANDS_UUID             "c1f481dc-1ec6-4477-9e8b-b61cba95fed2" //app sends command to pmc: ask the pmc to do something
#define BLE_PMC_COMMANDS_UUID             "126a52ab-c007-488a-bdf0-10d2e805dc77" //pmc sends command to app: ask the app to do something
#define BLE_SYSTEM_ERROR_UUID             "96ae3a99-2fbc-4090-b522-1098bfceb051"

#define BLE_FILE_TRANSFER_BLOCK_UUID      "f84b529a-8f13-4b84-8420-9e0436c7ac56"
#define BLE_FILE_TRANSFER_STATUS_UUID     "b57e5d26-6251-4c1e-b565-3b565da1f29b"

#define BLE_REAL_TIME_DATA_UUID           "D76F7FD4-8501-4142-AB81-D464ED0B2435"


#define BLE_FILE_TRANSFER_BLOCK_SIZE      512


#define BLE_CLR_ALL_EVENT_KEY   0xCAFE
#define BLE_CONFIRM_APP_CMD     0b10000000


#define PMC_REVISION_MAJOR      0x01
#define PMC_REVISION_MINOR      0x01

#define EX_REVISION_MAJOR      0x00
#define EX_REVISION_MINOR      0x00
#define EX_REVISION_PATCH      0x00

typedef enum
{
  BLE_EVENT_TIMER = 0x01,
  BLE_EVENT_READY_TO_RUN,
  BLE_EVENT_TREATMENT_START,
  BLE_EVENT_TREATMENT_PAUSE,
  BLE_EVENT_TREATMENT_REMUSE,
  BLE_EVENT_TREATMENT_END,
  BLE_EVENT_CURRENT_CYCLE_SETPOINT_CHANGED,
  BLE_EVENT_CURRENT_CYCLE_TIME_CHANGED,
  BLE_EVENT_SWITCH_TO_COLD_CYCLE,
  BLE_EVENT_SWITCH_TO_HOT_CYCLE,
  BLE_EVENT_REACHES_0,
  BLE_EVENT_PAUSE_TIMEOUT,
  BLE_EVENT_ID_MAX
}BLE_EVENT_ID_TYPEDEF;

char *bleEventstr[BLE_EVENT_ID_MAX] = 
{
  "BLE_EVENT_UNSE",
  "BLE_EVENT_TIMER",
  "BLE_EVENT_READY_TO_RUN",
  "BLE_EVENT_TREATMENT_START",
  "BLE_EVENT_TREATMENT_PAUSE",
  "BLE_EVENT_TREATMENT_REMUSE",
  "BLE_EVENT_TREATMENT_END",
  "BLE_EVENT_CURRENT_CYCLE_SETPOINT_CHANGED",
  "BLE_EVENT_CURRENT_CYCLE_TIME_CHANGED",
  "BLE_EVENT_SWITCH_TO_COLD_CYCLE",
  "BLE_EVENT_SWITCH_TO_HOT_CYCLE",
  "BLE_EVENT_REACHES_0",
  "BLE_EVENT_PAUSE_TIMEOUT",
};

typedef enum
{
  PMC_CMD_REVISION_INFOR = 0x01,
  PMC_CMD_NEXT_HOT_CYCLE_TIME,
  PMC_CMD_NEXT_COLD_CYCLE_TIME,
  PMC_CMD_NEXT_HOT_CYCLE_SETPOINT,
  PMC_CMD_NEXT_COLD_CYCLE_SETPOINT,
  PMC_CMD_FILLING_STATUS,
  PMC_CMD_MAX,
}PMC_COMMAND_TYPEDEF;

typedef enum
{
  SYS_ERR_TIMEOUT = 0x01,
  SYS_ERR_MAX,
}SYSTEM_ERROR_TYPEDEF; //mtodo:

typedef enum
{
  APP_CMD_SET_FULL_CYCLE = 0x01,
  APP_CMD_START_PREPARE,
  APP_CMD_SET_TREATMENT_STATUS,
  APP_CMD_CHANGE_CURRENT_CYCLE_SETPOINT,
  APP_CMD_CHANGE_CURRENT_CYCLE_TIME,
  APP_CMD_SET_EB_POWER,
  APP_CMD_CLEAR_ALL_EVENTS,
  APP_CMD_SWITCH_CYCLE,
  APP_CMD_GET_LOG_FILE,
  APP_CMD_CANCEL_GET_LOG_FILE,
  APP_CMD_SET_REAL_TIME,
  APP_CMD_RESERVOIR_FILLING,
  APP_CMD_MAX,
}APP_COMMAND_TYPEDEF;

char *appCMDStr[APP_CMD_MAX] = 
{
  "APP_CMD_UNSE",
  "APP_CMD_SET_FULL_CYCLE",
  "APP_CMD_START_PREPARE",
  "APP_CMD_SET_TREATMENT_STATUS",
  "APP_CMD_CHANGE_CURRENT_CYCLE_SETPOINT",
  "APP_CMD_CHANGE_CURRENT_CYCLE_TIME",
  "APP_CMD_SET_EB_POWER",
  "APP_CMD_CLEAR_ALL_EVENTS",
  "APP_CMD_SWITCH_CYCLE",
  "APP_CMD_GET_LOG_FILE",
  "APP_CMD_CANCEL_GET_LOG_FILE",
  "APP_CMD_SET_REAL_TIME",
  "APP_CMD_RESERVOIR_FILLING",
};

typedef enum
{
  TREATMENT_STT_BEGIN = 0x01,
  TREATMENT_STT_PAUSE,
  TREATMENT_STT_RESUME,
  TREATMENT_STT_END,
  TREATMENT_STT_MAX,
}TREATMENT_STATUS_TYPEDEF;

typedef enum
{
  PMC_TRANSFER_NEW_BLOCK = 0x01,
  PMC_TRANSFER_DONE,
  APP_REQUEST_TRANSFER,
  APP_RECEIVED_OK,
  APP_RECEIVED_ERR,
}FILE_TRANSFER_STATUS_TYPEDEF;

typedef enum
{
  SYS_STATE_OFF,
  SYS_STATE_PREPARING,
  SYS_STATE_READY,
  SYS_STATE_HEATING,
  SYS_STATE_COOLING,
  SYS_STATE_PAUSING,
  SYS_STATE_FILLING,
  SYS_STATE_MAX,
}SYSTEM_STATE_TYPEDEF;

char *sysStateStr[SYS_STATE_MAX] = 
{
  "SYS_STATE_OFF",
  "SYS_STATE_PREPARING",
  "SYS_STATE_READY",
  "SYS_STATE_HEATING",
  "SYS_STATE_COOLING",
  "SYS_STATE_PAUSING",
  "SYS_STATE_FILLING",
};

typedef struct
{
  byte code;
  byte data[17];
}st_APPCommands;

typedef struct
{
  byte code;
  byte data[5];
}st_PMCCommands;

typedef struct
{
  byte code;
  byte data[10];
}st_ErrorData; //mtodo:

typedef struct
{
//Portenta Machine Control Revision
    byte PMC_major;
    byte PMC_minor;
//Existing Board Revision
    byte EX_major;
    byte EX_minor;
    byte EX_patch;
}st_SWRevision;

typedef struct
{
  uint32_t index;
  uint32_t timestamp;
  BLE_EVENT_ID_TYPEDEF eventType;
  uint32_t cycleTimeRemaining;
  SYSTEM_STATE_TYPEDEF currentSysState;
  float inletTemp;
  float outletTemp;
  float padTemp;
  float hotResvTemp;
  float coldResvTemp;
  float heaterTemp;
  float hotSetPoint;
  float coldSetPoint;
}st_EventData;

typedef struct
{
  char *pProcessFileName;
  uint32_t processPosition;
  byte blockData[BLE_FILE_TRANSFER_BLOCK_SIZE + 1]; // + 1 for debug with the last byte is '\0'
  uint16_t blockLength;
}st_LogFileTransfer;

//---------------------------------------------------------------------
//System
//---------------------------------------------------------------------

typedef struct
{
  bool btnStartPausePressed;
  bool btnStopPressed;
  bool btn2Pressed;
  bool btn3Pressed;

  bool flowSwitch;
  bool hotLiquidLevel;
  bool coldLiquidLevel;

  bool relayState;
  bool serialConnected;
  bool getEBFWVersion;
  
  bool bleCentralConnected;
  bool bleCentralJustConnect;
  bool bleCentralJustDisconnect;
  bool bleLogFileTransfer;

  bool rs232NewMessage;

  bool timerCollectTemperature;
  bool timerSendSaveEventData;
  bool timer1000ms;

  bool treatmentAutoBegin;
}st_flags;

typedef struct
{
  uint8_t order;
  float hotSetPoint;
  uint32_t hotTime;
  float coldSetPoint;
  uint32_t coldTime;
}st_CycleConfig;

typedef struct
{
  uint8_t numOfCycles;//"cycleS" as pairs of hot cycle + cold cycle.
  SYSTEM_STATE_TYPEDEF preSysState;
  SYSTEM_STATE_TYPEDEF sysState;
  uint32_t acctualCycleRunTime;
  st_CycleConfig cycleConfig;
}st_SystemOperation; 

//---------------------------------------------------------------------
//Board control
//---------------------------------------------------------------------
/*
   - TX : TXN485
   - RX : RXP485
*/

#define RS232_RX_BUFFER_LENGTH    50

typedef enum
{
  TEMP_SENSOR_HOT_RESERVOIR  = 0x01,
  TEMP_SENSOR_COLD_RESERVOIR,
  TEMP_SENSOR_OUTLET,
  TEMP_SENSOR_INLET,
  TEMP_SENSOR_PAD,
  TEMP_SENSOR_ID_MAX,
}TEMP_SENSOR_ID_TYPEDEF;

char *tempSensorStr[TEMP_SENSOR_ID_MAX] = 
{
  "TEMP_SENSOR_UNSE",
  "TEMP_SENSOR_HOT_RESERVOIR",
  "TEMP_SENSOR_COLD_RESERVOIR",
  "TEMP_SENSOR_OUTLET",
  "TEMP_SENSOR_INLET",
  "TEMP_SENSOR_PAD",
};

typedef enum
{
  MODE_GO_OFF = 0x01,
  MODE_GO_PREPARE,
  MODE_GO_HEAT,
  MODE_GO_COOL,
}MODE_ID_TYPEDEF;

typedef enum
{
  HOT_SETPOINT = 0x01,
  COLD_SETPOINT,
}SETPOINT_ID_TYPEDEF;

typedef enum
{
  HOT_PUMP = 0x01,
  COLD_PUMP,
}PUMP_ID_TYPEDEF;


//---------------------------------------------------------------------
//Moc Lib
//---------------------------------------------------------------------
//Timer
#define MOC_TIME_1000_MS               1000 //ms
#define MOC_TIME_500_MS                500 //ms

#define MOC_TIME_BUTTON_HANDLER        200 //ms
#define MOC_TIME_COLLECT_TEMP          MOC_TIME_500_MS //ms
#define MOC_TIME_BLE_EVENT_TIMER       MOC_TIME_1000_MS

typedef enum
{
  MOC_TIMER_BUTTON_START_PAUSE_HANDLER,
  MOC_TIMER_BUTTON_STOP_HANDLER,
  MOC_TIMER_BUTTON_2_HANDLER,
  MOC_TIMER_COLLECT_TEMP,
  MOC_TIMER_BLE_EVENT_TIMER,
  MOC_TIMER_BLE_SEND_EVENT_TO_APP,
  MOC_TIMER_CYCLE_1000_MS,
  MOC_TIMER_CHECK_EB_COMMAND,
  MOC_TIMER_SEND_FILLING_STT,
  MOC_TIMER_ID_NUM
}MOC_TIMER_ID_TYPEDEF;

extern unsigned int volatile mocTimerTick_1ms;

//FIFO
extern unsigned char mocFIFO_bleEvtQty;

#define MOC_BLE_EVENT_FIFO_DEPTH     10
#define IsFIFOBleEvtAvailable        ((mocFIFO_bleEvtQty > 0) ? true:false)